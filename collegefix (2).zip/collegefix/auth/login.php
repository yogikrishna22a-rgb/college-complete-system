<?php
/**
 * CollegeFix - User Login
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Redirect if already authenticated
if (is_logged_in()) {
    $role = $_SESSION['user_role'] ?? 'student';
    if ($role === 'admin') redirect('admin/dashboard.php');
    if ($role === 'staff') redirect('staff/dashboard.php');
    redirect('student/dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please enter both your email and password.';
    } else {
        try {
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND status = 'Active' LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // Set session
                $_SESSION['user_id']       = $user['id'];
                $_SESSION['user_name']     = $user['name'];
                $_SESSION['user_email']    = $user['email'];
                $_SESSION['user_role']     = $user['role'];
                $_SESSION['student_id']    = $user['student_id'];
                $_SESSION['staff_id']      = $user['staff_id'];
                $_SESSION['department_id'] = $user['department_id'];
                $_SESSION['phone']         = $user['phone'];

                set_flash('success', 'Welcome back, ' . $user['name'] . '!');

                if ($user['role'] === 'admin') {
                    redirect('admin/dashboard.php');
                } elseif ($user['role'] === 'staff') {
                    redirect('staff/dashboard.php');
                } else {
                    redirect('student/dashboard.php');
                }
            } else {
                $error = 'Invalid email or password. Please verify credentials.';
            }
        } catch (Exception $e) {
            $error = 'Database authentication error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - CollegeFix Portal</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
  <script src="<?php echo base_url('assets/js/lucide.min.js'); ?>"></script>
</head>
<body>

<div class="auth-wrapper">
  <div class="auth-card">
    
    <div class="auth-header">
      <div class="auth-logo">
        <i data-lucide="shield-check"></i>
      </div>
      <h1>CollegeFix</h1>
      <p>Complaint & Maintenance Management System</p>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger" style="margin-bottom: 16px;">
        <?php echo clean($error); ?>
      </div>
    <?php endif; ?>

    <?php $flash = get_flash(); if ($flash): ?>
      <div class="alert alert-<?php echo clean($flash['type']); ?>" style="margin-bottom: 16px;">
        <?php echo clean($flash['message']); ?>
      </div>
    <?php endif; ?>

    <form action="<?php echo base_url('auth/login.php'); ?>" method="POST" id="loginForm">
      <input type="hidden" name="sid" value="<?php echo htmlspecialchars(session_id()); ?>">
      <div class="form-group">
        <label for="email" class="form-label">Email Address</label>
        <input type="email" name="email" id="email" class="form-control" placeholder="name@collegefix.edu" required autofocus>
      </div>

      <div class="form-group">
        <label for="password" class="form-label">Password</label>
        <input type="password" name="password" id="password" class="form-control" placeholder="••••••••" required>
      </div>

      <button type="submit" class="btn btn-primary btn-lg" style="width: 100%; margin-top: 8px;">
        <i data-lucide="log-in" style="width: 18px; height: 18px;"></i>
        <span>Sign In to CollegeFix</span>
      </button>
    </form>

    <div style="text-align: center; margin-top: 24px; font-size: 13px; color: #64748b;">
      Are you a new student? 
      <a href="<?php echo base_url('auth/register.php'); ?>" style="color: #2563eb; font-weight: 600; text-decoration: none;">
        Register Account
      </a>
    </div>

  </div>
</div>

<script src="<?php echo base_url('assets/js/script.js'); ?>"></script>
<script>
  if (typeof lucide !== 'undefined' && typeof lucide.createIcons === 'function') {
    lucide.createIcons();
  }
</script>
</body>
</html>
