<?php
/**
 * CollegeFix - Student Registration
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Redirect if already logged in
if (is_logged_in()) {
    redirect('index.php');
}

$error = '';
$success = '';

// Fetch departments for dropdown
$departments = [];
try {
    $stmt = $conn->query("SELECT id, name, code FROM departments ORDER BY name ASC");
    $departments = $stmt->fetchAll();
} catch (Exception $e) {
    // Ignore error
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name          = trim($_POST['name'] ?? '');
    $email         = trim($_POST['email'] ?? '');
    $student_id    = trim($_POST['student_id'] ?? '');
    $department_id = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
    $password      = $_POST['password'] ?? '';
    $confirm_pass  = $_POST['confirm_password'] ?? '';

    if (empty($name) || empty($email) || empty($student_id) || empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please provide a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($password !== $confirm_pass) {
        $error = 'Passwords do not match.';
    } else {
        try {
            // Check if email or student ID exists
            $check = $conn->prepare("SELECT id FROM users WHERE email = ? OR student_id = ?");
            $check->execute([$email, $student_id]);
            if ($check->fetch()) {
                $error = 'An account with this email address or Student ID already exists.';
            } else {
                // Hash password securely
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                
                $insert = $conn->prepare("INSERT INTO users (name, email, password, role, student_id, department_id, status, created_at) VALUES (?, ?, ?, 'student', ?, ?, 'Active', ?)");
                $now = date('Y-m-d H:i:s');
                $insert->execute([$name, $email, $hashed_password, $student_id, $department_id, $now]);
                
                $new_id = $conn->lastInsertId();

                // Auto login new student
                $_SESSION['user_id']       = $new_id;
                $_SESSION['user_name']     = $name;
                $_SESSION['user_email']    = $email;
                $_SESSION['user_role']     = 'student';
                $_SESSION['student_id']    = $student_id;
                $_SESSION['staff_id']      = null;
                $_SESSION['department_id'] = $department_id;
                $_SESSION['phone']         = $phone;

                // Welcome notification
                create_notification($conn, $new_id, null, 'Welcome to CollegeFix', 'Your student account has been registered successfully. You can now submit maintenance complaints.', 'success');

                set_flash('success', 'Registration successful! Welcome to CollegeFix.');
                redirect('student/dashboard.php');
            }
        } catch (Exception $e) {
            $error = 'Error registering user: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Registration - CollegeFix</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
  <script src="<?php echo base_url('assets/js/lucide.min.js'); ?>"></script>
</head>
<body>

<div class="auth-wrapper" style="padding: 40px 16px;">
  <div class="auth-card" style="max-width: 520px;">
    
    <div class="auth-header">
      <div class="auth-logo">
        <i data-lucide="user-plus"></i>
      </div>
      <h1>Student Registration</h1>
      <p>Create your student account to report and track issues</p>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger" style="margin-bottom: 16px;">
        <?php echo clean($error); ?>
      </div>
    <?php endif; ?>

    <form action="<?php echo base_url('auth/register.php'); ?>" method="POST">
      <div class="form-group">
        <label for="name" class="form-label">Full Name <span class="required">*</span></label>
        <input type="text" name="name" id="name" class="form-control" placeholder="e.g. John Doe" value="<?php echo clean($_POST['name'] ?? ''); ?>" required>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="email" class="form-label">College Email <span class="required">*</span></label>
          <input type="email" name="email" id="email" class="form-control" placeholder="john@college.edu" value="<?php echo clean($_POST['email'] ?? ''); ?>" required>
        </div>
        <div class="form-group">
          <label for="student_id" class="form-label">Student ID / Roll No <span class="required">*</span></label>
          <input type="text" name="student_id" id="student_id" class="form-control" placeholder="e.g. STU2024045" value="<?php echo clean($_POST['student_id'] ?? ''); ?>" required>
        </div>
      </div>

      <div class="form-group">
        <label for="department_id" class="form-label">Academic Class / Section</label>
        <select name="department_id" id="department_id" class="form-control">
          <option value="">-- Select Class --</option>
          <?php foreach ($departments as $dept): ?>
            <option value="<?php echo $dept['id']; ?>" <?php echo (isset($_POST['department_id']) && $_POST['department_id'] == $dept['id']) ? 'selected' : ''; ?>>
              <?php echo clean($dept['name'] . ' (' . $dept['code'] . ')'); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="password" class="form-label">Password <span class="required">*</span></label>
          <input type="password" name="password" id="password" class="form-control" placeholder="At least 6 characters" required>
        </div>
        <div class="form-group">
          <label for="confirm_password" class="form-label">Confirm Password <span class="required">*</span></label>
          <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Repeat password" required>
        </div>
      </div>

      <button type="submit" class="btn btn-primary btn-lg" style="width: 100%; margin-top: 10px;">
        <i data-lucide="check-circle" style="width: 18px; height: 18px;"></i>
        <span>Register & Access Portal</span>
      </button>
    </form>

    <div style="text-align: center; margin-top: 20px; font-size: 13px; color: #64748b;">
      Already have an account? 
      <a href="<?php echo base_url('auth/login.php'); ?>" style="color: #2563eb; font-weight: 600; text-decoration: none;">
        Sign In here
      </a>
    </div>

  </div>
</div>

<script src="<?php echo base_url('assets/js/script.js'); ?>"></script>
<script>
  if (typeof lucide !== 'undefined' && typeof lucide.createIcons === 'function') {
    lucide.createIcons();
  }
</script>
</body>
</html>
