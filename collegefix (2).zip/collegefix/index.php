<?php
/**
 * CollegeFix - Root Entry Point
 */

require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) {
    $role = $_SESSION['user_role'] ?? 'student';
    if ($role === 'admin') {
        redirect('admin/dashboard.php');
    } elseif ($role === 'staff') {
        redirect('staff/dashboard.php');
    } else {
        redirect('student/dashboard.php');
    }
} else {
    redirect('auth/login.php');
}
