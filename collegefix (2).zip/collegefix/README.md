# CollegeFix – College Complaint & Maintenance Management System

A professional, responsive web-based maintenance and complaint resolution portal engineered in **PHP 8+** and **MySQL** for colleges and universities.

Designed specifically for **XAMPP / Apache / MySQL** on Windows, macOS, or Linux, without requiring Node.js or React.

---

## 🏛️ System Features & User Roles

### 1. 🛡️ Admin Panel (Principal / Maintenance Director)
- **Executive Command Center:** Real-time metrics on total complaints, pending reviews, active repairs, resolved/closed tickets, and critical emergencies.
- **Interactive Analytics:** Visual Chart.js charts for complaints by category, complaints by department, and status breakdown.
- **Complaint Workflow Management:** Full inspection of complaint details, attached problem photos, location specifics, and student information.
- **Technician Assignment:** Assign or re-assign tickets directly to staff technicians based on domain specialty and current workload.
- **Override Status & Priority:** Adjust priority (Low, Medium, High, Emergency) or override status (Submitted, Under Review, Assigned, In Progress, Resolved, Closed, Rejected).
- **Staff Directory:** Manage maintenance staff profiles, track resolved tasks, and monitor student satisfaction star ratings.
- **Students Directory:** View registered students, department enrollments, and complaint submission histories.
- **Category & Department Management:** Add, edit, and toggle campus issue categories and academic departments.
- **Accreditation & Audit Reports:** Export full system reports and complaints data into CSV format for official university documentation (NIRF, NAAC, ISO).
- **College Settings:** Customize college name, campus address, helpline numbers, and admin security credentials.

### 2. 🎓 Student Portal
- **Dashboard:** Overview of personal tickets, pending items, resolved issues, and recent alerts.
- **Complaint Submission Form:** 
  - Dynamic category selection (Electrical, Plumbing, Smart Board, AC, Furniture, Network, etc.)
  - Precise location tracking (Building/Block, Floor Level, Room / Lab number)
  - Priority selection (Low, Medium, High, Emergency)
  - Problem image / screenshot upload (JPG, PNG, WEBP with 5MB validation)
- **Live Complaint Tracker:** Visual multi-step progress bar (`Submitted → Reviewed → Assigned → In Progress → Resolved → Closed`).
- **Interactive Communication:** Post inquiries or supplementary information directly to the complaint timeline.
- **Resolution Verification & Feedback:**
  - When staff marks an issue resolved, students inspect the location and confirm completion.
  - Interactive 5-star rating system, satisfaction toggle, and feedback comments.
  - One-click "Reopen Ticket" with reason if the problem persists.
- **Student Profile:** Update contact phone, department, and change password securely.

### 3. 🛠️ Maintenance Staff Portal
- **Work Orders Dashboard:** Immediate view of assigned tasks, ongoing repairs, and emergency alerts.
- **Task Management:** Inspect location, problem descriptions, and student contact numbers.
- **Progress Updates:**
  - Transition status to *In Progress* when diagnosing/repairing.
  - Mark *Resolved* when the repair is completed.
  - Log work notes detailing replacement parts or repairs made.
  - Upload proof-of-resolution photographs (e.g. repaired electrical board, fixed faucet).
- **Work History:** Archive of all completed jobs and student satisfaction scores.

---

## 🚀 Installation Guide for XAMPP (Local Machine)

### Step 1: Start XAMPP Services
1. Open the **XAMPP Control Panel**.
2. Click **Start** next to **Apache**.
3. Click **Start** next to **MySQL**.

### Step 2: Copy Project to `htdocs`
1. Locate your XAMPP installation directory:
   - **Windows:** `C:\xampp\htdocs\`
   - **macOS:** `/Applications/XAMPP/xamppfiles/htdocs/`
   - **Linux:** `/opt/lampp/htdocs/`
2. Place the `collegefix` folder inside `htdocs`:
   ```
   C:\xampp\htdocs\collegefix\
   ```

### Step 3: Import Database in phpMyAdmin
1. Open your web browser and go to: `http://localhost/phpmyadmin`
2. Click on **New** in the left sidebar to create a database.
3. Database name: **`collegefix`** (Collation: `utf8mb4_unicode_ci`).
4. Click **Create**.
5. Select the newly created `collegefix` database.
6. Go to the **Import** tab.
7. Click **Choose File** and select `C:\xampp\htdocs\collegefix\database.sql`.
8. Click **Import** (or **Go**).
9. All 8 tables (`departments`, `categories`, `users`, `complaints`, `complaint_updates`, `notifications`, `feedback`, `college_settings`) and initial demo accounts will be created automatically!

### Step 4: Access the Application
Open your browser and visit:
```
http://localhost/collegefix/
```

---

## 🔑 Demo Login Credentials

The system includes pre-configured demo accounts for testing all roles:

| Role | Email | Password | Details |
|---|---|---|---|
| **Administrator** | `admin@collegefix.edu` | `Admin@123` | Full administrative control |
| **Student** | `student@collegefix.edu` | `Student@123` | CS Dept &bull; Roll: STU2024001 |
| **Maintenance Staff** | `staff@collegefix.edu` | `Staff@123` | Electrical & Hardware Technician |

*(Note: On the login page, you can also click the **Quick Demo Credentials** buttons to instantly autofill any account!)*

---

## 📁 Project Directory Structure

```
collegefix/
├── admin/                     # Administrator Pages
│   ├── categories.php         # Issue category manager
│   ├── complaint_view.php     # 360-degree complaint inspector & assignment
│   ├── complaints.php         # Master complaints directory & filter
│   ├── dashboard.php          # Administrative command center & charts
│   ├── departments.php        # Academic department configuration
│   ├── notifications.php      # Incident alerts log
│   ├── reports.php            # Analytics & performance matrix
│   ├── settings.php           # College identity & security settings
│   ├── staff.php              # Maintenance technician directory
│   └── students.php           # Registered student directory
│
├── api/                       # API Endpoints
│   ├── download-zip.php       # Instant 1-click ZIP export for XAMPP
│   └── export-csv.php         # CSV exporter for complaints & reports
│
├── assets/                    # Front-end styling and scripts
│   ├── css/
│   │   └── style.css          # Modern custom CSS design system
│   └── js/
│       └── script.js          # Mobile sidebar, modals, star rating
│
├── auth/                      # Authentication
│   ├── login.php              # Secure login with bcrypt validation
│   ├── logout.php             # Session destroyer
│   └── register.php           # Student registration
│
├── config/
│   └── db.php                 # Environment-agnostic PDO database connection
│
├── includes/                  # Core helpers & layout templates
│   ├── auth_check.php         # Role-based access control middleware
│   ├── footer.php             # Common HTML footer & script loader
│   ├── functions.php          # Security sanitizers, uploads, badges
│   ├── header.php             # Common HTML header & topbar
│   └── sidebar.php            # Role-specific sidebar navigation
│
├── staff/                     # Maintenance Staff Portal
│   ├── complaints.php         # Resolved tasks history
│   ├── dashboard.php          # Technician dashboard & active tasks
│   ├── notifications.php      # Work order notifications
│   ├── profile.php            # Specialty & contact settings
│   ├── task_view.php          # Task progress logger & resolution upload
│   └── tasks.php              # Assigned tasks list & filters
│
├── student/                   # Student Portal
│   ├── complaint_view.php     # Timeline tracker & resolution confirmation
│   ├── complaints.php         # Student complaints list & search
│   ├── dashboard.php          # Student dashboard & stat counters
│   ├── notifications.php      # Status alerts
│   ├── profile.php            # Student profile & password update
│   └── submit_complaint.php   # Detailed complaint registration form
│
├── uploads/                   # User and staff uploads
│   ├── complaints/            # Problem photos from students
│   └── resolutions/           # Proof-of-work photos from staff
│
├── database.sql               # Full schema and seed data
├── index.php                  # Root entry router
└── README.md                  # Comprehensive documentation
```

---

## 🔒 Security Measures Implemented
- **Password Protection:** All user passwords hashed using industry standard `password_hash($password, PASSWORD_BCRYPT)`.
- **SQL Injection Prevention:** 100% of database queries utilize PDO Prepared Statements with parameterized inputs.
- **Cross-Site Scripting (XSS):** All dynamic browser outputs pass through `htmlspecialchars()` with UTF-8 encoding via the `clean()` helper.
- **Strict File Upload Validation:** File extension and MIME-type restrictions (JPG, PNG, WEBP), 5MB size limit, and randomized UUID filenames to prevent file overwrite attacks and directory traversals.
- **Role-Based Access Control (RBAC):** Middleware in `includes/auth_check.php` verifies active session authenticity and user role permissions on every page request.
