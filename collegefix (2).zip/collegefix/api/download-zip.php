<?php
/**
 * CollegeFix - 1-Click Codebase ZIP Generator
 * Generates an instant downloadable zip archive of the complete CollegeFix system for XAMPP deployment.
 */

require_once __DIR__ . '/../includes/functions.php';

$root_dir = realpath(__DIR__ . '/..');
$zip_filename = 'collegefix-xampp-source.zip';

if (!extension_loaded('zip')) {
    // Fallback: simple text error
    header('Content-Type: text/plain');
    echo "PHP ZipArchive extension is not loaded in this environment. You can copy the files directly from the workspace.";
    exit;
}

$zip = new ZipArchive();
$temp_file = tempnam(sys_get_temp_dir(), 'cf_zip');

if ($zip->open($temp_file, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root_dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );

    foreach ($files as $file) {
        if (!$file->isDir()) {
            $filePath = $file->getRealPath();
            $relativePath = substr($filePath, strlen($root_dir) + 1);

            // Skip sqlite database files from the zip to keep it clean for MySQL
            if (str_ends_with($relativePath, '.sqlite') || str_ends_with($relativePath, '.db')) {
                continue;
            }

            $zip->addFile($filePath, 'collegefix/' . $relativePath);
        }
    }
    $zip->close();

    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zip_filename . '"');
    header('Content-Length: ' . filesize($temp_file));
    header('Pragma: no-cache');
    readfile($temp_file);
    @unlink($temp_file);
    exit;
} else {
    echo "Could not create zip archive.";
    exit;
}
