<?php
/**
 * CollegeFix - Student Dashboard
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['student']);

$user = current_user();
$user_id = $user['id'];

// Get complaint counts
$counts = [
    'total'       => 0,
    'pending'     => 0,
    'in_progress' => 0,
    'resolved'    => 0,
    'reopened'    => 0
];

try {
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status IN ('Submitted', 'Under Review', 'Assigned') THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) as resolved,
            SUM(CASE WHEN status = 'Reopened' THEN 1 ELSE 0 END) as reopened
        FROM complaints 
        WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    $res = $stmt->fetch();
    if ($res) {
        $counts['total']       = (int)($res['total'] ?? 0);
        $counts['pending']     = (int)($res['pending'] ?? 0);
        $counts['in_progress'] = (int)($res['in_progress'] ?? 0);
        $counts['resolved']    = (int)($res['resolved'] ?? 0);
        $counts['reopened']    = (int)($res['reopened'] ?? 0);
    }

    // Recent complaints
    $stmt = $conn->prepare("
        SELECT c.*, cat.name as category_name, u.name as staff_name 
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN users u ON c.assigned_staff_id = u.id
        WHERE c.user_id = ?
        ORDER BY c.created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$user_id]);
    $recent_complaints = $stmt->fetchAll();

    // Recent notifications
    $stmt = $conn->prepare("
        SELECT * FROM notifications 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 4
    ");
    $stmt->execute([$user_id]);
    $notifications = $stmt->fetchAll();

} catch (Exception $e) {
    set_flash('danger', 'Error retrieving dashboard metrics: ' . $e->getMessage());
    $recent_complaints = [];
    $notifications = [];
}

$page_title = 'Student Dashboard - CollegeFix';
$active_menu = 'dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Header Action Area -->
<div class="page-header">
  <div class="page-title">
    <h1>Welcome, <?php echo clean($user['name']); ?></h1>
    <p>Student Portal &bull; ID: <?php echo clean($user['student_id'] ?? 'N/A'); ?> &bull; Report and track campus maintenance issues in real-time</p>
  </div>
  <div class="page-actions">
    <a href="<?php echo base_url('student/submit_complaint.php'); ?>" class="btn btn-primary btn-lg">
      <i data-lucide="plus-circle" style="width: 18px; height: 18px;"></i>
      <span>Submit New Complaint</span>
    </a>
  </div>
</div>

<!-- Stat Cards -->
<div class="stats-grid">
  <div class="stat-card stat-primary">
    <div class="stat-content">
      <h3>Total Complaints</h3>
      <div class="stat-number"><?php echo $counts['total']; ?></div>
      <div class="stat-subtext">All time registered</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="folder"></i>
    </div>
  </div>

  <div class="stat-card stat-warning">
    <div class="stat-content">
      <h3>Pending Review</h3>
      <div class="stat-number"><?php echo $counts['pending']; ?></div>
      <div class="stat-subtext">Awaiting or assigned</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="clock"></i>
    </div>
  </div>

  <div class="stat-card stat-info">
    <div class="stat-content">
      <h3>In Progress</h3>
      <div class="stat-number"><?php echo $counts['in_progress']; ?></div>
      <div class="stat-subtext">Staff currently working</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="wrench"></i>
    </div>
  </div>

  <div class="stat-card stat-success">
    <div class="stat-content">
      <h3>Resolved</h3>
      <div class="stat-number"><?php echo $counts['resolved']; ?></div>
      <div class="stat-subtext">Completed issues</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="check-circle-2"></i>
    </div>
  </div>

  <div class="stat-card stat-emergency">
    <div class="stat-content">
      <h3>Reopened</h3>
      <div class="stat-number"><?php echo $counts['reopened']; ?></div>
      <div class="stat-subtext">Needs further work</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="refresh-cw"></i>
    </div>
  </div>
</div>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
  
  <!-- Recent Complaints -->
  <div class="content-card">
    <div class="card-header">
      <h3>Recent Complaints</h3>
      <a href="<?php echo base_url('student/complaints.php'); ?>" class="btn btn-sm btn-secondary">View All Complaints</a>
    </div>
    <div class="card-body card-body-table">
      <?php if (empty($recent_complaints)): ?>
        <div style="padding: 40px 20px; text-align: center; color: var(--text-muted);">
          <i data-lucide="check-circle" style="width: 48px; height: 48px; margin: 0 auto 12px; color: #10b981;"></i>
          <p style="font-size: 15px; font-weight: 600;">No complaints submitted yet</p>
          <p style="font-size: 13px; margin-top: 4px;">Notice an issue in a classroom, lab, or hostel? Click below to file a ticket.</p>
          <a href="<?php echo base_url('student/submit_complaint.php'); ?>" class="btn btn-sm btn-primary" style="margin-top: 14px;">
            Submit Your First Complaint
          </a>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Title</th>
                <th>Category</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Assigned Staff</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recent_complaints as $c): ?>
                <tr>
                  <td>
                    <a href="<?php echo base_url('student/complaint_view.php?id=' . $c['id']); ?>" class="table-code">
                      #<?php echo clean($c['complaint_code']); ?>
                    </a>
                  </td>
                  <td>
                    <strong><?php echo clean(mb_strimwidth($c['title'], 0, 30, '...')); ?></strong>
                    <div style="font-size: 11px; color: var(--text-muted);">
                      <?php echo clean($c['building'] . ' - ' . $c['room_number']); ?>
                    </div>
                  </td>
                  <td><?php echo clean($c['category_name'] ?? 'General'); ?></td>
                  <td><?php echo get_priority_badge($c['priority']); ?></td>
                  <td><?php echo get_status_badge($c['status']); ?></td>
                  <td>
                    <?php if (!empty($c['staff_name'])): ?>
                      <span style="font-size: 12px; font-weight: 500; color: #1e40af;"><?php echo clean($c['staff_name']); ?></span>
                    <?php else: ?>
                      <span style="font-size: 12px; color: var(--text-muted);">Unassigned</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <a href="<?php echo base_url('student/complaint_view.php?id=' . $c['id']); ?>" class="btn btn-sm btn-secondary">
                      Track
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Recent Notifications & Helpful Info -->
  <div>
    <div class="content-card">
      <div class="card-header">
        <h3>Recent Updates</h3>
        <a href="<?php echo base_url('student/notifications.php'); ?>" class="btn btn-sm btn-secondary">View All</a>
      </div>
      <div class="card-body" style="padding: 16px 20px;">
        <?php if (empty($notifications)): ?>
          <p style="font-size: 13px; color: var(--text-muted); text-align: center; padding: 20px 0;">
            No new notifications.
          </p>
        <?php else: ?>
          <div style="display: flex; flex-direction: column; gap: 12px;">
            <?php foreach ($notifications as $n): ?>
              <div style="padding: 10px 12px; border-radius: var(--radius-sm); background: #f8fafc; border: 1px solid var(--border-color); font-size: 13px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                  <strong style="color: var(--text-main); font-size: 12px;"><?php echo clean($n['title']); ?></strong>
                  <span style="font-size: 10px; color: var(--text-muted);"><?php echo time_ago($n['created_at']); ?></span>
                </div>
                <p style="color: var(--text-muted); font-size: 12px; line-height: 1.4;">
                  <?php echo clean($n['message']); ?>
                </p>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Quick Help Card -->
    <div class="content-card" style="border-left: 4px solid #2563eb;">
      <div class="card-body" style="padding: 18px 20px;">
        <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 6px;">Campus Maintenance Helpline</h4>
        <p style="font-size: 12px; color: var(--text-muted); line-height: 1.5;">
          For critical electrical emergencies, water pipe bursts, or lab hazards, choose <strong>Emergency</strong> priority in the complaint form for immediate dispatch.
        </p>
        <div style="margin-top: 12px; font-size: 12px; font-weight: 600; color: #1e3a8a;">
          <i data-lucide="phone" style="width: 13px; height: 13px; display: inline-block; vertical-align: middle;"></i>
          <span><?php echo clean(get_setting($conn, 'contact_phone', '+91 (080) 2839-4455')); ?></span>
        </div>
      </div>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
