<?php
/**
 * CollegeFix - Student Profile & Password Change
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['student']);

$user = current_user();
$user_id = $user['id'];
$error = '';

// Handle Profile Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // 1. Update Details
    if ($action === 'update_profile') {
        $name          = trim($_POST['name'] ?? '');
        $phone         = trim($_POST['phone'] ?? '');
        $department_id = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;

        if (empty($name)) {
            $error = 'Name cannot be empty.';
        } else {
            try {
                $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ?, department_id = ? WHERE id = ?");
                $stmt->execute([$name, $phone, $department_id, $user_id]);

                $_SESSION['user_name']     = $name;
                $_SESSION['phone']         = $phone;
                $_SESSION['department_id'] = $department_id;

                set_flash('success', 'Profile details updated successfully.');
                redirect('student/profile.php');
            } catch (Exception $e) {
                $error = 'Error updating profile: ' . $e->getMessage();
            }
        }
    }

    // 2. Change Password
    elseif ($action === 'change_password') {
        $current_pass = $_POST['current_password'] ?? '';
        $new_pass     = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        if (empty($current_pass) || empty($new_pass)) {
            $error = 'Please fill out all password fields.';
        } elseif (strlen($new_pass) < 6) {
            $error = 'New password must be at least 6 characters.';
        } elseif ($new_pass !== $confirm_pass) {
            $error = 'New passwords do not match.';
        } else {
            try {
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $hash = $stmt->fetchColumn();

                if (!password_verify($current_pass, $hash)) {
                    $error = 'Incorrect current password.';
                } else {
                    $new_hash = password_hash($new_pass, PASSWORD_BCRYPT);
                    $stmt_up = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt_up->execute([$new_hash, $user_id]);

                    set_flash('success', 'Password changed successfully!');
                    redirect('student/profile.php');
                }
            } catch (Exception $e) {
                $error = 'Error updating password: ' . $e->getMessage();
            }
        }
    }
}

// Fetch fresh user record & departments
$departments = [];
try {
    $stmt = $conn->prepare("SELECT u.*, d.name as department_name FROM users u LEFT JOIN departments d ON u.department_id = d.id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();

    $stmt_d = $conn->query("SELECT id, name, code FROM departments ORDER BY name ASC");
    $departments = $stmt_d->fetchAll();
} catch (Exception $e) {
    $user_data = $user;
}

$page_title = 'My Profile - CollegeFix';
$active_menu = 'profile';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>Student Profile</h1>
    <p>Manage your contact details and account security.</p>
  </div>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger">
    <?php echo clean($error); ?>
  </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; max-width: 1000px;">
  
  <!-- Profile Info Form -->
  <div class="content-card">
    <div class="card-header">
      <h3>Personal Information</h3>
    </div>
    <div class="card-body">
      <form action="<?php echo base_url('student/profile.php'); ?>" method="POST">
        <input type="hidden" name="action" value="update_profile">

        <div class="form-group">
          <label for="name" class="form-label">Full Name</label>
          <input type="text" name="name" id="name" class="form-control" value="<?php echo clean($user_data['name']); ?>" required>
        </div>

        <div class="form-group">
          <label class="form-label">Email Address (Read-only)</label>
          <input type="email" class="form-control" value="<?php echo clean($user_data['email']); ?>" disabled style="background: #f1f5f9; cursor: not-allowed;">
          <div class="form-hint">Contact administration if your official email needs updating.</div>
        </div>

        <div class="form-group">
          <label class="form-label">Student ID / Roll No</label>
          <input type="text" class="form-control" value="<?php echo clean($user_data['student_id'] ?? 'N/A'); ?>" disabled style="background: #f1f5f9; cursor: not-allowed;">
        </div>

        <div class="form-group">
          <label for="department_id" class="form-label">Academic Class / Section</label>
          <select name="department_id" id="department_id" class="form-control">
            <option value="">-- Select Class --</option>
            <?php foreach ($departments as $dept): ?>
              <option value="<?php echo $dept['id']; ?>" <?php echo ($user_data['department_id'] == $dept['id']) ? 'selected' : ''; ?>>
                <?php echo clean($dept['name'] . ' (' . $dept['code'] . ')'); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <button type="submit" class="btn btn-primary">Save Changes</button>
      </form>
    </div>
  </div>

  <!-- Password Change Card -->
  <div class="content-card">
    <div class="card-header">
      <h3>Change Password</h3>
    </div>
    <div class="card-body">
      <form action="<?php echo base_url('student/profile.php'); ?>" method="POST">
        <input type="hidden" name="action" value="change_password">

        <div class="form-group">
          <label for="current_password" class="form-label">Current Password</label>
          <input type="password" name="current_password" id="current_password" class="form-control" required placeholder="••••••••">
        </div>

        <div class="form-group">
          <label for="new_password" class="form-label">New Password</label>
          <input type="password" name="new_password" id="new_password" class="form-control" required placeholder="Minimum 6 characters">
        </div>

        <div class="form-group">
          <label for="confirm_password" class="form-label">Confirm New Password</label>
          <input type="password" name="confirm_password" id="confirm_password" class="form-control" required placeholder="••••••••">
        </div>

        <button type="submit" class="btn btn-secondary">Update Password</button>
      </form>
    </div>
  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
