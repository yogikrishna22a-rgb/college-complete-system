<?php
/**
 * CollegeFix - Student Complaint Details & Tracking
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['student']);

$user = current_user();
$complaint_id = (int)($_GET['id'] ?? 0);

if (!$complaint_id) {
    set_flash('danger', 'Complaint not found.');
    redirect('student/complaints.php');
}

// Strict Ownership Verification: Ensure student can ONLY access their own complaints
$auth_stmt = $conn->prepare("SELECT id, user_id FROM complaints WHERE id = ?");
$auth_stmt->execute([$complaint_id]);
$auth_check = $auth_stmt->fetch();

if (!$auth_check) {
    set_flash('danger', 'Complaint not found.');
    redirect('student/complaints.php');
}

if ((int)$auth_check['user_id'] !== (int)$user['id']) {
    set_flash('danger', 'Access denied: You can only view and manage your own complaints.');
    redirect('student/complaints.php');
}

// Handle Student Actions: Feedback & Close or Reopen or Add Note
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // 1. Confirm Resolution & Give Feedback
    if ($action === 'submit_feedback') {
        $rating = (int)($_POST['rating'] ?? 5);
        $is_satisfied = isset($_POST['is_satisfied']) ? 1 : 0;
        $comments = trim($_POST['comments'] ?? '');

        try {
            // Save feedback
            $stmt = $conn->prepare("INSERT INTO feedback (complaint_id, user_id, rating, is_satisfied, comments, created_at) VALUES (?, ?, ?, ?, ?, ?)");
            $now = date('Y-m-d H:i:s');
            $stmt->execute([$complaint_id, $user['id'], $rating, $is_satisfied, $comments, $now]);

            // Update complaint to Closed
            $stmt_close = $conn->prepare("UPDATE complaints SET status = 'Closed', closed_at = ? WHERE id = ? AND user_id = ?");
            $stmt_close->execute([$now, $complaint_id, $user['id']]);

            // Log update
            $stmt_up = $conn->prepare("INSERT INTO complaint_updates (complaint_id, user_id, update_type, status, notes, created_at) VALUES (?, ?, 'Resolution Confirmation', 'Closed', ?, ?)");
            $note = "Student confirmed resolution with a {$rating}-star rating: " . ($comments ?: 'No additional comments');
            $stmt_up->execute([$complaint_id, $user['id'], $note, $now]);

            set_flash('success', 'Thank you for your feedback! The complaint has been officially closed.');
            redirect('student/complaint_view.php?id=' . $complaint_id);
        } catch (Exception $e) {
            set_flash('danger', 'Error submitting feedback: ' . $e->getMessage());
        }
    }

    // 2. Reopen Complaint
    elseif ($action === 'reopen_complaint') {
        $reopen_notes = trim($_POST['reopen_notes'] ?? '');
        if (empty($reopen_notes)) {
            set_flash('danger', 'Please provide a reason why this complaint is being reopened.');
        } else {
            try {
                $now = date('Y-m-d H:i:s');
                $stmt = $conn->prepare("UPDATE complaints SET status = 'Reopened', updated_at = ? WHERE id = ? AND user_id = ?");
                $stmt->execute([$now, $complaint_id, $user['id']]);

                $stmt_up = $conn->prepare("INSERT INTO complaint_updates (complaint_id, user_id, update_type, status, notes, created_at) VALUES (?, ?, 'Student Reopen', 'Reopened', ?, ?)");
                $stmt_up->execute([$complaint_id, $user['id'], $reopen_notes, $now]);

                // Notify admin & assigned staff
                $stmt_cmp = $conn->prepare("SELECT complaint_code, assigned_staff_id FROM complaints WHERE id = ?");
                $stmt_cmp->execute([$complaint_id]);
                $cmp_info = $stmt_cmp->fetch();

                if ($cmp_info && $cmp_info['assigned_staff_id']) {
                    create_notification($conn, $cmp_info['assigned_staff_id'], $complaint_id, 'Complaint Reopened', "Student reopened #{$cmp_info['complaint_code']}: {$reopen_notes}", 'warning');
                }

                set_flash('warning', 'Complaint has been reopened. Maintenance staff has been alerted.');
                redirect('student/complaint_view.php?id=' . $complaint_id);
            } catch (Exception $e) {
                set_flash('danger', 'Error reopening complaint: ' . $e->getMessage());
            }
        }
    }

    // 3. Add Student Comment / Note
    elseif ($action === 'add_student_comment') {
        $student_note = trim($_POST['student_note'] ?? '');
        if (!empty($student_note)) {
            try {
                $now = date('Y-m-d H:i:s');
                $stmt_up = $conn->prepare("INSERT INTO complaint_updates (complaint_id, user_id, update_type, status, notes, created_at) VALUES (?, ?, 'Student Comment', 'In Progress', ?, ?)");
                $stmt_up->execute([$complaint_id, $user['id'], $student_note, $now]);

                set_flash('success', 'Your comment has been added to the complaint history.');
                redirect('student/complaint_view.php?id=' . $complaint_id);
            } catch (Exception $e) {
                set_flash('danger', 'Error adding comment: ' . $e->getMessage());
            }
        }
    }
}

// Fetch complaint with joins
try {
    $stmt = $conn->prepare("
        SELECT c.*, cat.name as category_name, d.name as department_name, 
               u.name as student_name, u.email as student_email,
               s.name as staff_name, s.phone as staff_phone, s.specialization as staff_spec
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN users u ON c.user_id = u.id
        LEFT JOIN users s ON c.assigned_staff_id = s.id
        WHERE c.id = ? AND c.user_id = ?
    ");
    $stmt->execute([$complaint_id, $user['id']]);
    $complaint = $stmt->fetch();

    if (!$complaint) {
        set_flash('danger', 'Complaint not found or you do not have permission to view it.');
        redirect('student/complaints.php');
    }

    // Fetch updates timeline
    $stmt_up = $conn->prepare("
        SELECT cu.*, u.name as user_name, u.role as user_role
        FROM complaint_updates cu
        LEFT JOIN users u ON cu.user_id = u.id
        WHERE cu.complaint_id = ?
        ORDER BY cu.created_at ASC
    ");
    $stmt_up->execute([$complaint_id]);
    $timeline_updates = $stmt_up->fetchAll();

    // Fetch feedback if any
    $stmt_fb = $conn->prepare("SELECT * FROM feedback WHERE complaint_id = ?");
    $stmt_fb->execute([$complaint_id]);
    $feedback = $stmt_fb->fetch();

} catch (Exception $e) {
    set_flash('danger', 'Error loading complaint details: ' . $e->getMessage());
    redirect('student/complaints.php');
}

// Define visual status steps
$pipeline = ['Submitted', 'Reviewed', 'Assigned', 'In Progress', 'Resolved', 'Closed'];
$current_status = $complaint['status'];

// Compute index of active stage
$status_indices = [
    'Submitted'    => 0,
    'Under Review' => 1,
    'Reviewed'     => 1,
    'Assigned'     => 2,
    'In Progress'  => 3,
    'Resolved'     => 4,
    'Closed'       => 5,
    'Reopened'     => 3,
    'Rejected'     => -1,
];
$current_step_idx = $status_indices[$current_status] ?? 0;

$page_title = 'Complaint #' . clean($complaint['complaint_code']) . ' - CollegeFix';
$active_menu = 'complaints';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Header -->
<div class="page-header">
  <div class="page-title">
    <div style="display: flex; align-items: center; gap: 10px;">
      <h1>Complaint #<?php echo clean($complaint['complaint_code']); ?></h1>
      <?php echo get_status_badge($complaint['status']); ?>
      <?php echo get_priority_badge($complaint['priority']); ?>
    </div>
    <p>Submitted on <?php echo format_datetime($complaint['created_at']); ?> &bull; Last updated <?php echo time_ago($complaint['updated_at']); ?></p>
  </div>
  <div class="page-actions">
    <a href="<?php echo base_url('student/complaints.php'); ?>" class="btn btn-secondary">
      <i data-lucide="arrow-left"></i>
      <span>Back to Complaints</span>
    </a>
  </div>
</div>

<!-- Visual Status Timeline -->
<div class="content-card" style="padding: 24px;">
  <h3 style="font-size: 14px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 20px;">
    Progress Status Tracker
  </h3>

  <?php if ($current_status === 'Rejected'): ?>
    <div class="alert alert-danger" style="margin-bottom: 0;">
      <i data-lucide="alert-triangle"></i>
      <span>This complaint has been reviewed and rejected by the administration. Check the notes below for further clarification.</span>
    </div>
  <?php else: ?>
    <div class="timeline-tracker">
      <?php foreach ($pipeline as $idx => $step_name): ?>
        <?php 
          $is_completed = $current_step_idx > $idx;
          $is_active = $current_step_idx === $idx;
          $step_class = $is_completed ? 'completed' : ($is_active ? 'active' : '');
        ?>
        <div class="timeline-step <?php echo $step_class; ?>">
          <div class="timeline-icon">
            <?php if ($is_completed): ?>
              <i data-lucide="check" style="width: 16px; height: 16px;"></i>
            <?php else: ?>
              <span><?php echo ($idx + 1); ?></span>
            <?php endif; ?>
          </div>
          <div class="timeline-label"><?php echo $step_name; ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<div class="complaint-view-grid">
  
  <!-- Left Column: Details & Updates -->
  <div>
    
    <!-- Complaint Overview Card -->
    <div class="content-card">
      <div class="card-header">
        <h3><?php echo clean($complaint['title']); ?></h3>
        <span style="font-size: 13px; color: var(--text-muted); font-weight: 500;">
          Category: <strong><?php echo clean($complaint['category_name']); ?></strong>
        </span>
      </div>
      <div class="card-body">
        
        <h4 style="font-size: 13px; font-weight: 600; color: var(--text-muted); margin-bottom: 8px;">Description</h4>
        <div style="font-size: 14px; line-height: 1.6; color: var(--text-main); white-space: pre-line; background: #f8fafc; padding: 14px; border-radius: var(--radius-sm); border: 1px solid var(--border-color);">
          <?php echo clean($complaint['description']); ?>
        </div>

        <!-- Problem Image if uploaded -->
        <?php if (!empty($complaint['problem_image'])): ?>
          <h4 style="font-size: 13px; font-weight: 600; color: var(--text-muted); margin-top: 20px; margin-bottom: 8px;">Attached Problem Photo</h4>
          <div class="image-preview-card">
            <img src="<?php echo base_url('uploads/complaints/' . $complaint['problem_image']); ?>" alt="Problem image" onclick="window.open(this.src, '_blank')">
          </div>
          <div style="font-size: 11px; color: var(--text-muted); margin-top: 4px;">Click photo to open in full resolution</div>
        <?php endif; ?>

        <!-- Resolution Image if uploaded by staff -->
        <?php if (!empty($complaint['resolution_image'])): ?>
          <div style="margin-top: 20px; padding: 16px; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: var(--radius-sm);">
            <h4 style="font-size: 13px; font-weight: 700; color: #065f46; margin-bottom: 6px;">Staff Proof of Resolution</h4>
            <div class="image-preview-card" style="max-width: 280px;">
              <img src="<?php echo base_url('uploads/resolutions/' . $complaint['resolution_image']); ?>" alt="Resolution proof" onclick="window.open(this.src, '_blank')">
            </div>
            <?php if (!empty($complaint['resolution_notes'])): ?>
              <p style="font-size: 13px; color: #047857; margin-top: 10px;">
                <strong>Resolution Notes:</strong> <?php echo clean($complaint['resolution_notes']); ?>
              </p>
            <?php endif; ?>
          </div>
        <?php endif; ?>

      </div>
    </div>

    <!-- Student Resolution Confirmation & Feedback Form (When Resolved) -->
    <?php if ($complaint['status'] === 'Resolved' && empty($feedback)): ?>
      <div class="content-card" style="border: 2px solid #10b981; background: #f0fdf4;">
        <div class="card-header" style="background: #dcfce7; border-bottom: 1px solid #bbf7d0;">
          <h3 style="color: #166534; display: flex; align-items: center; gap: 8px;">
            <i data-lucide="check-circle-2"></i>
            <span>Action Required: Confirm Problem Resolution</span>
          </h3>
        </div>
        <div class="card-body">
          <p style="font-size: 14px; color: #166534; margin-bottom: 16px;">
            Maintenance staff has marked this problem as <strong>Resolved</strong>. Please inspect the location and confirm whether the issue was fixed to your satisfaction.
          </p>

          <form action="<?php echo base_url('student/complaint_view.php?id=' . $complaint_id); ?>" method="POST">
            <input type="hidden" name="action" value="submit_feedback">
            <input type="hidden" name="rating" id="ratingInput" value="5">

            <div class="form-group">
              <label class="form-label" style="color: #166534;">Rate the Maintenance Service:</label>
              <div class="rating-stars" data-input="ratingInput">
                <span class="star selected">&#9733;</span>
                <span class="star selected">&#9733;</span>
                <span class="star selected">&#9733;</span>
                <span class="star selected">&#9733;</span>
                <span class="star selected">&#9733;</span>
              </div>
            </div>

            <div class="form-group">
              <label style="display: flex; align-items: center; gap: 8px; font-size: 14px; color: #166534; cursor: pointer;">
                <input type="checkbox" name="is_satisfied" value="1" checked style="width: 16px; height: 16px;">
                <span>Yes, the problem has been completely resolved.</span>
              </label>
            </div>

            <div class="form-group">
              <label for="feedback_comments" class="form-label" style="color: #166534;">Feedback / Comments (Optional)</label>
              <textarea name="comments" id="feedback_comments" class="form-control" rows="2" placeholder="Tell us how quickly and effectively the staff resolved your ticket..."></textarea>
            </div>

            <div style="display: flex; gap: 12px; align-items: center;">
              <button type="submit" class="btn btn-success">
                <i data-lucide="thumbs-up"></i>
                <span>Confirm & Close Complaint</span>
              </button>

              <button type="button" class="btn btn-secondary" onclick="openModal('reopenModal')" style="color: #c2410c;">
                <i data-lucide="refresh-cw"></i>
                <span>Problem Still Not Solved? Reopen Ticket</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    <?php endif; ?>

    <!-- Display Feedback if already submitted -->
    <?php if ($feedback): ?>
      <div class="content-card" style="background: #f8fafc; border-left: 4px solid #10b981;">
        <div class="card-body">
          <h4 style="font-size: 13px; font-weight: 700; color: #166534; margin-bottom: 6px;">Your Resolution Feedback</h4>
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 6px;">
            <div style="color: #f59e0b; font-size: 18px;">
              <?php echo str_repeat('&#9733;', $feedback['rating']); ?>
            </div>
            <span style="font-size: 12px; color: var(--text-muted);">
              (<?php echo $feedback['rating']; ?>/5 Stars &bull; <?php echo $feedback['is_satisfied'] ? 'Satisfied' : 'Unsatisfied'; ?>)
            </span>
          </div>
          <?php if (!empty($feedback['comments'])): ?>
            <p style="font-size: 13px; color: var(--text-main); font-style: italic;">
              "<?php echo clean($feedback['comments']); ?>"
            </p>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Activity & Updates Timeline Feed -->
    <div class="content-card">
      <div class="card-header">
        <h3>Work History & Status Updates</h3>
      </div>
      <div class="card-body">
        
        <div class="updates-feed">
          <?php foreach ($timeline_updates as $up): ?>
            <div class="update-item">
              <div class="update-dot"></div>
              <div class="update-content">
                <div class="update-header">
                  <span class="update-author">
                    <?php echo clean($up['user_name'] ?? 'System'); ?> 
                    <span style="font-size: 10px; font-weight: 500; color: var(--text-muted); text-transform: capitalize;">
                      (<?php echo clean($up['user_role'] ?? 'System'); ?>)
                    </span>
                  </span>
                  <span class="update-time"><?php echo format_datetime($up['created_at']); ?></span>
                </div>
                <div style="font-size: 13px; color: var(--text-main); margin-top: 4px;">
                  <?php echo clean($up['notes']); ?>
                </div>
                <?php if (!empty($up['proof_image'])): ?>
                  <div style="margin-top: 8px;">
                    <img src="<?php echo base_url('uploads/resolutions/' . $up['proof_image']); ?>" alt="Proof" style="max-height: 120px; border-radius: 4px; border: 1px solid var(--border-color); cursor: pointer;" onclick="window.open(this.src, '_blank')">
                  </div>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <!-- Add Follow-up Note / Inquiry -->
        <?php if ($complaint['status'] !== 'Closed'): ?>
          <form action="<?php echo base_url('student/complaint_view.php?id=' . $complaint_id); ?>" method="POST" style="margin-top: 24px; border-top: 1px solid var(--border-color); padding-top: 20px;">
            <input type="hidden" name="action" value="add_student_comment">
            <div class="form-group">
              <label for="student_note" class="form-label">Add Note / Additional Information</label>
              <textarea name="student_note" id="student_note" class="form-control" rows="2" placeholder="Have extra details to share with maintenance staff?" required></textarea>
            </div>
            <div style="text-align: right;">
              <button type="submit" class="btn btn-secondary btn-sm">
                <i data-lucide="message-square"></i>
                <span>Post Note</span>
              </button>
            </div>
          </form>
        <?php endif; ?>

      </div>
    </div>

  </div>

  <!-- Right Column: Location & Assigned Staff Info -->
  <div>
    
    <!-- Location Card -->
    <div class="content-card">
      <div class="card-header">
        <h3>Location Details</h3>
      </div>
      <div class="card-body">
        <div style="display: flex; flex-direction: column; gap: 12px; font-size: 13px;">
          <div>
            <span style="color: var(--text-muted); display: block; font-size: 11px; text-transform: uppercase;">Campus</span>
            <strong style="color: var(--text-main); font-size: 14px;"><?php echo clean($complaint['building']); ?></strong>
          </div>
          <div>
            <span style="color: var(--text-muted); display: block; font-size: 11px; text-transform: uppercase;">Floor Level</span>
            <strong style="color: var(--text-main);"><?php echo clean($complaint['floor']); ?></strong>
          </div>
          <div>
            <span style="color: var(--text-muted); display: block; font-size: 11px; text-transform: uppercase;">Room / Area</span>
            <strong style="color: var(--text-main);"><?php echo clean($complaint['room_number']); ?></strong>
          </div>
          <?php if (!empty($complaint['department_name'])): ?>
            <div>
              <span style="color: var(--text-muted); display: block; font-size: 11px; text-transform: uppercase;">Related Class</span>
              <strong style="color: var(--text-main);"><?php echo clean($complaint['department_name']); ?></strong>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Assigned Maintenance Staff Card -->
    <div class="content-card">
      <div class="card-header">
        <h3>Assigned Maintenance Staff</h3>
      </div>
      <div class="card-body">
        <?php if (!empty($complaint['staff_name'])): ?>
          <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 14px;">
            <div class="sidebar-user-avatar" style="background: #2563eb; width: 44px; height: 44px; font-size: 16px;">
              <?php echo strtoupper(substr($complaint['staff_name'], 0, 1)); ?>
            </div>
            <div>
              <h4 style="font-size: 14px; font-weight: 700;"><?php echo clean($complaint['staff_name']); ?></h4>
              <p style="font-size: 12px; color: var(--text-muted);"><?php echo clean($complaint['staff_spec'] ?? 'Maintenance Technician'); ?></p>
            </div>
          </div>

          <?php if (!empty($complaint['staff_phone'])): ?>
            <div style="background: #eff6ff; padding: 10px 14px; border-radius: var(--radius-sm); font-size: 13px; color: #1e40af; display: flex; align-items: center; gap: 8px;">
              <i data-lucide="phone" style="width: 15px; height: 15px;"></i>
              <span><?php echo clean($complaint['staff_phone']); ?></span>
            </div>
          <?php endif; ?>
        <?php else: ?>
          <div style="text-align: center; padding: 20px 0; color: var(--text-muted);">
            <i data-lucide="clock" style="width: 36px; height: 36px; margin: 0 auto 8px; color: #94a3b8;"></i>
            <p style="font-size: 13px; font-weight: 500;">Staff assignment pending</p>
            <p style="font-size: 11px; margin-top: 4px;">The college administration is reviewing this ticket to assign the appropriate technician.</p>
          </div>
        <?php endif; ?>
      </div>
    </div>

  </div>

</div>

<!-- Reopen Modal -->
<div id="reopenModal" class="modal-backdrop">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3>Reopen Complaint #<?php echo clean($complaint['complaint_code']); ?></h3>
      <button type="button" class="modal-close" onclick="closeModal('reopenModal')">&times;</button>
    </div>
    <form action="<?php echo base_url('student/complaint_view.php?id=' . $complaint_id); ?>" method="POST">
      <input type="hidden" name="action" value="reopen_complaint">
      <div class="modal-body">
        <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 12px;">
          Please state clearly why the issue is not resolved (e.g. "Problem recurred after 2 hours", "Only partial repair completed"):
        </p>
        <div class="form-group">
          <label for="reopen_notes" class="form-label">Explanation <span class="required">*</span></label>
          <textarea name="reopen_notes" id="reopen_notes" class="form-control" rows="3" required placeholder="Describe what still needs attention..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('reopenModal')">Cancel</button>
        <button type="submit" class="btn btn-danger">Confirm Reopen</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
