<?php
/**
 * CollegeFix - Submit New Complaint
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['student']);

$user = current_user();
$error = '';

// Fetch active categories
$categories = [];
try {
    $stmt = $conn->query("SELECT id, name, description FROM categories WHERE status = 'Active' ORDER BY name ASC");
    $categories = $stmt->fetchAll();
} catch (Exception $e) {
    // Ignore error
}

// Fetch departments
$departments = [];
try {
    $stmt = $conn->query("SELECT id, name, code FROM departments ORDER BY name ASC");
    $departments = $stmt->fetchAll();
} catch (Exception $e) {
    // Ignore error
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id   = (int)($_POST['category_id'] ?? 0);
    $department_id = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : $user['department_id'];
    $title         = trim($_POST['title'] ?? '');
    $description   = trim($_POST['description'] ?? '');
    $building      = trim($_POST['building'] ?? '');
    $floor         = trim($_POST['floor'] ?? '');
    $room_number   = trim($_POST['room_number'] ?? '');
    $priority      = $_POST['priority'] ?? 'Medium';

    if (empty($category_id) || empty($title) || empty($description) || empty($building) || empty($floor) || empty($room_number)) {
        $error = 'Please fill out all required fields marked with an asterisk (*).';
    } else {
        // Handle optional problem image upload
        $image_upload = handle_image_upload('problem_image', 'complaints');
        if (!$image_upload['success']) {
            $error = $image_upload['error'];
        } else {
            $image_filename = $image_upload['filename'];

            try {
                $code = generate_complaint_code($conn);
                $now = date('Y-m-d H:i:s');

                $stmt = $conn->prepare("
                    INSERT INTO complaints (
                        complaint_code, user_id, category_id, department_id, title, description, 
                        building, floor, room_number, priority, status, problem_image, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Submitted', ?, ?, ?)
                ");
                $stmt->execute([
                    $code, $user['id'], $category_id, $department_id, $title, $description,
                    $building, $floor, $room_number, $priority, $image_filename, $now, $now
                ]);

                $complaint_id = $conn->lastInsertId();

                // Add initial timeline update
                $stmt_up = $conn->prepare("
                    INSERT INTO complaint_updates (complaint_id, user_id, update_type, status, notes, proof_image, created_at)
                    VALUES (?, ?, 'Submission', 'Submitted', ?, ?, ?)
                ");
                $init_note = "Complaint registered with {$priority} priority.";
                $stmt_up->execute([$complaint_id, $user['id'], $init_note, $image_filename, $now]);

                // Notify student
                create_notification(
                    $conn, 
                    $user['id'], 
                    $complaint_id, 
                    'Complaint Submitted', 
                    "Your complaint #{$code} ({$title}) has been submitted successfully.", 
                    'info'
                );

                // Notify all admins
                $stmt_admins = $conn->query("SELECT id FROM users WHERE role = 'admin' AND status = 'Active'");
                while ($admin = $stmt_admins->fetch()) {
                    $admin_msg = "New {$priority} complaint #{$code} logged by {$user['name']}: {$title}";
                    $notif_type = ($priority === 'Emergency') ? 'danger' : 'info';
                    create_notification($conn, $admin['id'], $complaint_id, "New {$priority} Complaint #{$code}", $admin_msg, $notif_type);
                }

                set_flash('success', "Complaint #{$code} submitted successfully! Our maintenance administration will review it promptly.");
                redirect('student/complaint_view.php?id=' . $complaint_id);

            } catch (Exception $e) {
                $error = 'Error saving complaint: ' . $e->getMessage();
            }
        }
    }
}

$page_title = 'Submit New Complaint - CollegeFix';
$active_menu = 'submit';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>Submit a Maintenance Complaint</h1>
    <p>Describe the issue clearly with exact location details so maintenance staff can resolve it quickly.</p>
  </div>
  <div class="page-actions">
    <a href="<?php echo base_url('student/complaints.php'); ?>" class="btn btn-secondary">
      <i data-lucide="arrow-left"></i>
      <span>Back to My Complaints</span>
    </a>
  </div>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger">
    <?php echo clean($error); ?>
  </div>
<?php endif; ?>

<div class="content-card" style="max-width: 900px; margin: 0 auto;">
  <div class="card-header">
    <h3>New Complaint Registration Form</h3>
    <span style="font-size: 12px; color: var(--text-muted);"><span class="required" style="color:#ef4444;">*</span> Indicates mandatory field</span>
  </div>
  <div class="card-body">
    
    <form action="<?php echo base_url('student/submit_complaint.php'); ?>" method="POST" enctype="multipart/form-data">
      
      <!-- Category & Priority Row -->
      <div class="form-row">
        <div class="form-group">
          <label for="category_id" class="form-label">Issue Category <span class="required">*</span></label>
          <select name="category_id" id="category_id" class="form-control" required>
            <option value="">-- Select Category --</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?php echo $cat['id']; ?>" <?php echo (isset($_POST['category_id']) && $_POST['category_id'] == $cat['id']) ? 'selected' : ''; ?>>
                <?php echo clean($cat['name']); ?>
                <?php if (!empty($cat['description'])) echo ' (' . clean($cat['description']) . ')'; ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label for="priority" class="form-label">Priority Level <span class="required">*</span></label>
          <select name="priority" id="priority" class="form-control" required>
            <option value="Low" <?php echo (isset($_POST['priority']) && $_POST['priority'] === 'Low') ? 'selected' : ''; ?>>Low (Minor inconvenience / cosmetic)</option>
            <option value="Medium" <?php echo (!isset($_POST['priority']) || $_POST['priority'] === 'Medium') ? 'selected' : ''; ?>>Medium (Normal priority / scheduled repair)</option>
            <option value="High" <?php echo (isset($_POST['priority']) && $_POST['priority'] === 'High') ? 'selected' : ''; ?>>High (Impacting lectures or lab experiments)</option>
            <option value="Emergency" <?php echo (isset($_POST['priority']) && $_POST['priority'] === 'Emergency') ? 'selected' : ''; ?>>Emergency (Hazard, fire/spark risk, major flood)</option>
          </select>
        </div>
      </div>

      <!-- Title -->
      <div class="form-group">
        <label for="title" class="form-label">Complaint Title / Summary <span class="required">*</span></label>
        <input type="text" name="title" id="title" class="form-control" placeholder="e.g. Overhead Projector Flickering in Room 302" value="<?php echo clean($_POST['title'] ?? ''); ?>" required maxlength="180">
        <div class="form-hint">Be concise and specific (e.g. "Water leak under sink 2" rather than "Tap broken").</div>
      </div>

      <!-- Location Information (Campus, Floor, Room) -->
      <div class="form-row" style="grid-template-columns: 2fr 1fr 1fr;">
        <div class="form-group">
          <label for="building" class="form-label">Campus <span class="required">*</span></label>
          <select name="building" id="building" class="form-control" required>
            <option value="">-- Select Campus --</option>
            <option value="Primary Campus" <?php echo (isset($_POST['building']) && $_POST['building'] === 'Primary Campus') ? 'selected' : ''; ?>>Primary Campus</option>
            <option value="High School Campus" <?php echo (isset($_POST['building']) && $_POST['building'] === 'High School Campus') ? 'selected' : ''; ?>>High School Campus</option>
          </select>
        </div>

        <div class="form-group">
          <label for="floor" class="form-label">Floor <span class="required">*</span></label>
          <input type="text" name="floor" id="floor" class="form-control" placeholder="e.g. 2nd Floor" value="<?php echo clean($_POST['floor'] ?? ''); ?>" required>
        </div>

        <div class="form-group">
          <label for="room_number" class="form-label">Room / Lab / Area <span class="required">*</span></label>
          <input type="text" name="room_number" id="room_number" class="form-control" placeholder="e.g. Lab 204 or WR-102" value="<?php echo clean($_POST['room_number'] ?? ''); ?>" required>
        </div>
      </div>

      <!-- Academic Class (Optional / Helpful) -->
      <div class="form-group">
        <label for="department_id" class="form-label">Academic Class Related (Optional)</label>
        <select name="department_id" id="department_id" class="form-control">
          <option value="">-- Select Academic Class if applicable --</option>
          <?php foreach ($departments as $dept): ?>
            <option value="<?php echo $dept['id']; ?>" <?php echo (isset($_POST['department_id']) && $_POST['department_id'] == $dept['id']) ? 'selected' : ''; ?>>
              <?php echo clean($dept['name'] . ' (' . $dept['code'] . ')'); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Description -->
      <div class="form-group">
        <label for="description" class="form-label">Detailed Description <span class="required">*</span></label>
        <textarea name="description" id="description" class="form-control" rows="5" placeholder="Explain what happened, how often it occurs, and any symptoms or safety risks..." required><?php echo clean($_POST['description'] ?? ''); ?></textarea>
      </div>

      <!-- Image Upload -->
      <div class="form-group">
        <label for="problem_image" class="form-label">Problem Photo / Screenshot (Optional but recommended)</label>
        <input type="file" name="problem_image" id="problem_image" class="form-control" accept="image/jpeg,image/png,image/webp,image/gif" onchange="validateAndPreviewImage(this)">
        <div class="form-hint">Accepted formats: JPG, PNG, WEBP, GIF. Maximum file size: 25MB. High-resolution smartphone camera photos are fully supported.</div>
        <div id="image_preview_box" style="display: none; margin-top: 10px;">
          <img id="image_preview_img" src="" alt="Photo preview" style="max-height: 180px; border-radius: 6px; border: 1px solid var(--border-color); object-fit: contain;">
          <button type="button" class="btn btn-sm btn-secondary" style="margin-left: 10px; vertical-align: top;" onclick="clearSelectedImage()">Remove Photo</button>
        </div>
        <div id="image_error_msg" style="display: none; color: #ef4444; font-size: 13px; margin-top: 6px; font-weight: 500;"></div>
      </div>

      <script>
      function validateAndPreviewImage(input) {
        var errBox = document.getElementById('image_error_msg');
        var previewBox = document.getElementById('image_preview_box');
        var previewImg = document.getElementById('image_preview_img');
        errBox.style.display = 'none';
        errBox.innerText = '';

        if (input.files && input.files[0]) {
          var file = input.files[0];
          // Check 25MB limit
          if (file.size > 25 * 1024 * 1024) {
            errBox.innerText = 'The selected file is too large (' + (file.size / (1024 * 1024)).toFixed(1) + 'MB). Maximum size is 25MB.';
            errBox.style.display = 'block';
            input.value = '';
            previewBox.style.display = 'none';
            return;
          }

          var reader = new FileReader();
          reader.onload = function(e) {
            previewImg.src = e.target.result;
            previewBox.style.display = 'flex';
            previewBox.style.alignItems = 'center';
          };
          reader.readAsDataURL(file);
        } else {
          previewBox.style.display = 'none';
        }
      }

      function clearSelectedImage() {
        var input = document.getElementById('problem_image');
        input.value = '';
        document.getElementById('image_preview_box').style.display = 'none';
        document.getElementById('image_error_msg').style.display = 'none';
      }
      </script>

      <!-- Submit Buttons -->
      <div style="margin-top: 28px; display: flex; align-items: center; justify-content: flex-end; gap: 12px;">
        <a href="<?php echo base_url('student/dashboard.php'); ?>" class="btn btn-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary btn-lg">
          <i data-lucide="send" style="width: 18px; height: 18px;"></i>
          <span>Submit Complaint</span>
        </button>
      </div>

    </form>

  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
