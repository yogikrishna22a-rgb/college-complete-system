<?php
/**
 * CollegeFix - Student Complaints List
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['student']);

$user = current_user();
$user_id = $user['id'];

// Filter params
$search   = trim($_GET['search'] ?? '');
$status   = trim($_GET['status'] ?? '');
$category = (int)($_GET['category'] ?? 0);
$priority = trim($_GET['priority'] ?? '');

// Build query
$where_clauses = ["c.user_id = ?"];
$params = [$user_id];

if (!empty($search)) {
    $where_clauses[] = "(c.complaint_code LIKE ? OR c.title LIKE ? OR c.building LIKE ? OR c.room_number LIKE ?)";
    $like = '%' . $search . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

if (!empty($status)) {
    $where_clauses[] = "c.status = ?";
    $params[] = $status;
}

if (!empty($category)) {
    $where_clauses[] = "c.category_id = ?";
    $params[] = $category;
}

if (!empty($priority)) {
    $where_clauses[] = "c.priority = ?";
    $params[] = $priority;
}

$where_sql = implode(" AND ", $where_clauses);

// Fetch categories for filter dropdown
$categories = [];
try {
    $stmt_cat = $conn->query("SELECT id, name FROM categories ORDER BY name ASC");
    $categories = $stmt_cat->fetchAll();

    $query = "
        SELECT c.*, cat.name as category_name, u.name as staff_name, u.phone as staff_phone
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN users u ON c.assigned_staff_id = u.id
        WHERE {$where_sql}
        ORDER BY c.created_at DESC
    ";
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $complaints = $stmt->fetchAll();
} catch (Exception $e) {
    set_flash('danger', 'Error loading complaints: ' . $e->getMessage());
    $complaints = [];
}

$page_title = 'My Complaints - CollegeFix';
$active_menu = 'complaints';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>My Submitted Complaints</h1>
    <p>Track progress, review staff updates, and confirm resolutions.</p>
  </div>
  <div class="page-actions">
    <a href="<?php echo base_url('student/submit_complaint.php'); ?>" class="btn btn-primary">
      <i data-lucide="plus-circle"></i>
      <span>Submit Complaint</span>
    </a>
  </div>
</div>

<!-- Search & Filter Bar -->
<div class="filter-bar">
  <form action="<?php echo base_url('student/complaints.php'); ?>" method="GET" style="display: contents;">
    
    <div class="filter-item" style="flex: 2;">
      <label class="form-label" style="font-size: 11px;">Search Keyword</label>
      <input type="text" name="search" class="form-control" placeholder="Search by code, title, room..." value="<?php echo clean($search); ?>">
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Status</label>
      <select name="status" class="form-control">
        <option value="">All Statuses</option>
        <option value="Submitted" <?php if ($status === 'Submitted') echo 'selected'; ?>>Submitted</option>
        <option value="Assigned" <?php if ($status === 'Assigned') echo 'selected'; ?>>Assigned</option>
        <option value="In Progress" <?php if ($status === 'In Progress') echo 'selected'; ?>>In Progress</option>
        <option value="Resolved" <?php if ($status === 'Resolved') echo 'selected'; ?>>Resolved</option>
        <option value="Reopened" <?php if ($status === 'Reopened') echo 'selected'; ?>>Reopened</option>
        <option value="Rejected" <?php if ($status === 'Rejected') echo 'selected'; ?>>Rejected</option>
      </select>
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Category</label>
      <select name="category" class="form-control">
        <option value="">All Categories</option>
        <?php foreach ($categories as $cat): ?>
          <option value="<?php echo $cat['id']; ?>" <?php if ($category == $cat['id']) echo 'selected'; ?>>
            <?php echo clean($cat['name']); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Priority</label>
      <select name="priority" class="form-control">
        <option value="">All Priorities</option>
        <option value="Low" <?php if ($priority === 'Low') echo 'selected'; ?>>Low</option>
        <option value="Medium" <?php if ($priority === 'Medium') echo 'selected'; ?>>Medium</option>
        <option value="High" <?php if ($priority === 'High') echo 'selected'; ?>>High</option>
        <option value="Emergency" <?php if ($priority === 'Emergency') echo 'selected'; ?>>Emergency</option>
      </select>
    </div>

    <div style="display: flex; gap: 8px;">
      <button type="submit" class="btn btn-primary" title="Filter Complaints">
        <i data-lucide="filter"></i>
        <span>Filter</span>
      </button>
      <?php if (!empty($search) || !empty($status) || !empty($category) || !empty($priority)): ?>
        <a href="<?php echo base_url('student/complaints.php'); ?>" class="btn btn-secondary" title="Reset Filters">
          <i data-lucide="x"></i>
        </a>
      <?php endif; ?>
    </div>

  </form>
</div>

<!-- Complaints Table -->
<div class="content-card">
  <div class="card-header">
    <h3>Complaints Record (<?php echo count($complaints); ?> found)</h3>
  </div>
  <div class="card-body card-body-table">
    <?php if (empty($complaints)): ?>
      <div style="padding: 40px; text-align: center; color: var(--text-muted);">
        <i data-lucide="inbox" style="width: 48px; height: 48px; margin: 0 auto 12px; color: #94a3b8;"></i>
        <p style="font-size: 15px; font-weight: 600;">No matching complaints found</p>
        <p style="font-size: 13px; margin-top: 4px;">Try clearing your filters or submit a new complaint.</p>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Ticket ID</th>
              <th>Complaint Details</th>
              <th>Category</th>
              <th>Location</th>
              <th>Priority</th>
              <th>Status</th>
              <th>Assigned Staff</th>
              <th>Submitted</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($complaints as $c): ?>
              <tr>
                <td>
                  <a href="<?php echo base_url('student/complaint_view.php?id=' . $c['id']); ?>" class="table-code">
                    #<?php echo clean($c['complaint_code']); ?>
                  </a>
                </td>
                <td>
                  <strong style="color: var(--text-main); font-size: 14px;"><?php echo clean($c['title']); ?></strong>
                  <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                    <?php echo clean(mb_strimwidth($c['description'], 0, 50, '...')); ?>
                  </div>
                </td>
                <td><?php echo clean($c['category_name'] ?? 'General'); ?></td>
                <td>
                  <span style="font-size: 13px;"><?php echo clean($c['room_number']); ?></span>
                  <div style="font-size: 11px; color: var(--text-muted);"><?php echo clean($c['building']); ?></div>
                </td>
                <td><?php echo get_priority_badge($c['priority']); ?></td>
                <td><?php echo get_status_badge($c['status']); ?></td>
                <td>
                  <?php if (!empty($c['staff_name'])): ?>
                    <span style="font-weight: 600; font-size: 13px; color: #1e40af;"><?php echo clean($c['staff_name']); ?></span>
                    <?php if (!empty($c['staff_phone'])): ?>
                      <div style="font-size: 11px; color: var(--text-muted);"><?php echo clean($c['staff_phone']); ?></div>
                    <?php endif; ?>
                  <?php else: ?>
                    <span style="font-size: 12px; color: var(--text-muted); font-style: italic;">Not yet assigned</span>
                  <?php endif; ?>
                </td>
                <td style="font-size: 12px; color: var(--text-muted);">
                  <?php echo format_datetime($c['created_at']); ?>
                </td>
                <td>
                  <a href="<?php echo base_url('student/complaint_view.php?id=' . $c['id']); ?>" class="btn btn-sm btn-secondary">
                    View Details
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
