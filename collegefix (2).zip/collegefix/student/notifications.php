<?php
/**
 * CollegeFix - Student Notifications
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['student']);

$user = current_user();
$user_id = $user['id'];

// Mark all as read action
if (isset($_GET['mark_all_read'])) {
    try {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
        $stmt->execute([$user_id]);
        set_flash('success', 'All notifications marked as read.');
        redirect('student/notifications.php');
    } catch (Exception $e) {
        set_flash('danger', 'Error updating notifications: ' . $e->getMessage());
    }
}

// Mark single as read
if (isset($_GET['read_id'])) {
    $read_id = (int)$_GET['read_id'];
    try {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
        $stmt->execute([$read_id, $user_id]);
    } catch (Exception $e) {}
}

// Fetch all notifications for student
try {
    $stmt = $conn->prepare("
        SELECT n.*, c.complaint_code 
        FROM notifications n
        LEFT JOIN complaints c ON n.complaint_id = c.id
        WHERE n.user_id = ? 
        ORDER BY n.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $notifications = $stmt->fetchAll();
} catch (Exception $e) {
    $notifications = [];
}

$page_title = 'Notifications - CollegeFix';
$active_menu = 'notifications';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>Your Notifications</h1>
    <p>Real-time updates regarding your complaint status, assignments, and resolutions.</p>
  </div>
  <div class="page-actions">
    <?php if (!empty($notifications)): ?>
      <a href="<?php echo base_url('student/notifications.php?mark_all_read=1'); ?>" class="btn btn-secondary">
        <i data-lucide="check-check"></i>
        <span>Mark All as Read</span>
      </a>
    <?php endif; ?>
  </div>
</div>

<div class="content-card">
  <div class="card-header">
    <h3>Notifications Log</h3>
  </div>
  <div class="card-body" style="padding: 0;">
    <?php if (empty($notifications)): ?>
      <div style="padding: 40px; text-align: center; color: var(--text-muted);">
        <i data-lucide="bell-off" style="width: 44px; height: 44px; margin: 0 auto 12px; color: #94a3b8;"></i>
        <p style="font-size: 15px; font-weight: 600;">No notifications found</p>
        <p style="font-size: 13px; margin-top: 4px;">You will receive alerts here whenever your complaint progress updates.</p>
      </div>
    <?php else: ?>
      <div style="display: flex; flex-direction: column;">
        <?php foreach ($notifications as $n): ?>
          <div style="display: flex; align-items: flex-start; justify-content: space-between; padding: 18px 24px; border-bottom: 1px solid var(--border-color); background: <?php echo $n['is_read'] ? '#ffffff' : '#f0f9ff'; ?>; transition: background 0.15s ease;">
            <div style="display: flex; gap: 14px; align-items: flex-start;">
              <div style="width: 36px; height: 36px; border-radius: 50%; background: <?php echo $n['type'] === 'danger' ? '#fee2e2' : ($n['type'] === 'success' ? '#dcfce7' : '#e0e7ff'); ?>; color: <?php echo $n['type'] === 'danger' ? '#b91c1c' : ($n['type'] === 'success' ? '#15803d' : '#4338ca'); ?>; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <i data-lucide="<?php echo $n['type'] === 'danger' ? 'alert-triangle' : ($n['type'] === 'success' ? 'check-circle' : 'info'); ?>" style="width: 18px; height: 18px;"></i>
              </div>
              <div>
                <div style="font-size: 14px; font-weight: <?php echo $n['is_read'] ? '600' : '700'; ?>; color: var(--text-main);">
                  <?php echo clean($n['title']); ?>
                  <?php if (!$n['is_read']): ?>
                    <span style="display: inline-block; width: 8px; height: 8px; background: #2563eb; border-radius: 50%; margin-left: 6px;"></span>
                  <?php endif; ?>
                </div>
                <div style="font-size: 13px; color: var(--text-muted); margin-top: 4px; line-height: 1.4;">
                  <?php echo clean($n['message']); ?>
                </div>
                <div style="font-size: 11px; color: var(--text-light); margin-top: 6px;">
                  <?php echo format_datetime($n['created_at']); ?> (<?php echo time_ago($n['created_at']); ?>)
                </div>
              </div>
            </div>

            <?php if (!empty($n['complaint_id'])): ?>
              <div style="margin-left: 16px;">
                <a href="<?php echo base_url('student/complaint_view.php?id=' . $n['complaint_id']); ?>" class="btn btn-sm btn-secondary" onclick="fetch('<?php echo base_url('student/notifications.php?read_id=' . $n['id']); ?>');">
                  View Ticket
                </a>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
