<?php
/**
 * CollegeFix - Navigation Sidebar
 */

$user = current_user();
$role = $user['role'] ?? 'student';
$unread_notifs = isset($conn) && $user ? get_unread_notifications_count($conn, $user['id']) : 0;
?>

<aside id="appSidebar" class="app-sidebar">
  <!-- Brand -->
  <div class="sidebar-header">
    <div class="sidebar-brand-icon">
      <i data-lucide="shield-check"></i>
    </div>
    <div class="sidebar-brand-text">
      <h2>CollegeFix</h2>
      <span>Maintenance Portal</span>
      <div>
        <span class="sidebar-role-badge role-<?php echo htmlspecialchars($role); ?>">
          <?php echo htmlspecialchars(strtoupper($role)); ?> PANEL
        </span>
      </div>
    </div>
  </div>

  <!-- Role Menus -->
  <ul class="sidebar-menu">
    
    <?php if ($role === 'admin'): ?>
      <li class="menu-section-title">ADMINISTRATION</li>
      <li>
        <a href="<?php echo base_url('admin/dashboard.php'); ?>" class="<?php echo ($active_menu === 'dashboard') ? 'active' : ''; ?>">
          <i data-lucide="layout-dashboard"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('admin/complaints.php'); ?>" class="<?php echo ($active_menu === 'complaints') ? 'active' : ''; ?>">
          <i data-lucide="clipboard-list"></i>
          <span>Active Complaints</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('admin/closed_complaints.php'); ?>" class="<?php echo ($active_menu === 'closed_complaints') ? 'active' : ''; ?>">
          <i data-lucide="check-circle-2"></i>
          <span>Closed Archive</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('admin/staff.php'); ?>" class="<?php echo ($active_menu === 'staff') ? 'active' : ''; ?>">
          <i data-lucide="wrench"></i>
          <span>Maintenance Staff</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('admin/students.php'); ?>" class="<?php echo ($active_menu === 'students') ? 'active' : ''; ?>">
          <i data-lucide="users"></i>
          <span>Students</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('admin/categories.php'); ?>" class="<?php echo ($active_menu === 'categories') ? 'active' : ''; ?>">
          <i data-lucide="tag"></i>
          <span>Categories</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('admin/classes.php'); ?>" class="<?php echo in_array($active_menu, ['classes', 'departments']) ? 'active' : ''; ?>">
          <i data-lucide="graduation-cap"></i>
          <span>Academic Classes</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('admin/reports.php'); ?>" class="<?php echo ($active_menu === 'reports') ? 'active' : ''; ?>">
          <i data-lucide="bar-chart-3"></i>
          <span>Reports & Analytics</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('admin/notifications.php'); ?>" class="<?php echo ($active_menu === 'notifications') ? 'active' : ''; ?>">
          <i data-lucide="bell"></i>
          <span>Notifications</span>
          <?php if ($unread_notifs > 0): ?>
            <span class="menu-badge"><?php echo $unread_notifs; ?></span>
          <?php endif; ?>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('admin/admins.php'); ?>" class="<?php echo ($active_menu === 'admins') ? 'active' : ''; ?>">
          <i data-lucide="user-cog"></i>
          <span>Admin Accounts</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('admin/settings.php'); ?>" class="<?php echo ($active_menu === 'settings') ? 'active' : ''; ?>">
          <i data-lucide="settings"></i>
          <span>College Settings</span>
        </a>
      </li>

    <?php elseif ($role === 'student'): ?>
      <li class="menu-section-title">STUDENT PORTAL</li>
      <li>
        <a href="<?php echo base_url('student/dashboard.php'); ?>" class="<?php echo ($active_menu === 'dashboard') ? 'active' : ''; ?>">
          <i data-lucide="layout-dashboard"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('student/submit_complaint.php'); ?>" class="<?php echo ($active_menu === 'submit') ? 'active' : ''; ?>" style="background: rgba(37, 99, 235, 0.15); color: #93c5fd; font-weight: 600;">
          <i data-lucide="plus-circle"></i>
          <span>Submit Complaint</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('student/complaints.php'); ?>" class="<?php echo ($active_menu === 'complaints') ? 'active' : ''; ?>">
          <i data-lucide="file-text"></i>
          <span>My Complaints</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('student/notifications.php'); ?>" class="<?php echo ($active_menu === 'notifications') ? 'active' : ''; ?>">
          <i data-lucide="bell"></i>
          <span>Notifications</span>
          <?php if ($unread_notifs > 0): ?>
            <span class="menu-badge"><?php echo $unread_notifs; ?></span>
          <?php endif; ?>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('student/profile.php'); ?>" class="<?php echo ($active_menu === 'profile') ? 'active' : ''; ?>">
          <i data-lucide="user"></i>
          <span>My Profile</span>
        </a>
      </li>

    <?php elseif ($role === 'staff'): ?>
      <li class="menu-section-title">STAFF PORTAL</li>
      <li>
        <a href="<?php echo base_url('staff/dashboard.php'); ?>" class="<?php echo ($active_menu === 'dashboard') ? 'active' : ''; ?>">
          <i data-lucide="layout-dashboard"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('staff/tasks.php'); ?>" class="<?php echo ($active_menu === 'tasks') ? 'active' : ''; ?>">
          <i data-lucide="check-square"></i>
          <span>My Assigned Tasks</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('staff/complaints.php'); ?>" class="<?php echo ($active_menu === 'complaints') ? 'active' : ''; ?>">
          <i data-lucide="folder-kanban"></i>
          <span>Completed Work</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('staff/notifications.php'); ?>" class="<?php echo ($active_menu === 'notifications') ? 'active' : ''; ?>">
          <i data-lucide="bell"></i>
          <span>Notifications</span>
          <?php if ($unread_notifs > 0): ?>
            <span class="menu-badge"><?php echo $unread_notifs; ?></span>
          <?php endif; ?>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url('staff/profile.php'); ?>" class="<?php echo ($active_menu === 'profile') ? 'active' : ''; ?>">
          <i data-lucide="user"></i>
          <span>My Profile</span>
        </a>
      </li>
    <?php endif; ?>

    <li class="menu-section-title" style="margin-top: 20px;">ACCOUNT</li>
    <li>
      <a href="<?php echo base_url('auth/logout.php'); ?>" style="color: #f87171;">
        <i data-lucide="log-out"></i>
        <span>Logout</span>
      </a>
    </li>
  </ul>

  <!-- Sidebar Footer User Card -->
  <div class="sidebar-footer">
    <div class="sidebar-user-avatar">
      <?php 
        $initial = strtoupper(substr($user['name'] ?? 'U', 0, 1));
        echo htmlspecialchars($initial);
      ?>
    </div>
    <div class="sidebar-user-info">
      <div class="sidebar-user-name"><?php echo htmlspecialchars($user['name'] ?? 'Guest'); ?></div>
      <div class="sidebar-user-role"><?php echo htmlspecialchars(ucfirst($role)); ?></div>
    </div>
  </div>
</aside>
