<?php
/**
 * CollegeFix - Core Helper Functions
 */

// Enhanced session initialization for cloud iframe and local environments
if (session_status() === PHP_SESSION_NONE) {
    // Detect HTTPS / Cloud Run / Reverse Proxy
    $is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
        || (isset($_SERVER['HTTP_X_FORWARDED_SSL']) && strtolower($_SERVER['HTTP_X_FORWARDED_SSL']) === 'on')
        || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
        || (isset($_SERVER['HTTP_HOST']) && strpos($_SERVER['HTTP_HOST'], 'run.app') !== false);

    // Support session ID passed via query param, POST body, or custom header
    // This provides 100% reliable persistence inside iframes where 3rd-party cookies are blocked by browsers
    $candidate_sid = $_COOKIE['PHPSESSID'] ?? $_GET['sid'] ?? $_POST['sid'] ?? $_SERVER['HTTP_X_SESSION_ID'] ?? null;
    if (!empty($candidate_sid) && preg_match('/^[a-zA-Z0-9,-]{1,128}$/', (string)$candidate_sid)) {
        session_id($candidate_sid);
    }

    // Set cookie parameters - SameSite=None + Secure is required for iframes
    if ($is_https) {
        session_set_cookie_params([
            'lifetime' => 86400 * 30,
            'path'     => '/',
            'domain'   => '',
            'secure'   => true,
            'httponly' => true,
            'samesite' => 'None'
        ]);
    } else {
        session_set_cookie_params([
            'lifetime' => 86400 * 30,
            'path'     => '/',
            'domain'   => '',
            'secure'   => false,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
    }

    ini_set('session.use_only_cookies', '0');
    ini_set('session.use_cookies', '1');

    session_start();
}

/**
 * Returns dynamic base URL for links and assets
 * Handles both XAMPP subfolder (/collegefix/) and root deployments (/)
 * Preserves sid parameter for seamless navigation inside iframes
 */
function base_url($path = '') {
    // Detect base folder path from script name
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $base = (strpos($script, '/collegefix/') !== false) ? '/collegefix/' : '/';
    $clean_path = ltrim($path, '/');
    $url = $base . $clean_path;
    
    // Check if path is a static asset (.css, .js, .png, etc.)
    $is_asset = preg_match('/\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot)$/i', $clean_path);
    if (!$is_asset && session_status() === PHP_SESSION_ACTIVE && session_id()) {
        $need_sid = !empty($_GET['sid']) || empty($_COOKIE[session_name()]);
        if ($need_sid && strpos($url, 'sid=') === false) {
            $sep = (strpos($url, '?') !== false) ? '&' : '?';
            $url .= $sep . 'sid=' . urlencode(session_id());
        }
    }
    
    return $url;
}

/**
 * Clean & sanitize user input for HTML output
 */
function clean($data) {
    if (is_array($data)) {
        return array_map('clean', $data);
    }
    return htmlspecialchars(trim((string)$data), ENT_QUOTES, 'UTF-8');
}

/**
 * Set flash message for alert notifications
 */
function set_flash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

/**
 * Get and clear flash message
 */
function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Check if user is authenticated
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Get current logged in user object or null
 */
function current_user() {
    if (!is_logged_in()) {
        return null;
    }
    return [
        'id'            => $_SESSION['user_id'],
        'name'          => $_SESSION['user_name'] ?? 'User',
        'email'         => $_SESSION['user_email'] ?? '',
        'role'          => $_SESSION['user_role'] ?? '',
        'student_id'    => $_SESSION['student_id'] ?? null,
        'staff_id'      => $_SESSION['staff_id'] ?? null,
        'department_id' => $_SESSION['department_id'] ?? null,
        'phone'         => $_SESSION['phone'] ?? null,
    ];
}

/**
 * Check if current user has specific role
 */
function has_role($role) {
    return is_logged_in() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
}

/**
 * Redirect helper
 */
function redirect($path) {
    $url = base_url($path);
    if (session_status() === PHP_SESSION_ACTIVE && session_id()) {
        $sep = (strpos($url, '?') !== false) ? '&' : '?';
        if (strpos($url, 'sid=') === false) {
            $url .= $sep . 'sid=' . urlencode(session_id());
        }
    }
    header("Location: " . $url);
    exit;
}

/**
 * Generates unique complaint code: CMP1005, CMP1006...
 */
function generate_complaint_code($conn) {
    try {
        // Query all existing complaint codes to reliably extract the highest numeric code
        $stmt = $conn->query("SELECT complaint_code FROM complaints WHERE complaint_code LIKE 'CMP%'");
        $max_num = 1000;
        while ($row = $stmt->fetch()) {
            if (preg_match('/^CMP(\d+)$/i', $row['complaint_code'], $matches)) {
                $num = (int)$matches[1];
                if ($num > $max_num) {
                    $max_num = $num;
                }
            }
        }
        
        $candidate_num = $max_num + 1;
        $check_stmt = $conn->prepare("SELECT COUNT(*) FROM complaints WHERE complaint_code = ?");
        
        // Ensure strictly unique code
        do {
            $code = 'CMP' . $candidate_num;
            $check_stmt->execute([$code]);
            $exists = (int)$check_stmt->fetchColumn() > 0;
            if ($exists) {
                $candidate_num++;
            }
        } while ($exists);

        return $code;
    } catch (Exception $e) {
        return 'CMP' . (time() % 900000 + 100000);
    }
}

/**
 * Create a system notification
 */
function create_notification($conn, $user_id, $complaint_id, $title, $message, $type = 'info') {
    try {
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, complaint_id, title, message, is_read, type, created_at) VALUES (?, ?, ?, ?, 0, ?, ?)");
        $now = date('Y-m-d H:i:s');
        $stmt->execute([$user_id, $complaint_id, $title, $message, $type, $now]);
        return true;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Get count of unread notifications for a user
 */
function get_unread_notifications_count($conn, $user_id) {
    try {
        $stmt = $conn->prepare("SELECT COUNT(*) as unread_count FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$user_id]);
        $row = $stmt->fetch();
        return (int)($row['unread_count'] ?? 0);
    } catch (Exception $e) {
        return 0;
    }
}

/**
 * Render visual badge for complaint status
 */
function get_status_badge($status) {
    $classes = [
        'Submitted'    => 'badge-submitted',
        'Under Review' => 'badge-review',
        'Assigned'     => 'badge-assigned',
        'In Progress'  => 'badge-progress',
        'Resolved'     => 'badge-resolved',
        'Closed'       => 'badge-closed',
        'Reopened'     => 'badge-reopened',
        'Rejected'     => 'badge-rejected',
    ];
    $cls = $classes[$status] ?? 'badge-secondary';
    return '<span class="status-badge ' . $cls . '">' . htmlspecialchars($status) . '</span>';
}

/**
 * Render visual badge for complaint priority
 */
function get_priority_badge($priority) {
    $classes = [
        'Low'       => 'priority-low',
        'Medium'    => 'priority-medium',
        'High'      => 'priority-high',
        'Emergency' => 'priority-emergency',
    ];
    $cls = $classes[$priority] ?? 'priority-medium';
    return '<span class="priority-badge ' . $cls . '">' . htmlspecialchars($priority) . '</span>';
}

/**
 * Helper aliases for backwards compatibility
 */
function priority_badge($priority) {
    return get_priority_badge($priority);
}

function status_badge($status) {
    return get_status_badge($status);
}

/**
 * Safe image upload validator and handler
 * Allows: JPG, JPEG, PNG, WEBP, GIF
 * Enforces size limit (25MB), unique filename, and directory existence
 */
function handle_image_upload($file_input_name, $subfolder = 'complaints') {
    if (!isset($_FILES[$file_input_name]) || $_FILES[$file_input_name]['error'] === UPLOAD_ERR_NO_FILE) {
        return ['success' => true, 'filename' => null];
    }

    $file = $_FILES[$file_input_name];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        switch ($file['error']) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return ['success' => false, 'error' => 'The uploaded photo exceeds the allowable file size limit (max 25MB). Please select a compressed photo.'];
            case UPLOAD_ERR_PARTIAL:
                return ['success' => false, 'error' => 'The file was only partially uploaded due to network interruption. Please try again.'];
            case UPLOAD_ERR_NO_FILE:
                return ['success' => true, 'filename' => null];
            case UPLOAD_ERR_NO_TMP_DIR:
                return ['success' => false, 'error' => 'Server temporary directory is missing. Please contact system admin.'];
            case UPLOAD_ERR_CANT_WRITE:
                return ['success' => false, 'error' => 'Failed to write uploaded image to disk.'];
            case UPLOAD_ERR_EXTENSION:
                return ['success' => false, 'error' => 'A server extension stopped the file upload.'];
            default:
                return ['success' => false, 'error' => 'Upload error (code ' . $file['error'] . '). Please try selecting the image again.'];
        }
    }

    // 25MB maximum
    $max_size = 25 * 1024 * 1024;
    if ($file['size'] > $max_size) {
        return ['success' => false, 'error' => 'Image file size exceeds the 25MB limit. Please choose a smaller photo.'];
    }

    // Check mime & extension
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($file_ext, $allowed_extensions)) {
        return ['success' => false, 'error' => 'Invalid file format (' . clean($file_ext) . '). Only JPG, PNG, WEBP, and GIF images are allowed.'];
    }

    // Verify actual image using getimagesize if available
    if (function_exists('getimagesize')) {
        $img_info = @getimagesize($file['tmp_name']);
        if ($img_info === false) {
            return ['success' => false, 'error' => 'The uploaded file is not a valid image.'];
        }
    }

    $target_dir = dirname(__DIR__) . '/uploads/' . trim($subfolder, '/') . '/';
    if (!is_dir($target_dir)) {
        @mkdir($target_dir, 0777, true);
    }
    @chmod($target_dir, 0777);

    $unique_name = 'img_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $file_ext;
    $destination = $target_dir . $unique_name;

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        @chmod($destination, 0666);
        return ['success' => true, 'filename' => $unique_name];
    } else {
        return ['success' => false, 'error' => 'Failed to save uploaded image. Check folder permissions.'];
    }
}

/**
 * Formats date into readable relative time (e.g., 2 hours ago) or clean format
 */
function format_datetime($datetime) {
    if (!$datetime) return 'N/A';
    $time = strtotime($datetime);
    return date('M d, Y h:i A', $time);
}

function time_ago($datetime) {
    if (!$datetime) return '';
    $timestamp = strtotime($datetime);
    $difference = time() - $timestamp;

    if ($difference < 60) {
        return 'Just now';
    } elseif ($difference < 3600) {
        return floor($difference / 60) . ' mins ago';
    } elseif ($difference < 86400) {
        return floor($difference / 3600) . ' hrs ago';
    } elseif ($difference < 604800) {
        return floor($difference / 86400) . ' days ago';
    } else {
        return date('M d, Y', $timestamp);
    }
}

/**
 * Fetch setting with fallback
 */
function get_setting($conn, $key, $default = '') {
    try {
        $stmt = $conn->prepare("SELECT setting_value FROM college_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? $row['setting_value'] : $default;
    } catch (Exception $e) {
        return $default;
    }
}
