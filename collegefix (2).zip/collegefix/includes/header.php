<?php
/**
 * CollegeFix - Common Page Header
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/functions.php';

$current_user = current_user();
$unread_count = 0;
if ($current_user) {
    $unread_count = get_unread_notifications_count($conn, $current_user['id']);
}

$page_title = $page_title ?? 'CollegeFix - Complaint Management System';
$active_menu = $active_menu ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo clean($page_title); ?></title>
  
  <!-- CSS Styles -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
  
  <!-- Lucide Icons -->
  <script src="<?php echo base_url('assets/js/lucide.min.js'); ?>"></script>
  
  <!-- Chart.js for Dashboards & Analytics -->
  <script src="<?php echo base_url('assets/js/chart.umd.min.js'); ?>"></script>
  
  <!-- html2pdf for Direct Client-Side PDF Report Generation -->
  <script src="<?php echo base_url('assets/js/html2pdf.bundle.min.js'); ?>"></script>
</head>
<body>
<div class="app-wrapper">
  
  <!-- Sidebar Navigation -->
  <?php require_once __DIR__ . '/sidebar.php'; ?>

  <!-- Main Application Body -->
  <div class="app-main">
    
    <!-- Topbar -->
    <header class="app-topbar">
      <div class="topbar-left">
        <button id="sidebarToggleBtn" class="sidebar-toggle-btn" title="Toggle Navigation">
          <i data-lucide="menu"></i>
        </button>
        <div class="topbar-college-name">
          <i data-lucide="graduation-cap" style="color: #2563eb;"></i>
          <span><?php echo clean(get_setting($conn, 'college_short_name', 'CollegeFix Campus')); ?></span>
        </div>
      </div>

      <div class="topbar-right">
        <!-- Notification Bell -->
        <?php 
          $notif_url = 'student/notifications.php';
          if ($current_user && $current_user['role'] === 'admin') $notif_url = 'admin/notifications.php';
          if ($current_user && $current_user['role'] === 'staff') $notif_url = 'staff/notifications.php';
        ?>
        <a href="<?php echo base_url($notif_url); ?>" class="topbar-action-btn" title="Notifications">
          <i data-lucide="bell"></i>
          <?php if ($unread_count > 0): ?>
            <span class="topbar-badge"><?php echo $unread_count > 9 ? '9+' : $unread_count; ?></span>
          <?php endif; ?>
        </a>

        <?php if ($current_user): ?>
          <div class="topbar-user-pill" style="display: flex; align-items: center; gap: 8px; padding: 4px 12px; background: #f8fafc; border: 1px solid var(--border-color); border-radius: 20px; font-size: 13px;">
            <span style="width: 26px; height: 26px; border-radius: 50%; background: #2563eb; color: #ffffff; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; font-size: 12px;">
              <?php echo strtoupper(substr($current_user['name'] ?? 'U', 0, 1)); ?>
            </span>
            <span style="font-weight: 600; color: var(--text-main); font-size: 12px;">
              <?php echo clean($current_user['name'] ?? 'User'); ?>
            </span>
            <span class="sidebar-role-badge role-<?php echo htmlspecialchars($current_user['role'] ?? 'student'); ?>" style="font-size: 10px; padding: 2px 6px;">
              <?php echo htmlspecialchars(strtoupper($current_user['role'] ?? '')); ?>
            </span>
          </div>
        <?php endif; ?>
      </div>
    </header>

    <!-- Page Content Container -->
    <main class="app-content">
      
      <!-- Flash Messages -->
      <?php $flash = get_flash(); if ($flash): ?>
        <div class="alert alert-<?php echo clean($flash['type']); ?> alert-dismissible">
          <span><?php echo clean($flash['message']); ?></span>
          <button type="button" class="alert-close" onclick="this.parentElement.remove()">&times;</button>
        </div>
      <?php endif; ?>
