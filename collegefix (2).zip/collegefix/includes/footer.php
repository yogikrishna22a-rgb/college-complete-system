<?php
/**
 * CollegeFix - Common Page Footer
 */
?>
    </main>
    
    <!-- Footer Bar -->
    <footer style="padding: 16px 28px; border-top: 1px solid var(--border-color); font-size: 13px; color: var(--text-muted); background: #ffffff; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
      <div>
        <strong>CollegeFix</strong> &copy; <?php echo date('Y'); ?> &bull; College Complaint & Maintenance Management System
      </div>
      <div>
        <span>Environment: <strong>PHP 8+ &bull; MySQL / PDO</strong></span> &bull;
        <a href="<?php echo base_url('README.md'); ?>" style="color: #2563eb; text-decoration: none;" target="_blank">Setup Documentation</a>
      </div>
    </footer>

  </div> <!-- /.app-main -->
</div> <!-- /.app-wrapper -->

<!-- Scripts -->
<script src="<?php echo base_url('assets/js/script.js'); ?>"></script>
<script>
  // Initialize Lucide Icons
  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }
</script>
</body>
</html>
