<?php
/**
 * CollegeFix - Role-Based Access Control Middleware
 */

require_once __DIR__ . '/functions.php';

function require_auth($allowed_roles = []) {
    if (!is_logged_in()) {
        set_flash('danger', 'Please log in to access this page.');
        redirect('auth/login.php');
    }

    if (!empty($allowed_roles)) {
        $user_role = $_SESSION['user_role'] ?? '';
        if (!in_array($user_role, (array)$allowed_roles)) {
            set_flash('danger', 'Access denied. You do not have permission to view that section.');
            
            // Redirect based on current role
            if ($user_role === 'admin') {
                redirect('admin/dashboard.php');
            } elseif ($user_role === 'student') {
                redirect('student/dashboard.php');
            } elseif ($user_role === 'staff') {
                redirect('staff/dashboard.php');
            } else {
                redirect('auth/login.php');
            }
        }
    }
}
