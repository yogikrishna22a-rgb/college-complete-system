/**
 * CollegeFix - Core Front-end Interactions
 */

document.addEventListener('DOMContentLoaded', () => {
  // Mobile sidebar toggle
  const toggleBtn = document.getElementById('sidebarToggleBtn');
  const sidebar = document.getElementById('appSidebar');

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      sidebar.classList.toggle('show');
    });

    // Close on body click outside
    document.addEventListener('click', (e) => {
      if (window.innerWidth <= 768 && sidebar.classList.contains('show')) {
        if (!sidebar.contains(e.target) && e.target !== toggleBtn) {
          sidebar.classList.remove('show');
        }
      }
    });
  }

  // Star rating selector
  const starContainers = document.querySelectorAll('.rating-stars');
  starContainers.forEach(container => {
    const stars = container.querySelectorAll('.star');
    const input = document.getElementById(container.dataset.input || 'ratingInput');

    stars.forEach((star, index) => {
      star.addEventListener('mouseenter', () => {
        stars.forEach((s, i) => {
          s.classList.toggle('hovered', i <= index);
        });
      });

      star.addEventListener('mouseleave', () => {
        stars.forEach(s => s.classList.remove('hovered'));
      });

      star.addEventListener('click', () => {
        const val = index + 1;
        if (input) input.value = val;
        stars.forEach((s, i) => {
          s.classList.toggle('selected', i < val);
        });
      });
    });
  });

  // Modal helpers
  window.openModal = function(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.add('show');
  };

  window.closeModal = function(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.remove('show');
  };

  // Close modals on backdrop click
  document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        backdrop.classList.remove('show');
      }
    });
  });

  // Demo account autofill for login page
  window.fillDemo = function(role, autoSubmit = false) {
    const emailInput = document.getElementById('email');
    const passInput = document.getElementById('password');

    if (role === 'admin') {
      if (emailInput) emailInput.value = 'admin@collegefix.edu';
      if (passInput) passInput.value = 'Admin@123';
    } else if (role === 'student') {
      if (emailInput) emailInput.value = 'student@collegefix.edu';
      if (passInput) passInput.value = 'Student@123';
    } else if (role === 'student2') {
      if (emailInput) emailInput.value = 'priya@collegefix.edu';
      if (passInput) passInput.value = 'Student@123';
    } else if (role === 'staff') {
      if (emailInput) emailInput.value = 'staff@collegefix.edu';
      if (passInput) passInput.value = 'Staff@123';
    }

    if (autoSubmit) {
      const form = document.querySelector('form');
      if (form) form.submit();
    }
  };

  // Session ID preservation for cross-site iframes
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const sidFromUrl = urlParams.get('sid');
    if (sidFromUrl) {
      sessionStorage.setItem('cf_sid', sidFromUrl);
    }
    const storedSid = sessionStorage.getItem('cf_sid');
    if (storedSid) {
      // Ensure all forms carry the sid input
      document.querySelectorAll('form').forEach(form => {
        if (!form.querySelector('input[name="sid"]')) {
          const hidden = document.createElement('input');
          hidden.type = 'hidden';
          hidden.name = 'sid';
          hidden.value = storedSid;
          form.appendChild(hidden);
        }
      });

      // Ensure internal links keep the sid
      document.querySelectorAll('a[href]').forEach(a => {
        const href = a.getAttribute('href');
        if (href && !href.startsWith('#') && !href.startsWith('javascript:') && !href.startsWith('http')) {
          if (!href.includes('sid=')) {
            const sep = href.includes('?') ? '&' : '?';
            a.setAttribute('href', href + sep + 'sid=' + encodeURIComponent(storedSid));
          }
        }
      });
    }
  } catch (err) {
    console.debug('Session storage check completed', err);
  }

  // Auto-dismiss alert boxes after 6s
  setTimeout(() => {
    document.querySelectorAll('.alert-dismissible').forEach(alert => {
      alert.style.transition = 'opacity 0.5s ease';
      alert.style.opacity = '0';
      setTimeout(() => alert.remove(), 500);
    });
  }, 6000);

  // Initialize Lucide Icons safely
  if (typeof window.lucide !== 'undefined' && typeof window.lucide.createIcons === 'function') {
    try {
      window.lucide.createIcons();
    } catch (e) {
      console.warn('Lucide icons:', e);
    }
  }
});
