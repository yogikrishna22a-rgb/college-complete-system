<?php
/**
 * CollegeFix - Admin Complaint Details & Assignment Management
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

$user = current_user();
$complaint_id = (int)($_GET['id'] ?? 0);

if (!$complaint_id) {
    set_flash('danger', 'Complaint not found.');
    redirect('admin/complaints.php');
}

// Handle Admin Actions (Assign, Status Change, Priority Change, Notes)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // 1. Assign / Reassign Staff or Remove Assignment
    if ($action === 'assign_staff' || $action === 'unassign_staff') {
        $staff_param = trim($_POST['staff_id'] ?? '');
        $admin_notes = trim($_POST['admin_notes'] ?? '');
        $now = date('Y-m-d H:i:s');

        if ($action === 'unassign_staff' || $staff_param === 'unassign') {
            try {
                // Remove assigned staff
                $stmt_up = $conn->prepare("
                    UPDATE complaints 
                    SET assigned_staff_id = NULL, 
                        status = CASE WHEN status = 'Assigned' THEN 'Under Review' ELSE status END, 
                        updated_at = ?
                    WHERE id = ?
                ");
                $stmt_up->execute([$now, $complaint_id]);

                // Log in timeline
                $log_note = "Assigned staff removed by administrator." . ($admin_notes ? " Note: {$admin_notes}" : "");
                $stmt_tl = $conn->prepare("
                    INSERT INTO complaint_updates (complaint_id, user_id, update_type, status, notes, created_at)
                    VALUES (?, ?, 'Staff Unassignment', 'Under Review', ?, ?)
                ");
                $stmt_tl->execute([$complaint_id, $user['id'], $log_note, $now]);

                set_flash('success', 'Assigned staff has been successfully removed from this complaint.');
                redirect('admin/complaint_view.php?id=' . $complaint_id);
            } catch (Exception $e) {
                set_flash('danger', 'Error removing assigned staff: ' . $e->getMessage());
            }
        } else {
            $staff_id = (int)$staff_param;
            if (!$staff_id) {
                set_flash('danger', 'Please choose a maintenance staff technician to assign.');
            } else {
                try {
                    // Fetch staff name
                    $st_stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ? AND role = 'staff'");
                    $st_stmt->execute([$staff_id]);
                    $staff_info = $st_stmt->fetch();

                    if ($staff_info) {
                        // Update complaint
                        $stmt_up = $conn->prepare("
                            UPDATE complaints 
                            SET assigned_staff_id = ?, status = CASE WHEN status = 'Submitted' THEN 'Assigned' ELSE status END, updated_at = ?
                            WHERE id = ?
                        ");
                        $stmt_up->execute([$staff_id, $now, $complaint_id]);

                        // Log in timeline
                        $log_note = "Assigned to {$staff_info['name']}." . ($admin_notes ? " Directive: {$admin_notes}" : "");
                        $stmt_tl = $conn->prepare("
                            INSERT INTO complaint_updates (complaint_id, user_id, update_type, status, notes, created_at)
                            VALUES (?, ?, 'Staff Assignment', 'Assigned', ?, ?)
                        ");
                        $stmt_tl->execute([$complaint_id, $user['id'], $log_note, $now]);

                        // Fetch complaint info
                        $c_stmt = $conn->prepare("SELECT complaint_code, title, user_id, priority FROM complaints WHERE id = ?");
                        $c_stmt->execute([$complaint_id]);
                        $c_row = $c_stmt->fetch();

                        // Notify Staff
                        create_notification(
                            $conn,
                            $staff_id,
                            $complaint_id,
                            "New Task Assigned: #{$c_row['complaint_code']}",
                            "You have been assigned to #{$c_row['complaint_code']} ({$c_row['title']}). Priority: {$c_row['priority']}.",
                            ($c_row['priority'] === 'Emergency') ? 'danger' : 'info'
                        );

                        // Notify Student
                        create_notification(
                            $conn,
                            $c_row['user_id'],
                            $complaint_id,
                            "Staff Assigned to #{$c_row['complaint_code']}",
                            "Technician {$staff_info['name']} has been assigned to your ticket.",
                            'info'
                        );

                        set_flash('success', "Ticket successfully assigned to {$staff_info['name']}.");
                        redirect('admin/complaint_view.php?id=' . $complaint_id);
                    }
                } catch (Exception $e) {
                    set_flash('danger', 'Error assigning staff: ' . $e->getMessage());
                }
            }
        }
    }

    // 2. Change Status & Priority
    elseif ($action === 'update_status_priority') {
        $new_status   = $_POST['status'] ?? '';
        $new_priority = $_POST['priority'] ?? '';
        $status_notes = trim($_POST['status_notes'] ?? '');

        if (!empty($new_status)) {
            try {
                $now = date('Y-m-d H:i:s');
                $stmt = $conn->prepare("
                    UPDATE complaints 
                    SET status = ?, priority = ?, updated_at = ?
                    WHERE id = ?
                ");
                $stmt->execute([$new_status, $new_priority, $now, $complaint_id]);

                // Log timeline
                $tl_note = "Status changed to '{$new_status}', Priority set to '{$new_priority}'." . ($status_notes ? " Reason: {$status_notes}" : "");
                $stmt_tl = $conn->prepare("
                    INSERT INTO complaint_updates (complaint_id, user_id, update_type, status, notes, created_at)
                    VALUES (?, ?, 'Admin Status Update', ?, ?, ?)
                ");
                $stmt_tl->execute([$complaint_id, $user['id'], $new_status, $tl_note, $now]);

                // Notify student
                $c_stmt = $conn->prepare("SELECT complaint_code, user_id, assigned_staff_id FROM complaints WHERE id = ?");
                $c_stmt->execute([$complaint_id]);
                $c_row = $c_stmt->fetch();

                if ($c_row) {
                    create_notification(
                        $conn,
                        $c_row['user_id'],
                        $complaint_id,
                        "Status Updated: #{$c_row['complaint_code']}",
                        "Your ticket status has been updated to {$new_status} by the administration.",
                        ($new_status === 'Rejected') ? 'danger' : 'info'
                    );

                    if (!empty($c_row['assigned_staff_id'])) {
                        create_notification(
                            $conn,
                            $c_row['assigned_staff_id'],
                            $complaint_id,
                            "Ticket Updated: #{$c_row['complaint_code']}",
                            "Admin updated ticket #{$c_row['complaint_code']} status to {$new_status}.",
                            'info'
                        );
                    }
                }

                set_flash('success', 'Complaint status & priority updated successfully.');
                redirect('admin/complaint_view.php?id=' . $complaint_id);
            } catch (Exception $e) {
                set_flash('danger', 'Error updating complaint: ' . $e->getMessage());
            }
        }
    }
}

// Fetch complaint with joins
try {
    $stmt = $conn->prepare("
        SELECT c.*, cat.name as category_name, d.name as department_name, 
               u.name as student_name, u.email as student_email, u.phone as student_phone, u.student_id as student_roll,
               s.name as staff_name, s.phone as staff_phone, s.specialization as staff_spec
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN users u ON c.user_id = u.id
        LEFT JOIN users s ON c.assigned_staff_id = s.id
        WHERE c.id = ?
    ");
    $stmt->execute([$complaint_id]);
    $complaint = $stmt->fetch();

    if (!$complaint) {
        set_flash('danger', 'Complaint not found.');
        redirect('admin/complaints.php');
    }

    // Fetch timeline updates
    $stmt_up = $conn->prepare("
        SELECT cu.*, u.name as user_name, u.role as user_role
        FROM complaint_updates cu
        LEFT JOIN users u ON cu.user_id = u.id
        WHERE cu.complaint_id = ?
        ORDER BY cu.created_at ASC
    ");
    $stmt_up->execute([$complaint_id]);
    $timeline_updates = $stmt_up->fetchAll();

    // Fetch staff members for assignment dropdown
    $staff_members = $conn->query("
        SELECT id, name, specialization, phone,
               (SELECT COUNT(*) FROM complaints WHERE assigned_staff_id = users.id AND status IN ('Assigned', 'In Progress')) as active_tasks
        FROM users 
        WHERE role = 'staff' AND status = 'Active' 
        ORDER BY active_tasks ASC, name ASC
    ")->fetchAll();

    // Fetch student feedback if any
    $stmt_fb = $conn->prepare("SELECT * FROM feedback WHERE complaint_id = ?");
    $stmt_fb->execute([$complaint_id]);
    $feedback = $stmt_fb->fetch();

} catch (Exception $e) {
    set_flash('danger', 'Error loading complaint: ' . $e->getMessage());
    redirect('admin/complaints.php');
}

// Visual status tracker computation
$pipeline = ['Submitted', 'Reviewed', 'Assigned', 'In Progress', 'Resolved', 'Closed'];
$status_indices = [
    'Submitted'    => 0,
    'Under Review' => 1,
    'Reviewed'     => 1,
    'Assigned'     => 2,
    'In Progress'  => 3,
    'Resolved'     => 4,
    'Closed'       => 5,
    'Reopened'     => 3,
    'Rejected'     => -1,
];
$current_step_idx = $status_indices[$complaint['status']] ?? 0;

$page_title = 'Manage Complaint #' . clean($complaint['complaint_code']) . ' - Admin';
$active_menu = 'complaints';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <div style="display: flex; align-items: center; gap: 10px;">
      <h1>Complaint #<?php echo clean($complaint['complaint_code']); ?></h1>
      <?php echo get_status_badge($complaint['status']); ?>
      <?php echo get_priority_badge($complaint['priority']); ?>
    </div>
    <p>Submitted: <?php echo format_datetime($complaint['created_at']); ?> &bull; Reported by: <strong><?php echo clean($complaint['student_name']); ?></strong> (<?php echo clean($complaint['student_roll'] ?? 'Student'); ?>)</p>
  </div>
  <div class="page-actions">
    <a href="<?php echo base_url('admin/complaints.php'); ?>" class="btn btn-secondary">
      <i data-lucide="arrow-left"></i>
      <span>Back to List</span>
    </a>
  </div>
</div>

<!-- Visual Timeline Card -->
<div class="content-card" style="padding: 24px;">
  <h3 style="font-size: 13px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; margin-bottom: 20px;">
    Complaint Lifecycle Progression
  </h3>

  <?php if ($complaint['status'] === 'Rejected'): ?>
    <div class="alert alert-danger" style="margin-bottom: 0;">
      <i data-lucide="x-circle"></i>
      <span>This complaint is currently <strong>REJECTED</strong>. You can re-open or assign it to a staff member below if reconsidered.</span>
    </div>
  <?php else: ?>
    <div class="timeline-tracker">
      <?php foreach ($pipeline as $idx => $step_name): ?>
        <?php 
          $is_completed = $current_step_idx > $idx;
          $is_active = $current_step_idx === $idx;
          $step_class = $is_completed ? 'completed' : ($is_active ? 'active' : '');
        ?>
        <div class="timeline-step <?php echo $step_class; ?>">
          <div class="timeline-icon">
            <?php if ($is_completed): ?>
              <i data-lucide="check" style="width: 16px; height: 16px;"></i>
            <?php else: ?>
              <span><?php echo ($idx + 1); ?></span>
            <?php endif; ?>
          </div>
          <div class="timeline-label"><?php echo $step_name; ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<div class="complaint-view-grid">
  
  <!-- Left Column: Details & Audit Feed -->
  <div>
    
    <!-- Complaint Overview -->
    <div class="content-card">
      <div class="card-header">
        <h3><?php echo clean($complaint['title']); ?></h3>
        <span style="font-size: 13px; color: var(--text-muted);">
          Category: <strong><?php echo clean($complaint['category_name']); ?></strong>
        </span>
      </div>
      <div class="card-body">
        
        <h4 style="font-size: 13px; font-weight: 600; color: var(--text-muted); margin-bottom: 6px;">Description</h4>
        <div style="font-size: 14px; line-height: 1.6; color: var(--text-main); background: #f8fafc; padding: 14px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); white-space: pre-line;">
          <?php echo clean($complaint['description']); ?>
        </div>

        <?php if (!empty($complaint['problem_image'])): ?>
          <h4 style="font-size: 13px; font-weight: 600; color: var(--text-muted); margin-top: 18px; margin-bottom: 8px;">Uploaded Problem Photo</h4>
          <div class="image-preview-card">
            <img src="<?php echo base_url('uploads/complaints/' . $complaint['problem_image']); ?>" alt="Problem image" onclick="window.open(this.src, '_blank')">
          </div>
        <?php endif; ?>

        <!-- Resolution Evidence if Staff has resolved -->
        <?php if (!empty($complaint['resolution_image']) || !empty($complaint['resolution_notes'])): ?>
          <div style="margin-top: 20px; padding: 16px; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: var(--radius-sm);">
            <h4 style="font-size: 13px; font-weight: 700; color: #065f46; margin-bottom: 6px;">Staff Resolution Submission</h4>
            <?php if (!empty($complaint['resolution_image'])): ?>
              <div class="image-preview-card" style="max-width: 280px; margin-bottom: 10px;">
                <img src="<?php echo base_url('uploads/resolutions/' . $complaint['resolution_image']); ?>" alt="Resolution image" onclick="window.open(this.src, '_blank')">
              </div>
            <?php endif; ?>
            <p style="font-size: 13px; color: #047857;">
              <strong>Technician Notes:</strong> <?php echo clean($complaint['resolution_notes']); ?>
            </p>
          </div>
        <?php endif; ?>

        <!-- Student Feedback if Closed -->
        <?php if ($feedback): ?>
          <div style="margin-top: 20px; padding: 16px; background: #eff6ff; border: 1px solid #bfdbfe; border-radius: var(--radius-sm);">
            <h4 style="font-size: 13px; font-weight: 700; color: #1e40af; margin-bottom: 6px;">Student Service Evaluation</h4>
            <div style="color: #f59e0b; font-size: 16px; margin-bottom: 4px;">
              <?php echo str_repeat('&#9733;', $feedback['rating']); ?>
              <span style="font-size: 12px; color: var(--text-muted);">(<?php echo $feedback['rating']; ?>/5 &bull; <?php echo $feedback['is_satisfied'] ? 'Satisfied' : 'Unsatisfied'; ?>)</span>
            </div>
            <?php if (!empty($feedback['comments'])): ?>
              <p style="font-size: 13px; color: var(--text-main); font-style: italic;">
                "<?php echo clean($feedback['comments']); ?>"
              </p>
            <?php endif; ?>
          </div>
        <?php endif; ?>

      </div>
    </div>

    <!-- Timeline Updates & Audit History -->
    <div class="content-card">
      <div class="card-header">
        <h3>Audit Log & Updates History</h3>
      </div>
      <div class="card-body">
        <div class="updates-feed">
          <?php foreach ($timeline_updates as $up): ?>
            <div class="update-item">
              <div class="update-dot"></div>
              <div class="update-content">
                <div class="update-header">
                  <span class="update-author">
                    <?php echo clean($up['user_name'] ?? 'System'); ?> 
                    <span style="font-size: 10px; color: var(--text-muted); text-transform: uppercase;">
                      (<?php echo clean($up['user_role'] ?? 'System'); ?>)
                    </span>
                  </span>
                  <span class="update-time"><?php echo format_datetime($up['created_at']); ?></span>
                </div>
                <div style="font-size: 13px; color: var(--text-main); margin-top: 4px;">
                  <?php echo clean($up['notes']); ?>
                </div>
                <?php if (!empty($up['proof_image'])): ?>
                  <div style="margin-top: 8px;">
                    <img src="<?php echo base_url('uploads/resolutions/' . $up['proof_image']); ?>" alt="Proof" style="max-height: 120px; border-radius: 4px; border: 1px solid var(--border-color); cursor: pointer;" onclick="window.open(this.src, '_blank')">
                  </div>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

  </div>

  <!-- Right Column: Administrative Controls -->
  <div>
    
    <!-- Staff Assignment Action Box -->
    <div class="content-card" style="border-top: 4px solid #2563eb;">
      <div class="card-header">
        <h3>Assign Maintenance Technician</h3>
      </div>
      <div class="card-body">
        <form action="<?php echo base_url('admin/complaint_view.php?id=' . $complaint_id); ?>" method="POST">
          <input type="hidden" name="action" value="assign_staff">

          <div class="form-group">
            <label for="staff_id" class="form-label">Select Staff Member</label>
            <select name="staff_id" id="staff_id" class="form-control" required>
              <option value="">-- Choose Technician --</option>
              <?php if (!empty($complaint['assigned_staff_id'])): ?>
                <option value="unassign" style="color: #dc2626; font-weight: 600;">-- Remove Assigned Staff (Unassign) --</option>
              <?php endif; ?>
              <?php foreach ($staff_members as $sm): ?>
                <option value="<?php echo $sm['id']; ?>" <?php echo ($complaint['assigned_staff_id'] == $sm['id']) ? 'selected' : ''; ?>>
                  <?php echo clean($sm['name']); ?> - <?php echo clean($sm['specialization']); ?> (<?php echo $sm['active_tasks']; ?> active)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label for="admin_notes" class="form-label">Instructions / Directive (Optional)</label>
            <textarea name="admin_notes" id="admin_notes" class="form-control" rows="2" placeholder="e.g. Inspect room 204 switchboard before 2 PM today..."></textarea>
          </div>

          <button type="submit" class="btn btn-primary" style="width: 100%;">
            <i data-lucide="user-check"></i>
            <span><?php echo empty($complaint['assigned_staff_id']) ? 'Assign Ticket' : 'Reassign Technician'; ?></span>
          </button>
        </form>

        <?php if (!empty($complaint['assigned_staff_id'])): ?>
          <form action="<?php echo base_url('admin/complaint_view.php?id=' . $complaint_id); ?>" method="POST" style="margin-top: 10px;" onsubmit="return confirm('Are you sure you want to remove the assigned staff from this complaint?');">
            <input type="hidden" name="action" value="unassign_staff">
            <button type="submit" class="btn btn-secondary" style="width: 100%; color: #dc2626; border-color: #fecaca; background: #fff5f5;">
              <i data-lucide="user-minus"></i>
              <span>Remove Assigned Staff</span>
            </button>
          </form>
        <?php endif; ?>
      </div>
    </div>

    <!-- Status & Priority Override Box -->
    <div class="content-card">
      <div class="card-header">
        <h3>Status & Priority Override</h3>
      </div>
      <div class="card-body">
        <form action="<?php echo base_url('admin/complaint_view.php?id=' . $complaint_id); ?>" method="POST">
          <input type="hidden" name="action" value="update_status_priority">

          <div class="form-group">
            <label for="status" class="form-label">Complaint Status</label>
            <select name="status" id="status" class="form-control" required>
              <option value="Submitted" <?php echo ($complaint['status'] === 'Submitted') ? 'selected' : ''; ?>>Submitted</option>
              <option value="Under Review" <?php echo ($complaint['status'] === 'Under Review') ? 'selected' : ''; ?>>Under Review</option>
              <option value="Assigned" <?php echo ($complaint['status'] === 'Assigned') ? 'selected' : ''; ?>>Assigned</option>
              <option value="In Progress" <?php echo ($complaint['status'] === 'In Progress') ? 'selected' : ''; ?>>In Progress</option>
              <option value="Resolved" <?php echo ($complaint['status'] === 'Resolved') ? 'selected' : ''; ?>>Resolved</option>
              <option value="Closed" <?php echo ($complaint['status'] === 'Closed') ? 'selected' : ''; ?>>Closed (Completed)</option>
              <option value="Rejected" <?php echo ($complaint['status'] === 'Rejected') ? 'selected' : ''; ?>>Rejected (Invalid / Duplicate)</option>
            </select>
          </div>

          <div class="form-group">
            <label for="priority" class="form-label">Priority Level</label>
            <select name="priority" id="priority" class="form-control" required>
              <option value="Low" <?php echo ($complaint['priority'] === 'Low') ? 'selected' : ''; ?>>Low</option>
              <option value="Medium" <?php echo ($complaint['priority'] === 'Medium') ? 'selected' : ''; ?>>Medium</option>
              <option value="High" <?php echo ($complaint['priority'] === 'High') ? 'selected' : ''; ?>>High</option>
              <option value="Emergency" <?php echo ($complaint['priority'] === 'Emergency') ? 'selected' : ''; ?>>Emergency</option>
            </select>
          </div>

          <div class="form-group">
            <label for="status_notes" class="form-label">Administrative Log Note</label>
            <textarea name="status_notes" id="status_notes" class="form-control" rows="2" placeholder="Explain reason for status or priority modification..."></textarea>
          </div>

          <button type="submit" class="btn btn-secondary" style="width: 100%;">
            <i data-lucide="check"></i>
            <span>Update Status & Priority</span>
          </button>
        </form>
      </div>
    </div>

    <!-- Location & Student Info Cards -->
    <div class="content-card">
      <div class="card-header">
        <h3>Campus Location</h3>
      </div>
      <div class="card-body" style="font-size: 13px; display: flex; flex-direction: column; gap: 10px;">
        <div>
          <span style="color: var(--text-muted); display: block; font-size: 11px;">CAMPUS</span>
          <strong><?php echo clean($complaint['building']); ?></strong>
        </div>
        <div>
          <span style="color: var(--text-muted); display: block; font-size: 11px;">FLOOR & ROOM</span>
          <strong><?php echo clean($complaint['floor'] . ' &bull; ' . $complaint['room_number']); ?></strong>
        </div>
        <?php if (!empty($complaint['department_name'])): ?>
          <div>
            <span style="color: var(--text-muted); display: block; font-size: 11px;">CLASS / SECTION</span>
            <strong><?php echo clean($complaint['department_name']); ?></strong>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Student Reporter Info Card -->
    <div class="content-card">
      <div class="card-header">
        <h3>Student Information</h3>
      </div>
      <div class="card-body">
        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
          <div class="sidebar-user-avatar" style="width: 40px; height: 40px; font-size: 15px;">
            <?php echo strtoupper(substr($complaint['student_name'] ?? 'S', 0, 1)); ?>
          </div>
          <div>
            <h4 style="font-size: 14px; font-weight: 700;"><?php echo clean($complaint['student_name']); ?></h4>
            <span style="font-size: 12px; color: var(--text-muted);">Roll: <?php echo clean($complaint['student_roll'] ?? 'N/A'); ?></span>
          </div>
        </div>
        <div style="font-size: 12px; color: var(--text-muted); display: flex; flex-direction: column; gap: 6px;">
          <div>Email: <strong><?php echo clean($complaint['student_email']); ?></strong></div>
          <?php if (!empty($complaint['student_phone'])): ?>
            <div>Phone: <strong><?php echo clean($complaint['student_phone']); ?></strong></div>
          <?php endif; ?>
        </div>
      </div>
    </div>

  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
