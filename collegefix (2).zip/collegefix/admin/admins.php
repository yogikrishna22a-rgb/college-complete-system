<?php
/**
 * CollegeFix - Administrator Accounts Management
 * Manage, Create, and Edit System Administrator Accounts
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

$current_user = current_user();
$current_admin_id = $current_user['id'];
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // 1. Create New Admin Account
    if ($action === 'create_admin') {
        $name     = trim($_POST['name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';
        $status   = in_array($_POST['status'] ?? '', ['Active', 'Suspended']) ? $_POST['status'] : 'Active';

        if (empty($name) || empty($email) || empty($password)) {
            $error = 'Please fill in all required fields (Name, Email, and Password).';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters long.';
        } elseif ($password !== $confirm) {
            $error = 'Password and Confirm Password do not match.';
        } else {
            try {
                // Check if email already exists in system
                $chk = $conn->prepare("SELECT id FROM users WHERE email = ?");
                $chk->execute([$email]);
                if ($chk->fetch()) {
                    $error = 'An account with email "' . clean($email) . '" already exists.';
                } else {
                    $hashed_pwd = password_hash($password, PASSWORD_BCRYPT);
                    $now = date('Y-m-d H:i:s');
                    $stmt = $conn->prepare("
                        INSERT INTO users (name, email, password, role, status, created_at)
                        VALUES (?, ?, ?, 'admin', ?, ?)
                    ");
                    $stmt->execute([$name, $email, $hashed_pwd, $status, $now]);

                    set_flash('success', 'New administrator account for "' . clean($name) . '" (' . clean($email) . ') created successfully.');
                    redirect('admin/admins.php');
                }
            } catch (Exception $e) {
                $error = 'Database error creating administrator: ' . $e->getMessage();
            }
        }
    }

    // 2. Edit Existing Admin Account
    elseif ($action === 'edit_admin') {
        $target_id = (int)($_POST['admin_id'] ?? 0);
        $name      = trim($_POST['name'] ?? '');
        $email     = trim($_POST['email'] ?? '');
        $password  = $_POST['password'] ?? '';
        $status    = $_POST['status'] ?? 'Active';

        if ($target_id <= 0 || empty($name) || empty($email)) {
            $error = 'Administrator ID, Name, and Email are required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            try {
                // Check if email is used by another user
                $chk = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                $chk->execute([$email, $target_id]);
                if ($chk->fetch()) {
                    $error = 'Another user is already using email address "' . clean($email) . '".';
                } else {
                    // Prevent logged in admin from suspending their own active account
                    if ($target_id === $current_admin_id && $status === 'Suspended') {
                        $status = 'Active'; // Keep active for self
                    }

                    if (!empty($password)) {
                        if (strlen($password) < 6) {
                            $error = 'New password must be at least 6 characters long.';
                        } else {
                            $hashed_pwd = password_hash($password, PASSWORD_BCRYPT);
                            $stmt = $conn->prepare("
                                UPDATE users 
                                SET name = ?, email = ?, password = ?, status = ?
                                WHERE id = ? AND role = 'admin'
                            ");
                            $stmt->execute([$name, $email, $hashed_pwd, $status, $target_id]);
                        }
                    } else {
                        // Keep current password
                        $stmt = $conn->prepare("
                            UPDATE users 
                            SET name = ?, email = ?, status = ?
                            WHERE id = ? AND role = 'admin'
                        ");
                        $stmt->execute([$name, $email, $status, $target_id]);
                    }

                    if (empty($error)) {
                        // If updating current logged in admin, sync session variables
                        if ($target_id === $current_admin_id) {
                            $_SESSION['user_name'] = $name;
                            $_SESSION['user_email'] = $email;
                        }

                        set_flash('success', 'Administrator account "' . clean($name) . '" updated successfully.');
                        redirect('admin/admins.php');
                    }
                }
            } catch (Exception $e) {
                $error = 'Error updating administrator: ' . $e->getMessage();
            }
        }
    }

    // 3. Toggle Admin Status
    elseif ($action === 'toggle_status') {
        $target_id = (int)($_POST['id'] ?? 0);
        $curr_stat = $_POST['current_status'] ?? 'Active';

        if ($target_id === $current_admin_id) {
            $error = 'Security safeguard: You cannot suspend your own active administrator account.';
        } else {
            $new_status = ($curr_stat === 'Active') ? 'Suspended' : 'Active';
            try {
                $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'admin'");
                $stmt->execute([$new_status, $target_id]);
                set_flash('success', 'Administrator status updated to ' . $new_status . '.');
                redirect('admin/admins.php');
            } catch (Exception $e) {
                $error = 'Error toggling administrator status: ' . $e->getMessage();
            }
        }
    }
}

// Fetch all administrators
try {
    $admins = $conn->query("
        SELECT id, name, email, status, created_at
        FROM users
        WHERE role = 'admin'
        ORDER BY id ASC
    ")->fetchAll();
} catch (Exception $e) {
    $admins = [];
    $error = 'Error fetching administrators: ' . $e->getMessage();
}

$page_title = 'Administrator Accounts - CollegeFix Admin';
$active_menu = 'admins';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <div style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--text-muted); margin-bottom: 4px;">
      <span>Admin Dashboard</span>
      <span>·</span>
      <span>Access Control</span>
      <span>·</span>
      <span>Security & Credentials</span>
    </div>
    <h1>Administrator Accounts Management</h1>
    <p>Create new campus administrators, edit profile credentials, manage roles, and enforce security policies.</p>
  </div>
  
  <div class="page-actions">
    <button type="button" class="btn btn-primary" onclick="openModal('createAdminModal')">
      <i data-lucide="user-plus"></i>
      <span>Add New Administrator</span>
    </button>
  </div>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger" style="margin-bottom: 20px;">
    <?php echo clean($error); ?>
  </div>
<?php endif; ?>

<!-- Quick Stats -->
<div class="stats-grid" style="margin-bottom: 24px; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
  <div class="stat-card stat-primary">
    <div class="stat-content">
      <h3>Total Administrators</h3>
      <div class="stat-number"><?php echo count($admins); ?></div>
      <div class="stat-subtext">System super-users</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="shield-check"></i>
    </div>
  </div>

  <div class="stat-card stat-success">
    <div class="stat-content">
      <h3>Active Administrators</h3>
      <div class="stat-number">
        <?php echo count(array_filter($admins, fn($a) => $a['status'] === 'Active')); ?>
      </div>
      <div class="stat-subtext">Enabled access accounts</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="check-circle-2"></i>
    </div>
  </div>

  <div class="stat-card stat-info">
    <div class="stat-content">
      <h3>Current Signed-In Admin</h3>
      <div class="stat-number" style="font-size: 18px; font-weight: 700; word-break: break-word;">
        <?php echo clean($current_user['name']); ?>
      </div>
      <div class="stat-subtext"><?php echo clean($current_user['email']); ?></div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="user"></i>
    </div>
  </div>
</div>

<!-- Administrators Table Card -->
<div class="content-card">
  <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
    <div>
      <h3 style="font-size: 16px; font-weight: 700;">Authorized Administrators</h3>
      <p style="font-size: 12px; color: var(--text-muted); margin: 0;">
        All staff members with root administrative authority over tickets, infrastructure, and user accounts.
      </p>
    </div>
  </div>

  <div class="card-body" style="padding: 0;">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Administrator</th>
            <th>Email Address</th>
            <th>Role & Scope</th>
            <th>Account Status</th>
            <th>Account Created</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($admins as $adm): ?>
            <?php $is_self = ($adm['id'] === $current_admin_id); ?>
            <tr>
              <td>
                <div style="display: flex; align-items: center; gap: 10px;">
                  <div class="sidebar-user-avatar" style="width: 34px; height: 34px; font-size: 13px; background: #2563eb; color: #fff;">
                    <?php echo strtoupper(substr($adm['name'], 0, 1)); ?>
                  </div>
                  <div>
                    <strong><?php echo clean($adm['name']); ?></strong>
                    <?php if ($is_self): ?>
                      <span style="display: inline-block; margin-left: 6px; font-size: 10px; font-weight: 700; background: #eff6ff; color: #2563eb; padding: 1px 6px; border-radius: 3px; border: 1px solid #bfdbfe;">YOU</span>
                    <?php endif; ?>
                  </div>
                </div>
              </td>
              <td>
                <strong style="color: var(--text-main);"><?php echo clean($adm['email']); ?></strong>
              </td>
              <td>
                <span style="font-size: 12px; font-weight: 600; color: #1e40af; background: #eff6ff; padding: 2px 8px; border-radius: 4px; border: 1px solid #dbeafe;">
                  Super Administrator
                </span>
              </td>
              <td>
                <?php if ($adm['status'] === 'Active'): ?>
                  <span class="badge badge-success">Active</span>
                <?php else: ?>
                  <span class="badge badge-danger">Suspended</span>
                <?php endif; ?>
              </td>
              <td style="font-size: 12px; color: var(--text-muted);">
                <?php echo format_datetime($adm['created_at']); ?>
              </td>
              <td>
                <div style="display: flex; align-items: center; gap: 8px;">
                  
                  <!-- Edit Admin Button -->
                  <button type="button" 
                          class="btn btn-sm btn-secondary"
                          onclick="openEditAdminModal(<?php echo (int)$adm['id']; ?>, '<?php echo addslashes(clean($adm['name'])); ?>', '<?php echo addslashes(clean($adm['email'])); ?>', '<?php echo clean($adm['status']); ?>', <?php echo $is_self ? 'true' : 'false'; ?>)"
                          title="Edit Admin Account">
                    <i data-lucide="edit-3" style="width: 14px; height: 14px;"></i>
                    <span>Edit</span>
                  </button>

                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- MODAL 1: Create New Administrator Modal -->
<div id="createAdminModal" class="modal-backdrop">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3>Create New Administrator Account</h3>
      <button type="button" class="modal-close" onclick="closeModal('createAdminModal')">&times;</button>
    </div>
    <form action="<?php echo base_url('admin/admins.php'); ?>" method="POST">
      <input type="hidden" name="action" value="create_admin">
      <div class="modal-body">
        
        <div class="form-group">
          <label for="create_name" class="form-label">Full Name <span class="required">*</span></label>
          <input type="text" name="name" id="create_name" class="form-control" placeholder="e.g. Dr. Priya Sharma" required>
        </div>

        <div class="form-group">
          <label for="create_email" class="form-label">Admin Email Address <span class="required">*</span></label>
          <input type="email" name="email" id="create_email" class="form-control" placeholder="priya.admin@collegefix.edu" required>
          <div class="form-hint">Must be a unique email address used to log into the Admin Command Center.</div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="create_password" class="form-label">Password <span class="required">*</span></label>
            <input type="password" name="password" id="create_password" class="form-control" placeholder="Minimum 6 characters" required>
          </div>
          <div class="form-group">
            <label for="create_confirm" class="form-label">Confirm Password <span class="required">*</span></label>
            <input type="password" name="confirm_password" id="create_confirm" class="form-control" placeholder="Repeat password" required>
          </div>
        </div>

        <div class="form-group">
          <label for="create_status" class="form-label">Initial Account Status</label>
          <select name="status" id="create_status" class="form-control">
            <option value="Active" selected>Active (Immediate Access)</option>
            <option value="Suspended">Suspended (Access Disabled)</option>
          </select>
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('createAdminModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Create Administrator</button>
      </div>
    </form>
  </div>
</div>

<!-- MODAL 2: Edit Administrator Modal -->
<div id="editAdminModal" class="modal-backdrop">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3>Edit Administrator Account</h3>
      <button type="button" class="modal-close" onclick="closeModal('editAdminModal')">&times;</button>
    </div>
    <form action="<?php echo base_url('admin/admins.php'); ?>" method="POST">
      <input type="hidden" name="action" value="edit_admin">
      <input type="hidden" name="admin_id" id="edit_admin_id">
      
      <div class="modal-body">
        
        <div class="form-group">
          <label for="edit_name" class="form-label">Full Name <span class="required">*</span></label>
          <input type="text" name="name" id="edit_name" class="form-control" required>
        </div>

        <div class="form-group">
          <label for="edit_email" class="form-label">Admin Email Address <span class="required">*</span></label>
          <input type="email" name="email" id="edit_email" class="form-control" required>
        </div>

        <div class="form-group">
          <label for="edit_password" class="form-label">Reset Password (Optional)</label>
          <input type="password" name="password" id="edit_password" class="form-control" placeholder="Leave empty to keep existing password">
          <div class="form-hint">Enter a new password (min 6 characters) only if you wish to reset it.</div>
        </div>

        <div class="form-group" id="edit_status_group">
          <label for="edit_status" class="form-label">Account Status</label>
          <select name="status" id="edit_status" class="form-control">
            <option value="Active">Active</option>
            <option value="Suspended">Suspended</option>
          </select>
          <div id="edit_self_hint" style="display: none; font-size: 11px; color: var(--text-muted); margin-top: 4px;">
            You cannot suspend your own active administrator account.
          </div>
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('editAdminModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script>
function openEditAdminModal(id, name, email, status, isSelf) {
  document.getElementById('edit_admin_id').value = id;
  document.getElementById('edit_name').value = name;
  document.getElementById('edit_email').value = email;
  document.getElementById('edit_password').value = '';
  
  const statusSelect = document.getElementById('edit_status');
  statusSelect.value = status;
  
  const selfHint = document.getElementById('edit_self_hint');
  if (isSelf) {
    statusSelect.disabled = true;
    selfHint.style.display = 'block';
  } else {
    statusSelect.disabled = false;
    selfHint.style.display = 'none';
  }

  openModal('editAdminModal');
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
