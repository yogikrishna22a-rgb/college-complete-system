<?php
/**
 * CollegeFix - Admin Maintenance Staff Management
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

$error = '';

// Handle Add / Edit / Toggle Staff
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Add Staff
    if ($action === 'add_staff') {
        $name           = trim($_POST['name'] ?? '');
        $email          = trim($_POST['email'] ?? '');
        $staff_id       = trim($_POST['staff_id'] ?? '');
        $specialization = trim($_POST['specialization'] ?? '');
        $password       = $_POST['password'] ?? '';

        if (empty($name) || empty($email) || empty($staff_id) || empty($password)) {
            $error = 'Please fill out all required fields.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email address.';
        } else {
            try {
                // Check duplicate email or staff_id
                $chk = $conn->prepare("SELECT id FROM users WHERE email = ? OR staff_id = ?");
                $chk->execute([$email, $staff_id]);
                if ($chk->fetch()) {
                    $error = 'A user with this email or Staff ID already exists.';
                } else {
                    $hash = password_hash($password, PASSWORD_BCRYPT);
                    $now = date('Y-m-d H:i:s');
                    $stmt = $conn->prepare("
                        INSERT INTO users (name, email, password, role, staff_id, specialization, status, created_at)
                        VALUES (?, ?, ?, 'staff', ?, ?, 'Active', ?)
                    ");
                    $stmt->execute([$name, $email, $hash, $staff_id, $specialization, $now]);

                    set_flash('success', "Staff technician {$name} successfully registered.");
                    redirect('admin/staff.php');
                }
            } catch (Exception $e) {
                $error = 'Error adding staff: ' . $e->getMessage();
            }
        }
    }

    // Toggle Status (Active / Inactive)
    elseif ($action === 'toggle_status') {
        $id = (int)($_POST['id'] ?? 0);
        $new_status = ($_POST['current_status'] === 'Active') ? 'Inactive' : 'Active';

        try {
            $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'staff'");
            $stmt->execute([$new_status, $id]);
            set_flash('info', "Staff account marked as {$new_status}.");
            redirect('admin/staff.php');
        } catch (Exception $e) {
            $error = 'Error updating status: ' . $e->getMessage();
        }
    }
}

// Fetch all staff members with task counts
try {
    $stmt = $conn->query("
        SELECT u.*,
            (SELECT COUNT(*) FROM complaints WHERE assigned_staff_id = u.id AND status IN ('Assigned', 'In Progress')) as active_tasks,
            (SELECT COUNT(*) FROM complaints WHERE assigned_staff_id = u.id AND status IN ('Resolved', 'Closed')) as resolved_tasks,
            (SELECT AVG(fb.rating) FROM feedback fb JOIN complaints c ON fb.complaint_id = c.id WHERE c.assigned_staff_id = u.id) as avg_rating
        FROM users u
        WHERE u.role = 'staff'
        ORDER BY u.created_at DESC
    ");
    $staff_members = $stmt->fetchAll();
} catch (Exception $e) {
    set_flash('danger', 'Error loading staff: ' . $e->getMessage());
    $staff_members = [];
}

$page_title = 'Maintenance Staff - Admin - CollegeFix';
$active_menu = 'staff';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>Maintenance Staff Directory</h1>
    <p>Manage college technicians, track current workloads, and monitor student feedback ratings.</p>
  </div>
  <div class="page-actions">
    <button type="button" class="btn btn-primary" onclick="openModal('addStaffModal')">
      <i data-lucide="user-plus"></i>
      <span>Add New Staff</span>
    </button>
  </div>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger"><?php echo clean($error); ?></div>
<?php endif; ?>

<div class="content-card">
  <div class="card-header">
    <h3>Staff Members (<?php echo count($staff_members); ?> registered)</h3>
  </div>
  <div class="card-body card-body-table">
    <?php if (empty($staff_members)): ?>
      <div style="padding: 40px; text-align: center; color: var(--text-muted);">
        <i data-lucide="users" style="width: 44px; height: 44px; margin: 0 auto 12px; color: #94a3b8;"></i>
        <p style="font-size: 15px; font-weight: 600;">No maintenance staff members registered yet</p>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Staff ID</th>
              <th>Technician Name</th>
              <th>Specialization</th>
              <th>Active Workload</th>
              <th>Resolved</th>
              <th>Avg Rating</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($staff_members as $s): ?>
              <tr>
                <td><strong><?php echo clean($s['staff_id'] ?? 'STF' . $s['id']); ?></strong></td>
                <td>
                  <div style="display: flex; align-items: center; gap: 10px;">
                    <div class="sidebar-user-avatar" style="width: 32px; height: 32px; font-size: 13px;">
                      <?php echo strtoupper(substr($s['name'], 0, 1)); ?>
                    </div>
                    <div>
                      <strong style="color: var(--text-main); font-size: 13px;"><?php echo clean($s['name']); ?></strong>
                      <div style="font-size: 11px; color: var(--text-muted);"><?php echo clean($s['email']); ?></div>
                    </div>
                  </div>
                </td>
                <td>
                  <span style="display: inline-block; padding: 2px 8px; border-radius: 4px; background: #f1f5f9; font-size: 12px; font-weight: 500; color: #334155;">
                    <?php echo clean($s['specialization'] ?? 'General Technician'); ?>
                  </span>
                </td>
                <td>
                  <?php if ($s['active_tasks'] > 0): ?>
                    <span style="color: #b45309; font-weight: 700; font-size: 13px;">
                      <?php echo $s['active_tasks']; ?> tasks active
                    </span>
                  <?php else: ?>
                    <span style="color: #10b981; font-size: 12px;">Available (0 tasks)</span>
                  <?php endif; ?>
                </td>
                <td>
                  <strong style="color: #047857; font-size: 13px;"><?php echo $s['resolved_tasks']; ?></strong>
                </td>
                <td>
                  <?php if ($s['avg_rating']): ?>
                    <div style="color: #f59e0b; font-size: 12px; font-weight: 600;">
                      &#9733; <?php echo number_format($s['avg_rating'], 1); ?>/5
                    </div>
                  <?php else: ?>
                    <span style="font-size: 11px; color: var(--text-muted);">&mdash;</span>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if ($s['status'] === 'Active'): ?>
                    <span class="badge badge-success">Active</span>
                  <?php else: ?>
                    <span class="badge badge-danger">Inactive</span>
                  <?php endif; ?>
                </td>
                <td>
                  <form action="<?php echo base_url('admin/staff.php'); ?>" method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="toggle_status">
                    <input type="hidden" name="id" value="<?php echo $s['id']; ?>">
                    <input type="hidden" name="current_status" value="<?php echo $s['status']; ?>">
                    <button type="submit" class="btn btn-sm btn-secondary" title="<?php echo $s['status'] === 'Active' ? 'Deactivate' : 'Activate'; ?>">
                      <?php echo $s['status'] === 'Active' ? 'Disable' : 'Enable'; ?>
                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Add Staff Modal -->
<div id="addStaffModal" class="modal-backdrop">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3>Register Maintenance Technician</h3>
      <button type="button" class="modal-close" onclick="closeModal('addStaffModal')">&times;</button>
    </div>
    <form action="<?php echo base_url('admin/staff.php'); ?>" method="POST">
      <input type="hidden" name="action" value="add_staff">
      <div class="modal-body">
        
        <div class="form-group">
          <label for="name" class="form-label">Full Name <span class="required">*</span></label>
          <input type="text" name="name" id="name" class="form-control" placeholder="e.g. Ramesh Kumar" required>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="email" class="form-label">Email Address <span class="required">*</span></label>
            <input type="email" name="email" id="email" class="form-control" placeholder="ramesh@collegefix.edu" required>
          </div>
          <div class="form-group">
            <label for="staff_id" class="form-label">Staff Employee ID <span class="required">*</span></label>
            <input type="text" name="staff_id" id="staff_id" class="form-control" placeholder="STF004" required>
          </div>
        </div>

        <div class="form-group">
          <label for="specialization" class="form-label">Specialization / Domain</label>
          <input type="text" name="specialization" id="specialization" class="form-control" placeholder="e.g. Electrical & Wiring">
        </div>

        <div class="form-group">
          <label for="password" class="form-label">Account Password <span class="required">*</span></label>
          <input type="password" name="password" id="password" class="form-control" placeholder="Minimum 6 characters" required>
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('addStaffModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Create Staff Account</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
