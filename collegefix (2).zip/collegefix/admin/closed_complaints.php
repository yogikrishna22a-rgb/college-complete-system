<?php
/**
 * CollegeFix - Closed & Completed Complaints Archive
 * Dedicated archive repository where all complaints go once they have been closed/completed.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

$error = '';
$success = '';

// Handle Reopen Action from Archive (moves ticket back into active pipeline)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reopen') {
    $complaint_id = (int)($_POST['id'] ?? 0);
    $reopen_notes = trim($_POST['reopen_notes'] ?? 'Reopened by administrator from closed archive for further inspection.');

    if ($complaint_id > 0) {
        try {
            $now = date('Y-m-d H:i:s');
            $admin_user = current_user();

            $stmt = $conn->prepare("UPDATE complaints SET status = 'Reopened', updated_at = ? WHERE id = ?");
            $stmt->execute([$now, $complaint_id]);

            // Add timeline entry
            $stmt_tl = $conn->prepare("
                INSERT INTO complaint_updates (complaint_id, user_id, update_type, status, notes, created_at)
                VALUES (?, ?, 'Admin Reopen', 'Reopened', ?, ?)
            ");
            $stmt_tl->execute([$complaint_id, $admin_user['id'], $reopen_notes, $now]);

            // Fetch complaint info for notification
            $c_stmt = $conn->prepare("SELECT complaint_code, user_id, assigned_staff_id FROM complaints WHERE id = ?");
            $c_stmt->execute([$complaint_id]);
            $c_info = $c_stmt->fetch();

            if ($c_info) {
                // Notify student
                create_notification(
                    $conn,
                    $c_info['user_id'],
                    $complaint_id,
                    "Ticket Reopened: #{$c_info['complaint_code']}",
                    "Your ticket has been reopened from the archive for further maintenance.",
                    'info'
                );

                // Notify staff if assigned
                if (!empty($c_info['assigned_staff_id'])) {
                    create_notification(
                        $conn,
                        $c_info['assigned_staff_id'],
                        $complaint_id,
                        "Assigned Ticket Reopened: #{$c_info['complaint_code']}",
                        "A previously closed ticket assigned to you has been reopened.",
                        'warning'
                    );
                }
            }

            set_flash('success', "Ticket #{$c_info['complaint_code']} has been reopened and returned to active complaints.");
            redirect('admin/complaints.php');
        } catch (Exception $e) {
            $error = 'Error reopening ticket: ' . $e->getMessage();
        }
    }
}

// Filter parameters
$search     = trim($_GET['search'] ?? '');
$category   = (int)($_GET['category'] ?? 0);
$priority   = trim($_GET['priority'] ?? '');
$department = (int)($_GET['department'] ?? 0);
$staff_id   = (int)($_GET['staff_id'] ?? 0);
$status_filter = trim($_GET['status_filter'] ?? 'Closed'); // 'Closed' or 'Resolved' or 'Both'

// Build Query: Closed Archive
$where_clauses = [];
$params = [];

if ($status_filter === 'Both') {
    $where_clauses[] = "c.status IN ('Closed', 'Resolved')";
} elseif ($status_filter === 'Resolved') {
    $where_clauses[] = "c.status = 'Resolved'";
} else {
    $where_clauses[] = "c.status = 'Closed'";
}

if (!empty($search)) {
    $where_clauses[] = "(c.complaint_code LIKE ? OR c.title LIKE ? OR c.description LIKE ? OR c.building LIKE ? OR c.room_number LIKE ? OR u.name LIKE ?)";
    $like = '%' . $search . '%';
    for ($i = 0; $i < 6; $i++) {
        $params[] = $like;
    }
}

if (!empty($category)) {
    $where_clauses[] = "c.category_id = ?";
    $params[] = $category;
}

if (!empty($priority)) {
    $where_clauses[] = "c.priority = ?";
    $params[] = $priority;
}

if (!empty($department)) {
    $where_clauses[] = "c.department_id = ?";
    $params[] = $department;
}

if (!empty($staff_id)) {
    $where_clauses[] = "c.assigned_staff_id = ?";
    $params[] = $staff_id;
}

$where_sql = implode(" AND ", $where_clauses);

// Fetch categories, academic classes, and staff for dropdowns
$categories = [];
$departments = [];
$staff_list = [];

try {
    $categories  = $conn->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll();
    $departments = $conn->query("SELECT id, name, code FROM departments ORDER BY name ASC")->fetchAll();
    $staff_list  = $conn->query("SELECT id, name, specialization FROM users WHERE role = 'staff' AND status = 'Active' ORDER BY name ASC")->fetchAll();
} catch (Exception $e) {
    // Ignore dropdown load fail
}

// Fetch closed complaints with student, technician, class, and feedback details
try {
    $sql = "
        SELECT c.*, 
               cat.name as category_name, 
               d.name as department_name, 
               d.code as department_code,
               u.name as student_name, 
               u.student_id as student_roll, 
               u.email as student_email,
               staff.name as staff_name,
               fb.rating as feedback_rating,
               fb.comments as feedback_comments,
               fb.created_at as feedback_time
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN users u ON c.user_id = u.id
        LEFT JOIN users staff ON c.assigned_staff_id = staff.id
        LEFT JOIN feedback fb ON c.id = fb.complaint_id
        WHERE {$where_sql}
        ORDER BY COALESCE(c.resolved_at, c.updated_at, c.created_at) DESC
    ";
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $closed_complaints = $stmt->fetchAll();
} catch (Exception $e) {
    $closed_complaints = [];
}

// Calculate total active vs closed counts for tabs
$active_count = 0;
$closed_count = 0;
$avg_rating = 0;
$total_ratings = 0;

try {
    $counts_row = $conn->query("
        SELECT 
            SUM(CASE WHEN status != 'Closed' THEN 1 ELSE 0 END) as active_cnt,
            SUM(CASE WHEN status = 'Closed' THEN 1 ELSE 0 END) as closed_cnt
        FROM complaints
    ")->fetch();
    $active_count = (int)($counts_row['active_cnt'] ?? 0);
    $closed_count = (int)($counts_row['closed_cnt'] ?? 0);

    $rating_row = $conn->query("
        SELECT AVG(fb.rating) as avg_r, COUNT(fb.id) as total_r
        FROM feedback fb
        JOIN complaints c ON fb.complaint_id = c.id
        WHERE c.status = 'Closed'
    ")->fetch();
    if ($rating_row && $rating_row['avg_r']) {
        $avg_rating = round((float)$rating_row['avg_r'], 1);
        $total_ratings = (int)$rating_row['total_r'];
    }
} catch (Exception $e) {
    // default 0
}

$page_title = 'Closed Complaints Archive - Admin - CollegeFix';
$active_menu = 'closed_complaints';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Tab Switcher: Active vs Closed Archive -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid var(--border-color); padding-bottom: 12px;">
  <div style="display: flex; gap: 10px;">
    <a href="<?php echo base_url('admin/complaints.php'); ?>" class="btn btn-secondary" style="display: flex; align-items: center; gap: 8px;">
      <i data-lucide="clipboard-list" style="width: 18px; height: 18px;"></i>
      <span>Active Tickets</span>
      <span class="badge badge-primary" style="font-size: 11px; padding: 2px 8px;"><?php echo $active_count; ?></span>
    </a>
    <a href="<?php echo base_url('admin/closed_complaints.php'); ?>" class="btn btn-primary" style="display: flex; align-items: center; gap: 8px;">
      <i data-lucide="check-circle-2" style="width: 18px; height: 18px;"></i>
      <span>Closed Archive</span>
      <span class="badge" style="background: rgba(255,255,255,0.25); color: #fff; font-size: 11px; padding: 2px 8px;"><?php echo $closed_count; ?></span>
    </a>
  </div>

  <div style="display: flex; gap: 8px;">
    <a href="<?php echo base_url('api/export-csv.php?status=Closed'); ?>" class="btn btn-secondary" title="Export Closed Archive to CSV">
      <i data-lucide="download"></i>
      <span>Export Closed CSV</span>
    </a>
  </div>
</div>

<div class="page-header" style="margin-top: 0;">
  <div class="page-title">
    <h1>Closed & Completed Complaints Archive</h1>
    <p>Permanent historical archive where all tickets are preserved after being resolved and closed.</p>
  </div>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger"><?php echo clean($error); ?></div>
<?php endif; ?>

<!-- Quick Metrics for Closed Tickets -->
<div class="stats-grid" style="margin-bottom: 24px;">
  <div class="stat-card stat-success">
    <div class="stat-content">
      <h3>Total Closed Tickets</h3>
      <div class="stat-number"><?php echo $closed_count; ?></div>
      <div class="stat-subtext">Successfully completed & archived</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="check-check"></i>
    </div>
  </div>

  <div class="stat-card stat-warning">
    <div class="stat-content">
      <h3>Student Satisfaction</h3>
      <div class="stat-number">&#9733; <?php echo $avg_rating > 0 ? $avg_rating : '5.0'; ?> / 5</div>
      <div class="stat-subtext"><?php echo $total_ratings > 0 ? "{$total_ratings} verified reviews" : 'No negative feedback'; ?></div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="star"></i>
    </div>
  </div>

  <div class="stat-card stat-info">
    <div class="stat-content">
      <h3>Archive Status</h3>
      <div class="stat-number">100%</div>
      <div class="stat-subtext">Audit log & photos preserved</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="archive"></i>
    </div>
  </div>
</div>

<!-- Filters Bar -->
<div class="filter-bar">
  <form action="<?php echo base_url('admin/closed_complaints.php'); ?>" method="GET" style="display: contents;">
    <div class="filter-item" style="flex: 2;">
      <label class="form-label" style="font-size: 11px;">Search Archive</label>
      <input type="text" name="search" class="form-control" placeholder="Ticket #, title, student, room..." value="<?php echo clean($search); ?>">
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Category</label>
      <select name="category" class="form-control">
        <option value="">All Categories</option>
        <?php foreach ($categories as $cat): ?>
          <option value="<?php echo $cat['id']; ?>" <?php if ($category == $cat['id']) echo 'selected'; ?>>
            <?php echo clean($cat['name']); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Academic Class</label>
      <select name="department" class="form-control">
        <option value="">All Classes</option>
        <?php foreach ($departments as $dept): ?>
          <option value="<?php echo $dept['id']; ?>" <?php if ($department == $dept['id']) echo 'selected'; ?>>
            <?php echo clean($dept['name'] . ' (' . $dept['code'] . ')'); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Priority</label>
      <select name="priority" class="form-control">
        <option value="">All Priorities</option>
        <option value="Emergency" <?php if ($priority === 'Emergency') echo 'selected'; ?>>Emergency</option>
        <option value="High" <?php if ($priority === 'High') echo 'selected'; ?>>High</option>
        <option value="Medium" <?php if ($priority === 'Medium') echo 'selected'; ?>>Medium</option>
        <option value="Low" <?php if ($priority === 'Low') echo 'selected'; ?>>Low</option>
      </select>
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Technician</label>
      <select name="staff_id" class="form-control">
        <option value="">All Technicians</option>
        <?php foreach ($staff_list as $st): ?>
          <option value="<?php echo $st['id']; ?>" <?php if ($staff_id == $st['id']) echo 'selected'; ?>>
            <?php echo clean($st['name']); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div style="display: flex; gap: 8px;">
      <button type="submit" class="btn btn-primary">Filter</button>
      <?php if (!empty($search) || !empty($category) || !empty($priority) || !empty($department) || !empty($staff_id)): ?>
        <a href="<?php echo base_url('admin/closed_complaints.php'); ?>" class="btn btn-secondary" title="Reset Filters"><i data-lucide="x"></i></a>
      <?php endif; ?>
    </div>
  </form>
</div>

<!-- Closed Complaints Archive Table -->
<div class="content-card">
  <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
    <h3>Archived Cases (<?php echo count($closed_complaints); ?> closed)</h3>
    <span style="font-size: 12px; color: var(--text-muted);">
      Cases in this archive are completed. Use "Reopen" if an issue needs further maintenance.
    </span>
  </div>
  <div class="card-body card-body-table">
    <?php if (empty($closed_complaints)): ?>
      <div style="padding: 48px; text-align: center; color: var(--text-muted);">
        <i data-lucide="archive" style="width: 48px; height: 48px; margin: 0 auto 16px; color: #94a3b8;"></i>
        <h3 style="font-size: 16px; color: var(--text-main); margin-bottom: 6px;">No closed complaints found</h3>
        <p style="font-size: 13px;">When active tickets are marked as Closed, they will automatically appear here in this archive.</p>
        <a href="<?php echo base_url('admin/complaints.php'); ?>" class="btn btn-primary" style="margin-top: 16px;">
          View Active Complaints
        </a>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Ticket #</th>
              <th>Issue Title & Location</th>
              <th>Class</th>
              <th>Student Reporter</th>
              <th>Technician Handled</th>
              <th>Closed Date</th>
              <th>Student Rating</th>
              <th style="text-align: right;">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($closed_complaints as $c): ?>
              <tr>
                <td>
                  <a href="<?php echo base_url('admin/complaint_view.php?id=' . $c['id']); ?>" style="font-weight: 700; color: #2563eb; font-family: monospace;">
                    #<?php echo clean($c['complaint_code']); ?>
                  </a>
                  <div style="margin-top: 4px;">
                    <?php echo get_priority_badge($c['priority']); ?>
                  </div>
                </td>
                <td style="max-width: 260px;">
                  <strong style="color: var(--text-main); font-size: 14px; display: block;">
                    <?php echo clean($c['title']); ?>
                  </strong>
                  <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                    <i data-lucide="map-pin" style="width: 12px; height: 12px; display: inline; vertical-align: middle;"></i>
                    <?php echo clean($c['building'] . ', ' . $c['room_number']); ?>
                    &bull; <span style="color: #64748b;"><?php echo clean($c['category_name'] ?? 'General'); ?></span>
                  </div>
                </td>
                <td>
                  <?php if (!empty($c['department_code'])): ?>
                    <span class="badge badge-secondary" style="font-size: 12px; font-weight: 600;">
                      <?php echo clean($c['department_code']); ?>
                    </span>
                  <?php else: ?>
                    <span style="color: var(--text-muted); font-size: 12px;">General</span>
                  <?php endif; ?>
                </td>
                <td>
                  <strong><?php echo clean($c['student_name'] ?? 'Student'); ?></strong>
                  <div style="font-size: 11px; color: var(--text-muted);">
                    ID: <?php echo clean($c['student_roll'] ?? 'N/A'); ?>
                  </div>
                </td>
                <td>
                  <?php if (!empty($c['staff_name'])): ?>
                    <div style="display: flex; align-items: center; gap: 6px;">
                      <div class="sidebar-user-avatar" style="width: 24px; height: 24px; font-size: 11px;">
                        <?php echo strtoupper(substr($c['staff_name'], 0, 1)); ?>
                      </div>
                      <span style="font-size: 13px; font-weight: 500;"><?php echo clean($c['staff_name']); ?></span>
                    </div>
                  <?php else: ?>
                    <span style="color: var(--text-muted); font-size: 12px; font-style: italic;">Unassigned</span>
                  <?php endif; ?>
                </td>
                <td>
                  <span style="font-size: 13px; font-weight: 600; color: #166534;">
                    <i data-lucide="check-circle" style="width: 13px; height: 13px; display: inline; vertical-align: middle; color: #16a34a;"></i>
                    <?php 
                      $closed_date = $c['resolved_at'] ?: ($c['updated_at'] ?: $c['created_at']);
                      echo date('M d, Y', strtotime($closed_date)); 
                    ?>
                  </span>
                  <div style="font-size: 11px; color: var(--text-muted);">
                    <?php echo date('h:i A', strtotime($closed_date)); ?>
                  </div>
                </td>
                <td>
                  <?php if (!empty($c['feedback_rating'])): ?>
                    <div style="color: #f59e0b; font-weight: 700; font-size: 13px;" title="<?php echo clean($c['feedback_comments'] ?? ''); ?>">
                      <?php 
                        $r = (int)$c['feedback_rating'];
                        echo str_repeat('&#9733;', $r) . str_repeat('&#9734;', 5 - $r);
                      ?>
                      <span style="font-size: 11px; color: var(--text-muted); margin-left: 2px;">(<?php echo $r; ?>/5)</span>
                    </div>
                  <?php else: ?>
                    <span style="color: var(--text-muted); font-size: 11px; font-style: italic;">No feedback</span>
                  <?php endif; ?>
                </td>
                <td style="text-align: right;">
                  <div style="display: flex; justify-content: flex-end; gap: 6px;">
                    <a href="<?php echo base_url('admin/complaint_view.php?id=' . $c['id']); ?>" class="btn btn-sm btn-secondary" title="View Full Case History">
                      <i data-lucide="eye" style="width: 14px; height: 14px;"></i>
                      <span>Case File</span>
                    </a>
                    <button type="button" 
                            class="btn btn-sm btn-secondary" 
                            style="color: #c2410c;" 
                            onclick="openReopenModal(<?php echo (int)$c['id']; ?>, '<?php echo clean($c['complaint_code']); ?>')"
                            title="Reopen ticket back to active queue">
                      <i data-lucide="rotate-ccw" style="width: 14px; height: 14px;"></i>
                      <span>Reopen</span>
                    </button>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Reopen Modal -->
<div id="reopenModal" class="modal-backdrop">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3 id="reopenModalTitle">Reopen Ticket</h3>
      <button type="button" class="modal-close" onclick="closeModal('reopenModal')">&times;</button>
    </div>
    <form action="<?php echo base_url('admin/closed_complaints.php'); ?>" method="POST">
      <input type="hidden" name="action" value="reopen">
      <input type="hidden" name="id" id="reopen_ticket_id" value="">
      <div class="modal-body">
        <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 12px;">
          Reopening this ticket will move it out of the closed archive and return it to the active tickets queue for technicians to continue working on it.
        </p>
        <div class="form-group">
          <label for="reopen_notes" class="form-label">Reason for Reopening <span class="required">*</span></label>
          <textarea name="reopen_notes" id="reopen_notes" class="form-control" rows="3" placeholder="Explain what issue recurred or why further maintenance is required..." required></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('reopenModal')">Cancel</button>
        <button type="submit" class="btn btn-primary" style="background: #ea580c; border-color: #ea580c;">Confirm Reopen</button>
      </div>
    </form>
  </div>
</div>

<script>
function openReopenModal(ticketId, ticketCode) {
  document.getElementById('reopen_ticket_id').value = ticketId;
  document.getElementById('reopenModalTitle').innerText = 'Reopen Ticket #' + ticketCode;
  if (typeof window.openModal === 'function') {
    window.openModal('reopenModal');
  } else {
    var m = document.getElementById('reopenModal');
    if (m) m.classList.add('show');
  }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
