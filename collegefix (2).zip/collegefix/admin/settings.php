<?php
/**
 * CollegeFix - College System Settings & Admin Security
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

$user = current_user();
$user_id = $user['id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Save General Settings
    if ($action === 'save_settings') {
        $keys = [
            'college_name',
            'college_short_name',
            'contact_email',
            'contact_phone',
            'emergency_phone',
            'campus_address'
        ];

        try {
            $driver = $conn->getAttribute(PDO::ATTR_DRIVER_NAME);
            $is_sqlite = (strpos($driver, 'sqlite') !== false);

            if ($is_sqlite) {
                $stmt = $conn->prepare("INSERT OR REPLACE INTO college_settings (setting_key, setting_value) VALUES (?, ?)");
            } else {
                $stmt = $conn->prepare("INSERT INTO college_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            }

            foreach ($keys as $k) {
                $val = trim($_POST[$k] ?? '');
                $stmt->execute([$k, $val]);
            }

            set_flash('success', 'College settings saved successfully.');
            redirect('admin/settings.php');
        } catch (Exception $e) {
            $error = 'Error saving settings: ' . $e->getMessage();
        }
    }

    // Edit Admin Profile (Name and Email)
    elseif ($action === 'edit_profile') {
        $admin_name  = trim($_POST['name'] ?? '');
        $admin_email = trim($_POST['email'] ?? '');

        if (empty($admin_name) || empty($admin_email)) {
            $error = 'Name and email are required.';
        } elseif (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            try {
                $chk = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                $chk->execute([$admin_email, $user_id]);
                if ($chk->fetch()) {
                    $error = 'An account with email "' . clean($admin_email) . '" already exists.';
                } else {
                    $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
                    $stmt->execute([$admin_name, $admin_email, $user_id]);
                    $_SESSION['user_name'] = $admin_name;
                    $_SESSION['user_email'] = $admin_email;
                    set_flash('success', 'Admin profile updated successfully!');
                    redirect('admin/settings.php');
                }
            } catch (Exception $e) {
                $error = 'Error updating profile: ' . $e->getMessage();
            }
        }
    }

    // Change Admin Password
    elseif ($action === 'change_password') {
        $curr = $_POST['current_password'] ?? '';
        $new  = $_POST['new_password'] ?? '';
        $conf = $_POST['confirm_password'] ?? '';

        if (empty($curr) || empty($new)) {
            $error = 'Please fill in all password fields.';
        } elseif (strlen($new) < 6) {
            $error = 'Password must be at least 6 characters.';
        } elseif ($new !== $conf) {
            $error = 'New passwords do not match.';
        } else {
            try {
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $hash = $stmt->fetchColumn();

                if (!password_verify($curr, $hash)) {
                    $error = 'Current password is incorrect.';
                } else {
                    $new_hash = password_hash($new, PASSWORD_BCRYPT);
                    $stmt_up = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt_up->execute([$new_hash, $user_id]);
                    set_flash('success', 'Admin password changed successfully!');
                    redirect('admin/settings.php');
                }
            } catch (Exception $e) {
                $error = 'Error updating password: ' . $e->getMessage();
            }
        }
    }
}

// Fetch current settings
$settings = [];
try {
    $rows = $conn->query("SELECT setting_key, setting_value FROM college_settings")->fetchAll();
    foreach ($rows as $r) {
        $settings[$r['setting_key']] = $r['setting_value'];
    }
    // Fetch current admin user info fresh from DB
    $current_admin_info = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
    $current_admin_info->execute([$user_id]);
    $admin_db = $current_admin_info->fetch();
    $total_admins_count = (int)$conn->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
} catch (Exception $e) {
    $admin_db = ['name' => $user['name'] ?? 'Admin', 'email' => $user['email'] ?? 'admin@collegefix.edu'];
    $total_admins_count = 1;
}

$page_title = 'Settings - Admin - CollegeFix';
$active_menu = 'settings';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>College System Settings & Security</h1>
    <p>Configure campus identity, administrative profiles, and manage administrator accounts.</p>
  </div>
  <div class="page-actions">
    <a href="<?php echo base_url('admin/admins.php'); ?>" class="btn btn-primary">
      <i data-lucide="user-cog"></i>
      <span>Manage Administrator Accounts (<?php echo $total_admins_count; ?>)</span>
    </a>
  </div>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger" style="margin-bottom: 20px;"><?php echo clean($error); ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
  
  <!-- Column 1: College Info Form -->
  <div style="display: flex; flex-direction: column; gap: 24px;">
    
    <div class="content-card">
      <div class="card-header">
        <h3>Campus Institution Profile</h3>
      </div>
      <div class="card-body">
        <form action="<?php echo base_url('admin/settings.php'); ?>" method="POST">
          <input type="hidden" name="action" value="save_settings">

          <div class="form-group">
            <label for="college_name" class="form-label">Full College / University Name <span class="required">*</span></label>
            <input type="text" name="college_name" id="college_name" class="form-control" value="<?php echo clean($settings['college_name'] ?? 'National Institute of Technology & Science'); ?>" required>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="college_short_name" class="form-label">Short Name / Campus Title</label>
              <input type="text" name="college_short_name" id="college_short_name" class="form-control" value="<?php echo clean($settings['college_short_name'] ?? 'NITS Campus Portal'); ?>" required>
            </div>

            <div class="form-group">
              <label for="contact_email" class="form-label">Official Maintenance Email</label>
              <input type="email" name="contact_email" id="contact_email" class="form-control" value="<?php echo clean($settings['contact_email'] ?? 'maintenance@collegefix.edu'); ?>">
            </div>
          </div>

          <div class="form-group">
            <label for="campus_address" class="form-label">Campus Physical Address</label>
            <textarea name="campus_address" id="campus_address" class="form-control" rows="2"><?php echo clean($settings['campus_address'] ?? 'Knowledge Park Sector 5, Greater Campus Road'); ?></textarea>
          </div>

          <button type="submit" class="btn btn-primary">Save College Settings</button>
        </form>
      </div>
    </div>

    <!-- Admin Accounts Banner Card -->
    <div class="content-card" style="border-left: 4px solid #2563eb;">
      <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <div>
          <h3>Multiple Administrator Accounts</h3>
          <p style="font-size: 12px; color: var(--text-muted); margin: 0;">
            Create new administrators, revoke access, or edit other administrator accounts.
          </p>
        </div>
        <a href="<?php echo base_url('admin/admins.php'); ?>" class="btn btn-secondary btn-sm">
          <i data-lucide="user-plus" style="width: 14px; height: 14px;"></i>
          <span>Add / Edit Admins</span>
        </a>
      </div>
    </div>

  </div>

  <!-- Column 2: Admin Profile & Password Forms -->
  <div style="display: flex; flex-direction: column; gap: 24px;">
    
    <!-- Edit My Admin Profile Form -->
    <div class="content-card">
      <div class="card-header">
        <h3>My Administrator Profile</h3>
      </div>
      <div class="card-body">
        <form action="<?php echo base_url('admin/settings.php'); ?>" method="POST">
          <input type="hidden" name="action" value="edit_profile">

          <div class="form-group">
            <label for="admin_name" class="form-label">Admin Full Name <span class="required">*</span></label>
            <input type="text" name="name" id="admin_name" class="form-control" value="<?php echo clean($admin_db['name'] ?? $user['name']); ?>" required>
          </div>

          <div class="form-group">
            <label for="admin_email" class="form-label">Admin Email Address <span class="required">*</span></label>
            <input type="email" name="email" id="admin_email" class="form-control" value="<?php echo clean($admin_db['email'] ?? $user['email']); ?>" required>
          </div>

          <button type="submit" class="btn btn-primary" style="width: 100%;">Update Admin Profile</button>
        </form>
      </div>
    </div>

    <!-- Admin Password Change -->
    <div class="content-card">
      <div class="card-header">
        <h3>Change Password</h3>
      </div>
      <div class="card-body">
        <form action="<?php echo base_url('admin/settings.php'); ?>" method="POST">
          <input type="hidden" name="action" value="change_password">

          <div class="form-group">
            <label for="current_password" class="form-label">Current Password</label>
            <input type="password" name="current_password" id="current_password" class="form-control" required placeholder="••••••••">
          </div>

          <div class="form-group">
            <label for="new_password" class="form-label">New Password</label>
            <input type="password" name="new_password" id="new_password" class="form-control" required placeholder="Minimum 6 characters">
          </div>

          <div class="form-group">
            <label for="confirm_password" class="form-label">Confirm Password</label>
            <input type="password" name="confirm_password" id="confirm_password" class="form-control" required placeholder="••••••••">
          </div>

          <button type="submit" class="btn btn-secondary" style="width: 100%;">Update Admin Password</button>
        </form>
      </div>
    </div>

  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
