<?php
/**
 * CollegeFix - Admin All Complaints Management
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

// Filters
$search     = trim($_GET['search'] ?? '');
$status     = trim($_GET['status'] ?? '');
$category   = (int)($_GET['category'] ?? 0);
$priority   = trim($_GET['priority'] ?? '');
$department = (int)($_GET['department'] ?? 0);
$staff_id   = (int)($_GET['staff_id'] ?? 0);

$where_clauses = ["1=1"];
$params = [];

if (!empty($search)) {
    $where_clauses[] = "(c.complaint_code LIKE ? OR c.title LIKE ? OR c.description LIKE ? OR c.building LIKE ? OR c.room_number LIKE ? OR u.name LIKE ?)";
    $like = '%' . $search . '%';
    for ($i = 0; $i < 6; $i++) {
        $params[] = $like;
    }
}

if ($status === 'Closed') {
    redirect('admin/closed_complaints.php?' . http_build_query($_GET));
}

if (!empty($status)) {
    $where_clauses[] = "c.status = ?";
    $params[] = $status;
} else {
    // By default, active tickets exclude closed tickets (which are housed in the closed archive)
    $where_clauses[] = "c.status != 'Closed'";
}

if (!empty($category)) {
    $where_clauses[] = "c.category_id = ?";
    $params[] = $category;
}

if (!empty($priority)) {
    $where_clauses[] = "c.priority = ?";
    $params[] = $priority;
}

if (!empty($department)) {
    $where_clauses[] = "c.department_id = ?";
    $params[] = $department;
}

if (!empty($staff_id)) {
    $where_clauses[] = "c.assigned_staff_id = ?";
    $params[] = $staff_id;
}

$where_sql = implode(" AND ", $where_clauses);

// Fetch categories & departments for dropdowns
$categories = [];
$departments = [];
$staff_list = [];

try {
    $categories  = $conn->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll();
    $departments = $conn->query("SELECT id, name, code FROM departments ORDER BY name ASC")->fetchAll();
    $staff_list  = $conn->query("SELECT id, name, specialization FROM users WHERE role = 'staff' ORDER BY name ASC")->fetchAll();

    $query = "
        SELECT c.*, cat.name as category_name, d.name as department_name, 
               u.name as student_name, u.student_id as student_roll,
               s.name as staff_name, s.specialization as staff_spec
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN users u ON c.user_id = u.id
        LEFT JOIN users s ON c.assigned_staff_id = s.id
        WHERE {$where_sql}
        ORDER BY 
            CASE c.priority WHEN 'Emergency' THEN 1 WHEN 'High' THEN 2 ELSE 3 END ASC,
            c.created_at DESC
    ";
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $complaints = $stmt->fetchAll();
} catch (Exception $e) {
    set_flash('danger', 'Error querying complaints: ' . $e->getMessage());
    $complaints = [];
}

// Count active vs closed complaints for tabs
$active_count = 0;
$closed_count = 0;
try {
    $c_row = $conn->query("
        SELECT 
            SUM(CASE WHEN status != 'Closed' THEN 1 ELSE 0 END) as active_cnt,
            SUM(CASE WHEN status = 'Closed' THEN 1 ELSE 0 END) as closed_cnt
        FROM complaints
    ")->fetch();
    $active_count = (int)($c_row['active_cnt'] ?? 0);
    $closed_count = (int)($c_row['closed_cnt'] ?? 0);
} catch (Exception $e) {}

$page_title = 'Active Complaints - Admin - CollegeFix';
$active_menu = 'complaints';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Tab Switcher: Active Tickets vs Closed Archive -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid var(--border-color); padding-bottom: 12px;">
  <div style="display: flex; gap: 10px;">
    <a href="<?php echo base_url('admin/complaints.php'); ?>" class="btn btn-primary" style="display: flex; align-items: center; gap: 8px;">
      <i data-lucide="clipboard-list" style="width: 18px; height: 18px;"></i>
      <span>Active Tickets</span>
      <span class="badge" style="background: rgba(255,255,255,0.25); color: #fff; font-size: 11px; padding: 2px 8px;"><?php echo $active_count; ?></span>
    </a>
    <a href="<?php echo base_url('admin/closed_complaints.php'); ?>" class="btn btn-secondary" style="display: flex; align-items: center; gap: 8px;">
      <i data-lucide="check-circle-2" style="width: 18px; height: 18px;"></i>
      <span>Closed Archive</span>
      <span class="badge badge-secondary" style="font-size: 11px; padding: 2px 8px;"><?php echo $closed_count; ?></span>
    </a>
  </div>

  <div style="display: flex; gap: 8px;">
    <!-- Export to CSV -->
    <a href="<?php echo base_url('api/export-csv.php?' . http_build_query($_GET)); ?>" class="btn btn-secondary" title="Export Current List to CSV">
      <i data-lucide="download"></i>
      <span>Export CSV</span>
    </a>
  </div>
</div>

<div class="page-header" style="margin-top: 0;">
  <div class="page-title">
    <h1>Active Campus Complaints</h1>
    <p>Monitor open tickets, assign technicians, and track progress. Once closed, tickets move to the Closed Archive.</p>
  </div>
</div>

<!-- Filters Bar -->
<div class="filter-bar">
  <form action="<?php echo base_url('admin/complaints.php'); ?>" method="GET" style="display: contents;">
    <div class="filter-item" style="flex: 2;">
      <label class="form-label" style="font-size: 11px;">Search Keyword</label>
      <input type="text" name="search" class="form-control" placeholder="Ticket #, title, room, student..." value="<?php echo clean($search); ?>">
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Status</label>
      <select name="status" class="form-control">
        <option value="">All Statuses</option>
        <option value="Submitted" <?php if ($status === 'Submitted') echo 'selected'; ?>>Submitted</option>
        <option value="Under Review" <?php if ($status === 'Under Review') echo 'selected'; ?>>Under Review</option>
        <option value="Assigned" <?php if ($status === 'Assigned') echo 'selected'; ?>>Assigned</option>
        <option value="In Progress" <?php if ($status === 'In Progress') echo 'selected'; ?>>In Progress</option>
        <option value="Resolved" <?php if ($status === 'Resolved') echo 'selected'; ?>>Resolved</option>
        <option value="Closed" <?php if ($status === 'Closed') echo 'selected'; ?>>Closed</option>
        <option value="Reopened" <?php if ($status === 'Reopened') echo 'selected'; ?>>Reopened</option>
        <option value="Rejected" <?php if ($status === 'Rejected') echo 'selected'; ?>>Rejected</option>
      </select>
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Category</label>
      <select name="category" class="form-control">
        <option value="">All Categories</option>
        <?php foreach ($categories as $cat): ?>
          <option value="<?php echo $cat['id']; ?>" <?php if ($category == $cat['id']) echo 'selected'; ?>>
            <?php echo clean($cat['name']); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Priority</label>
      <select name="priority" class="form-control">
        <option value="">All Priorities</option>
        <option value="Emergency" <?php if ($priority === 'Emergency') echo 'selected'; ?>>Emergency</option>
        <option value="High" <?php if ($priority === 'High') echo 'selected'; ?>>High</option>
        <option value="Medium" <?php if ($priority === 'Medium') echo 'selected'; ?>>Medium</option>
        <option value="Low" <?php if ($priority === 'Low') echo 'selected'; ?>>Low</option>
      </select>
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Class</label>
      <select name="department" class="form-control">
        <option value="">All Classes</option>
        <?php foreach ($departments as $dept): ?>
          <option value="<?php echo $dept['id']; ?>" <?php if ($department == $dept['id']) echo 'selected'; ?>>
            <?php echo clean($dept['name'] . ' (' . $dept['code'] . ')'); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div style="display: flex; gap: 8px;">
      <button type="submit" class="btn btn-primary">Filter</button>
      <?php if (!empty($search) || !empty($status) || !empty($category) || !empty($priority) || !empty($department)): ?>
        <a href="<?php echo base_url('admin/complaints.php'); ?>" class="btn btn-secondary" title="Reset Filters"><i data-lucide="x"></i></a>
      <?php endif; ?>
    </div>
  </form>
</div>

<!-- Table -->
<div class="content-card">
  <div class="card-header">
    <h3>Complaints Records (<?php echo count($complaints); ?> found)</h3>
  </div>
  <div class="card-body card-body-table">
    <?php if (empty($complaints)): ?>
      <div style="padding: 40px; text-align: center; color: var(--text-muted);">
        <i data-lucide="inbox" style="width: 44px; height: 44px; margin: 0 auto 12px; color: #94a3b8;"></i>
        <p style="font-size: 15px; font-weight: 600;">No complaints match the specified criteria</p>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Ticket ID</th>
              <th>Complaint Title</th>
              <th>Category</th>
              <th>Location</th>
              <th>Priority</th>
              <th>Status</th>
              <th>Reported By</th>
              <th>Submitted</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($complaints as $c): ?>
              <tr style="<?php echo ($c['priority'] === 'Emergency' && !in_array($c['status'], ['Resolved', 'Closed'])) ? 'background: #fff1f2;' : ''; ?>">
                <td>
                  <a href="<?php echo base_url('admin/complaint_view.php?id=' . $c['id']); ?>" class="table-code">
                    #<?php echo clean($c['complaint_code']); ?>
                  </a>
                </td>
                <td>
                  <strong style="color: var(--text-main); font-size: 13px;"><?php echo clean($c['title']); ?></strong>
                  <div style="font-size: 11px; color: var(--text-muted);">
                    <?php echo clean(mb_strimwidth($c['description'], 0, 45, '...')); ?>
                  </div>
                </td>
                <td><?php echo clean($c['category_name']); ?></td>
                <td>
                  <strong><?php echo clean($c['room_number']); ?></strong>
                  <div style="font-size: 11px; color: var(--text-muted);"><?php echo clean($c['building']); ?></div>
                </td>
                <td><?php echo get_priority_badge($c['priority']); ?></td>
                <td><?php echo get_status_badge($c['status']); ?></td>
                <td>
                  <div style="font-size: 13px; font-weight: 500;"><?php echo clean($c['student_name']); ?></div>
                  <div style="font-size: 11px; color: var(--text-muted);"><?php echo clean($c['student_roll'] ?? 'Student'); ?></div>
                </td>
                <td style="font-size: 12px; color: var(--text-muted);">
                  <?php echo format_datetime($c['created_at']); ?>
                </td>
                <td>
                  <a href="<?php echo base_url('admin/complaint_view.php?id=' . $c['id']); ?>" class="btn btn-sm btn-primary">
                    Manage
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
