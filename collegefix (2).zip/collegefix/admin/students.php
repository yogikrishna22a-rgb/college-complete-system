<?php
/**
 * CollegeFix - Admin Student Management
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

$search = trim($_GET['search'] ?? '');

// Toggle status action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_status') {
    $id = (int)$_POST['id'];
    $new_status = ($_POST['current_status'] === 'Active') ? 'Inactive' : 'Active';
    try {
        $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'student'");
        $stmt->execute([$new_status, $id]);
        set_flash('info', "Student status set to {$new_status}.");
        redirect('admin/students.php');
    } catch (Exception $e) {}
}

$where_sql = "u.role = 'student'";
$params = [];

if (!empty($search)) {
    $where_sql .= " AND (u.name LIKE ? OR u.email LIKE ? OR u.student_id LIKE ? OR d.name LIKE ?)";
    $like = '%' . $search . '%';
    $params = [$like, $like, $like, $like];
}

try {
    $query = "
        SELECT u.*, d.name as department_name, d.code as department_code,
               (SELECT COUNT(*) FROM complaints WHERE user_id = u.id) as total_complaints,
               (SELECT COUNT(*) FROM complaints WHERE user_id = u.id AND status IN ('Resolved', 'Closed')) as resolved_complaints
        FROM users u
        LEFT JOIN departments d ON u.department_id = d.id
        WHERE {$where_sql}
        ORDER BY u.created_at DESC
    ";
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $students = $stmt->fetchAll();
} catch (Exception $e) {
    $students = [];
}

$page_title = 'Students Directory - Admin - CollegeFix';
$active_menu = 'students';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>Registered Students Directory</h1>
    <p>View registered students, their academic class enrollments, and filed complaint history.</p>
  </div>
</div>

<div class="filter-bar">
  <form action="<?php echo base_url('admin/students.php'); ?>" method="GET" style="display: flex; gap: 12px; width: 100%; max-width: 600px;">
    <input type="text" name="search" class="form-control" placeholder="Search by Student ID, name, email, class..." value="<?php echo clean($search); ?>">
    <button type="submit" class="btn btn-primary">Search</button>
    <?php if (!empty($search)): ?>
      <a href="<?php echo base_url('admin/students.php'); ?>" class="btn btn-secondary"><i data-lucide="x"></i></a>
    <?php endif; ?>
  </form>
</div>

<div class="content-card">
  <div class="card-header">
    <h3>Students (<?php echo count($students); ?> found)</h3>
  </div>
  <div class="card-body card-body-table">
    <?php if (empty($students)): ?>
      <div style="padding: 40px; text-align: center; color: var(--text-muted);">
        <i data-lucide="users" style="width: 44px; height: 44px; margin: 0 auto 12px; color: #94a3b8;"></i>
        <p style="font-size: 15px; font-weight: 600;">No students found</p>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Roll / Student ID</th>
              <th>Student Name</th>
              <th>Academic Class</th>
              <th>Complaints Filed</th>
              <th>Status</th>
              <th>Registered</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($students as $s): ?>
              <tr>
                <td><strong><?php echo clean($s['student_id'] ?? 'N/A'); ?></strong></td>
                <td>
                  <strong><?php echo clean($s['name']); ?></strong>
                  <div style="font-size: 11px; color: var(--text-muted);"><?php echo clean($s['email']); ?></div>
                </td>
                <td><?php echo clean($s['department_name'] ?? 'Unassigned'); ?></td>
                <td>
                  <a href="<?php echo base_url('admin/complaints.php?search=' . urlencode($s['name'])); ?>" style="color: #2563eb; font-weight: 600; text-decoration: none;">
                    <?php echo $s['total_complaints']; ?> complaints (<?php echo $s['resolved_complaints']; ?> resolved)
                  </a>
                </td>
                <td>
                  <?php if ($s['status'] === 'Active'): ?>
                    <span class="badge badge-success">Active</span>
                  <?php else: ?>
                    <span class="badge badge-danger">Suspended</span>
                  <?php endif; ?>
                </td>
                <td style="font-size: 12px; color: var(--text-muted);">
                  <?php echo format_datetime($s['created_at']); ?>
                </td>
                <td>
                  <form action="<?php echo base_url('admin/students.php'); ?>" method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="toggle_status">
                    <input type="hidden" name="id" value="<?php echo $s['id']; ?>">
                    <input type="hidden" name="current_status" value="<?php echo $s['status']; ?>">
                    <button type="submit" class="btn btn-sm btn-secondary">
                      <?php echo $s['status'] === 'Active' ? 'Suspend' : 'Activate'; ?>
                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
