<?php
/**
 * CollegeFix - Admin Classes Management (Redirect for backward compatibility)
 */
require_once __DIR__ . '/classes.php';
