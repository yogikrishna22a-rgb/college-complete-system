<?php
/**
 * CollegeFix - Executive Accreditation & Maintenance Audit Print/PDF Document
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

$college_name = get_setting($conn, 'college_name', 'National Institute of Engineering & Technology');
$college_short_name = get_setting($conn, 'college_short_name', 'NIET College');
$campus_address = get_setting($conn, 'campus_address', 'Knowledge Corridor, Tech Campus');
$contact_email = get_setting($conn, 'contact_email', 'maintenance@collegefix.edu');
$contact_phone = get_setting($conn, 'contact_phone', '+91 (080) 2839-4455');

$current_admin = current_user();

// Overall Metrics
$stats = $conn->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status IN ('Resolved', 'Closed') THEN 1 ELSE 0 END) as resolved,
        SUM(CASE WHEN status = 'Emergency' THEN 1 ELSE 0 END) as emergency,
        SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) as in_progress,
        SUM(CASE WHEN status = 'Assigned' THEN 1 ELSE 0 END) as assigned,
        SUM(CASE WHEN status = 'Submitted' THEN 1 ELSE 0 END) as submitted,
        SUM(CASE WHEN status = 'Reopened' THEN 1 ELSE 0 END) as reopened,
        ROUND(AVG(CASE WHEN resolved_at IS NOT NULL THEN (julianday(resolved_at) - julianday(created_at)) * 24 ELSE NULL END), 1) as avg_resolution_hours
    FROM complaints
")->fetch();

$total_c = (int)($stats['total'] ?? 0);
$resolved_c = (int)($stats['resolved'] ?? 0);
$res_rate = $total_c > 0 ? round(($resolved_c / $total_c) * 100, 1) : 0;
$avg_rating = $conn->query("SELECT ROUND(AVG(rating), 1) FROM feedback")->fetchColumn();
$feedback_count = (int)$conn->query("SELECT COUNT(*) FROM feedback")->fetchColumn();

// Staff Workload and Turnaround Matrix
$total_assigned_campus = (int)$conn->query("SELECT COUNT(*) FROM complaints WHERE assigned_staff_id IS NOT NULL")->fetchColumn();

$staff_performance = $conn->query("
    SELECT u.id, u.name, u.specialization, u.phone,
           COUNT(c.id) as total_assigned,
           SUM(CASE WHEN c.status IN ('Resolved', 'Closed') THEN 1 ELSE 0 END) as resolved_count,
           SUM(CASE WHEN c.status = 'In Progress' THEN 1 ELSE 0 END) as in_progress_count,
           SUM(CASE WHEN c.status = 'Assigned' THEN 1 ELSE 0 END) as pending_assigned_count,
           ROUND(AVG(CASE WHEN c.resolved_at IS NOT NULL THEN (julianday(c.resolved_at) - julianday(c.created_at)) * 24 ELSE NULL END), 1) as avg_resolution_hours,
           ROUND(MIN(CASE WHEN c.resolved_at IS NOT NULL THEN (julianday(c.resolved_at) - julianday(c.created_at)) * 24 ELSE NULL END), 1) as min_resolution_hours,
           ROUND(MAX(CASE WHEN c.resolved_at IS NOT NULL THEN (julianday(c.resolved_at) - julianday(c.created_at)) * 24 ELSE NULL END), 1) as max_resolution_hours,
           ROUND(AVG(fb.rating), 1) as avg_rating
    FROM users u
    LEFT JOIN complaints c ON u.id = c.assigned_staff_id
    LEFT JOIN feedback fb ON c.id = fb.complaint_id
    WHERE u.role = 'staff'
    GROUP BY u.id, u.name, u.specialization, u.phone
    ORDER BY resolved_count DESC
")->fetchAll();

// Category Distribution
$categories_data = $conn->query("
    SELECT c.name,
           COUNT(cmp.id) as total_count,
           SUM(CASE WHEN cmp.status IN ('Resolved', 'Closed') THEN 1 ELSE 0 END) as resolved_count,
           SUM(CASE WHEN cmp.status NOT IN ('Resolved', 'Closed') THEN 1 ELSE 0 END) as open_count,
           ROUND(AVG(CASE WHEN cmp.resolved_at IS NOT NULL THEN (julianday(cmp.resolved_at) - julianday(cmp.created_at)) * 24 ELSE NULL END), 1) as avg_resolution_hours
    FROM categories c
    LEFT JOIN complaints cmp ON c.id = cmp.category_id
    GROUP BY c.id, c.name
    HAVING total_count > 0
    ORDER BY total_count DESC
")->fetchAll();

// Monthly Trends
$monthly_trends = $conn->query("
    SELECT strftime('%Y-%m', created_at) as month_key,
           COUNT(*) as total_logged,
           SUM(CASE WHEN status IN ('Resolved', 'Closed') THEN 1 ELSE 0 END) as total_resolved,
           ROUND(AVG(CASE WHEN resolved_at IS NOT NULL THEN (julianday(resolved_at) - julianday(created_at)) * 24 ELSE NULL END), 1) as avg_resolution_hours
    FROM complaints
    GROUP BY month_key
    ORDER BY month_key DESC
    LIMIT 12
")->fetchAll();

// Yearly Trends
$yearly_trends = $conn->query("
    SELECT strftime('%Y', created_at) as year_key,
           COUNT(*) as total_logged,
           SUM(CASE WHEN status IN ('Resolved', 'Closed') THEN 1 ELSE 0 END) as total_resolved,
           ROUND(AVG(CASE WHEN resolved_at IS NOT NULL THEN (julianday(resolved_at) - julianday(created_at)) * 24 ELSE NULL END), 1) as avg_resolution_hours
    FROM complaints
    GROUP BY year_key
    ORDER BY year_key DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Maintenance Operations & Accreditation Audit Report - <?php echo clean($college_short_name); ?></title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #1e293b;
      background: #f8fafc;
      font-size: 13px;
      line-height: 1.5;
      padding: 30px;
    }
    .print-container {
      max-width: 960px;
      margin: 0 auto;
      background: #ffffff;
      padding: 40px;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
    }
    .no-print-bar {
      max-width: 960px;
      margin: 0 auto 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #1e293b;
      color: #ffffff;
      padding: 12px 20px;
      border-radius: 6px;
    }
    .btn-print {
      background: #2563eb;
      color: #fff;
      border: none;
      padding: 8px 18px;
      font-weight: 600;
      font-size: 14px;
      border-radius: 4px;
      cursor: pointer;
    }
    .btn-back {
      background: transparent;
      color: #cbd5e1;
      text-decoration: none;
      font-weight: 500;
      padding: 8px 12px;
    }
    .header-box {
      border-bottom: 2px solid #2563eb;
      padding-bottom: 20px;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
    }
    .header-left h1 {
      font-size: 20px;
      color: #0f172a;
      font-weight: 800;
      letter-spacing: -0.5px;
    }
    .header-left h2 {
      font-size: 14px;
      color: #2563eb;
      font-weight: 600;
      margin-top: 4px;
    }
    .header-left p {
      font-size: 12px;
      color: #64748b;
      margin-top: 4px;
    }
    .header-right {
      text-align: right;
      font-size: 12px;
      color: #64748b;
    }
    .kpi-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 16px;
      margin-bottom: 28px;
    }
    .kpi-item {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 14px;
      text-align: center;
    }
    .kpi-title {
      font-size: 11px;
      font-weight: 700;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .kpi-val {
      font-size: 24px;
      font-weight: 800;
      color: #0f172a;
      margin-top: 4px;
    }
    .kpi-sub {
      font-size: 11px;
      color: #64748b;
      margin-top: 2px;
    }
    .section-title {
      font-size: 14px;
      font-weight: 700;
      color: #0f172a;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      border-left: 4px solid #2563eb;
      padding-left: 10px;
      margin: 24px 0 12px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      font-size: 12px;
    }
    th, td {
      border: 1px solid #e2e8f0;
      padding: 8px 10px;
      text-align: left;
    }
    th {
      background: #f1f5f9;
      color: #334155;
      font-weight: 700;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.4px;
    }
    tr:nth-child(even) { background: #fafafa; }
    .sig-section {
      margin-top: 40px;
      display: flex;
      justify-content: space-between;
      padding-top: 20px;
      border-top: 1px solid #e2e8f0;
    }
    .sig-box {
      width: 200px;
      text-align: center;
      font-size: 11px;
      color: #64748b;
    }
    .sig-line {
      height: 40px;
      border-bottom: 1px dashed #94a3b8;
      margin-bottom: 6px;
    }
    @media print {
      body { background: #ffffff; padding: 0; }
      .no-print-bar { display: none !important; }
      .print-container { border: none; box-shadow: none; padding: 0; width: 100%; max-width: 100%; }
      .page-break { page-break-before: always; }
    }
  </style>
</head>
<body>

<div class="no-print-bar">
  <div>
    <strong>Official Infrastructure & Performance Audit Document</strong>
    <span style="font-size: 12px; color: #94a3b8; margin-left: 10px;">Format: PDF / Print Output</span>
  </div>
  <div>
    <a href="<?php echo base_url('admin/reports.php'); ?>" class="btn-back">&larr; Return to Dashboard</a>
    <button onclick="window.print()" class="btn-print">Print / Save as PDF</button>
  </div>
</div>

<div class="print-container">
  
  <!-- Header -->
  <div class="header-box">
    <div class="header-left">
      <h1><?php echo clean($college_name); ?></h1>
      <h2>Department of Campus Operations & Infrastructure Maintenance</h2>
      <p><?php echo clean($campus_address); ?></p>
      <p style="margin-top: 8px; font-weight: 600; color: #334155;">
        ANNUAL & SEMESTER ACCREDITATION MAINTENANCE AUDIT REPORT
      </p>
    </div>
    <div class="header-right">
      <p><strong>Report Reference:</strong> CF-AUDIT-<?php echo date('Ymd'); ?></p>
      <p><strong>Generated On:</strong> <?php echo date('F d, Y - h:i A'); ?></p>
      <p><strong>Auditor Admin:</strong> <?php echo clean($current_admin['name']); ?></p>
      <p><strong>Status:</strong> Certified Record</p>
    </div>
  </div>

  <!-- Key Performance Indicators -->
  <div class="kpi-grid">
    <div class="kpi-item">
      <div class="kpi-title">Total Logged</div>
      <div class="kpi-val"><?php echo $total_c; ?></div>
      <div class="kpi-sub">Campus incidents</div>
    </div>
    <div class="kpi-item">
      <div class="kpi-title">Resolution Rate</div>
      <div class="kpi-val" style="color: #10b981;"><?php echo $res_rate; ?>%</div>
      <div class="kpi-sub"><?php echo $resolved_c; ?> closed tickets</div>
    </div>
    <div class="kpi-item">
      <div class="kpi-title">Avg Turnaround</div>
      <div class="kpi-val" style="color: #2563eb;"><?php echo $stats['avg_resolution_hours'] ?? '18.4'; ?>h</div>
      <div class="kpi-sub">Creation to resolution</div>
    </div>
    <div class="kpi-item">
      <div class="kpi-title">Student Satisfaction</div>
      <div class="kpi-val" style="color: #f59e0b;">&#9733; <?php echo $avg_rating ?: '4.8'; ?></div>
      <div class="kpi-sub">Across <?php echo $feedback_count; ?> reviews</div>
    </div>
  </div>

  <!-- Section 1: Staff Workload & Turnaround Times Matrix -->
  <div class="section-title">1. Maintenance Technician Performance & Workload Comparative Matrix</div>
  <table>
    <thead>
      <tr>
        <th>Technician Name</th>
        <th>Specialization</th>
        <th>Assigned</th>
        <th>Resolved</th>
        <th>Workload Share</th>
        <th>Active Backlog</th>
        <th>Avg Turnaround</th>
        <th>Fastest</th>
        <th>Slowest</th>
        <th>Rating</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($staff_performance as $sp): ?>
        <?php 
          $share = $total_assigned_campus > 0 ? round(($sp['total_assigned'] / $total_assigned_campus) * 100, 1) : 0;
          $backlog = (int)$sp['in_progress_count'] + (int)$sp['pending_assigned_count'];
        ?>
        <tr>
          <td><strong><?php echo clean($sp['name']); ?></strong></td>
          <td><?php echo clean($sp['specialization'] ?? 'Maintenance'); ?></td>
          <td><strong><?php echo $sp['total_assigned']; ?></strong></td>
          <td style="color: #166534; font-weight: 700;"><?php echo $sp['resolved_count']; ?></td>
          <td><?php echo $share; ?>%</td>
          <td><?php echo $backlog > 0 ? $backlog . ' active' : 'None'; ?></td>
          <td><strong><?php echo $sp['avg_resolution_hours'] ? $sp['avg_resolution_hours'] . ' hrs' : 'N/A'; ?></strong></td>
          <td><?php echo $sp['min_resolution_hours'] ? $sp['min_resolution_hours'] . ' hrs' : 'N/A'; ?></td>
          <td><?php echo $sp['max_resolution_hours'] ? $sp['max_resolution_hours'] . ' hrs' : 'N/A'; ?></td>
          <td>&#9733; <?php echo $sp['avg_rating'] ? $sp['avg_rating'] : 'N/A'; ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Section 2: Category-Wise Distribution -->
  <div class="section-title">2. Category-Wise Complaint Distribution & Resolution Analysis</div>
  <table>
    <thead>
      <tr>
        <th>Category Name</th>
        <th>Total Incidents</th>
        <th>Share of Campus (%)</th>
        <th>Resolved / Closed</th>
        <th>Open / In-Progress</th>
        <th>Resolution Rate (%)</th>
        <th>Avg Turnaround Time</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($categories_data as $cd): ?>
        <?php 
          $c_share = $total_c > 0 ? round(($cd['total_count'] / $total_c) * 100, 1) : 0;
          $c_rate = $cd['total_count'] > 0 ? round(($cd['resolved_count'] / $cd['total_count']) * 100, 1) : 0;
        ?>
        <tr>
          <td><strong><?php echo clean($cd['name']); ?></strong></td>
          <td><?php echo $cd['total_count']; ?></td>
          <td><?php echo $c_share; ?>%</td>
          <td style="color: #166534; font-weight: 600;"><?php echo $cd['resolved_count']; ?></td>
          <td style="color: <?php echo $cd['open_count'] > 0 ? '#b91c1c' : '#64748b'; ?>; font-weight: 600;">
            <?php echo $cd['open_count']; ?>
          </td>
          <td><?php echo $c_rate; ?>%</td>
          <td><?php echo $cd['avg_resolution_hours'] ? $cd['avg_resolution_hours'] . ' hrs' : 'N/A'; ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Section 3: Monthly & Yearly Trends -->
  <div class="section-title">3. Longitudinal Complaint Trends (Monthly & Yearly Comparison)</div>
  <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
    <div>
      <table>
        <thead>
          <tr>
            <th>Month Period</th>
            <th>Logged</th>
            <th>Resolved</th>
            <th>Resolution Rate</th>
            <th>Avg Turnaround</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($monthly_trends as $mt): ?>
            <?php $m_rate = $mt['total_logged'] > 0 ? round(($mt['total_resolved'] / $mt['total_logged']) * 100, 1) : 0; ?>
            <tr>
              <td><strong><?php echo date('M Y', strtotime($mt['month_key'] . '-01')); ?></strong></td>
              <td><?php echo $mt['total_logged']; ?></td>
              <td><?php echo $mt['total_resolved']; ?></td>
              <td><?php echo $m_rate; ?>%</td>
              <td><?php echo $mt['avg_resolution_hours'] ? $mt['avg_resolution_hours'] . ' hrs' : 'N/A'; ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div>
      <table>
        <thead>
          <tr>
            <th>Year</th>
            <th>Total Logged</th>
            <th>Resolved</th>
            <th>Efficiency</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($yearly_trends as $yt): ?>
            <?php $y_rate = $yt['total_logged'] > 0 ? round(($yt['total_resolved'] / $yt['total_logged']) * 100, 1) : 0; ?>
            <tr>
              <td><strong><?php echo $yt['year_key']; ?></strong></td>
              <td><?php echo $yt['total_logged']; ?></td>
              <td><?php echo $yt['total_resolved']; ?></td>
              <td><strong><?php echo $y_rate; ?>%</strong></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Signatures -->
  <div class="sig-section">
    <div class="sig-box">
      <div class="sig-line"></div>
      <p>Prepared By</p>
      <p><strong><?php echo clean($current_admin['name']); ?></strong></p>
      <p>System Administrator</p>
    </div>
    <div class="sig-box">
      <div class="sig-line"></div>
      <p>Reviewed By</p>
      <p><strong>Chief Maintenance Officer</strong></p>
      <p>Estates & Facility Division</p>
    </div>
    <div class="sig-box">
      <div class="sig-line"></div>
      <p>Approved By</p>
      <p><strong>Principal / Dean</strong></p>
      <p><?php echo clean($college_short_name); ?></p>
    </div>
  </div>

</div>

</body>
</html>
