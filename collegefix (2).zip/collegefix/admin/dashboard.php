<?php
/**
 * CollegeFix - Administrator Dashboard
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

$user = current_user();

// Summary counts
$metrics = [
    'total'       => 0,
    'pending'     => 0,
    'assigned'    => 0,
    'in_progress' => 0,
    'resolved'    => 0,
    'closed'      => 0,
    'rejected'    => 0,
    'emergency'   => 0,
    'total_staff' => 0,
    'total_students' => 0
];

try {
    $res = $conn->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status IN ('Submitted', 'Under Review') THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'Assigned' THEN 1 ELSE 0 END) as assigned,
            SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) as resolved,
            SUM(CASE WHEN status = 'Closed' THEN 1 ELSE 0 END) as closed,
            SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) as rejected,
            SUM(CASE WHEN priority = 'Emergency' AND status NOT IN ('Resolved', 'Closed', 'Rejected') THEN 1 ELSE 0 END) as emergency
        FROM complaints
    ")->fetch();

    if ($res) {
        $metrics['total']       = (int)($res['total'] ?? 0);
        $metrics['pending']     = (int)($res['pending'] ?? 0);
        $metrics['assigned']    = (int)($res['assigned'] ?? 0);
        $metrics['in_progress'] = (int)($res['in_progress'] ?? 0);
        $metrics['resolved']    = (int)($res['resolved'] ?? 0);
        $metrics['closed']      = (int)($res['closed'] ?? 0);
        $metrics['rejected']    = (int)($res['rejected'] ?? 0);
        $metrics['emergency']   = (int)($res['emergency'] ?? 0);
    }

    // Counts of staff & students
    $user_counts = $conn->query("
        SELECT role, COUNT(*) as cnt 
        FROM users 
        WHERE status = 'Active' 
        GROUP BY role
    ")->fetchAll();

    foreach ($user_counts as $uc) {
        if ($uc['role'] === 'staff') $metrics['total_staff'] = (int)$uc['cnt'];
        if ($uc['role'] === 'student') $metrics['total_students'] = (int)$uc['cnt'];
    }

    // Recent unassigned complaints (needs attention)
    $unassigned = $conn->query("
        SELECT c.*, cat.name as category_name, u.name as student_name, u.student_id as roll_no
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN users u ON c.user_id = u.id
        WHERE c.status IN ('Submitted', 'Under Review') OR c.assigned_staff_id IS NULL
        ORDER BY 
            CASE c.priority WHEN 'Emergency' THEN 1 WHEN 'High' THEN 2 ELSE 3 END ASC,
            c.created_at DESC
        LIMIT 6
    ")->fetchAll();

    // Staff list for quick assignment
    $staff_members = $conn->query("
        SELECT id, name, specialization 
        FROM users 
        WHERE role = 'staff' AND status = 'Active' 
        ORDER BY name ASC
    ")->fetchAll();

    // Category breakdown for chart
    $cat_data = $conn->query("
        SELECT cat.name, COUNT(c.id) as cnt
        FROM categories cat
        LEFT JOIN complaints c ON cat.id = c.category_id
        GROUP BY cat.id, cat.name
        HAVING cnt > 0
        ORDER BY cnt DESC
        LIMIT 6
    ")->fetchAll();

    $cat_labels = [];
    $cat_counts = [];
    foreach ($cat_data as $cd) {
        $cat_labels[] = $cd['name'];
        $cat_counts[] = (int)$cd['cnt'];
    }

} catch (Exception $e) {
    set_flash('danger', 'Error loading admin data: ' . $e->getMessage());
    $unassigned = [];
    $staff_members = [];
    $cat_labels = [];
    $cat_counts = [];
}

$page_title = 'Administration Dashboard - CollegeFix';
$active_menu = 'dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>College Maintenance Command Center</h1>
    <p><?php echo clean(get_setting($conn, 'college_name', 'National Institute of Technology & Science')); ?> &bull; Administrative Overview</p>
  </div>
  <div class="page-actions">
    <a href="<?php echo base_url('admin/reports.php'); ?>" class="btn btn-secondary">
      <i data-lucide="bar-chart-2"></i>
      <span>View Reports</span>
    </a>
    <a href="<?php echo base_url('admin/complaints.php'); ?>" class="btn btn-primary">
      <i data-lucide="clipboard-list"></i>
      <span>Manage All Complaints</span>
    </a>
  </div>
</div>

<!-- Key Stat Cards -->
<div class="stats-grid">
  <div class="stat-card stat-primary">
    <div class="stat-content">
      <h3>Total Complaints</h3>
      <div class="stat-number"><?php echo $metrics['total']; ?></div>
      <div class="stat-subtext">Across all academic classes</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="layers"></i>
    </div>
  </div>

  <div class="stat-card stat-warning">
    <div class="stat-content">
      <h3>Pending Review</h3>
      <div class="stat-number"><?php echo $metrics['pending']; ?></div>
      <div class="stat-subtext">Awaiting staff assignment</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="clock"></i>
    </div>
  </div>

  <div class="stat-card stat-info">
    <div class="stat-content">
      <h3>In Progress</h3>
      <div class="stat-number"><?php echo $metrics['in_progress']; ?></div>
      <div class="stat-subtext">Under active technician work</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="wrench"></i>
    </div>
  </div>

  <a href="<?php echo base_url('admin/closed_complaints.php'); ?>" class="stat-card stat-success" style="text-decoration: none; color: inherit;">
    <div class="stat-content">
      <h3>Resolved / Closed</h3>
      <div class="stat-number"><?php echo $metrics['resolved'] + $metrics['closed']; ?></div>
      <div class="stat-subtext">Click to view Closed Archive</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="check-circle-2"></i>
    </div>
  </a>

  <div class="stat-card stat-emergency">
    <div class="stat-content">
      <h3>Emergency Tickets</h3>
      <div class="stat-number"><?php echo $metrics['emergency']; ?></div>
      <div class="stat-subtext">Critical priority unresolved</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="alert-octagon"></i>
    </div>
  </div>
</div>

<!-- Secondary Stats & Chart Area -->
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px; margin-bottom: 24px;">
  
  <!-- Unassigned / Pending Complaints Requiring Attention -->
  <div class="content-card">
    <div class="card-header">
      <h3>Complaints Requiring Review & Assignment</h3>
      <a href="<?php echo base_url('admin/complaints.php?status=Submitted'); ?>" class="btn btn-sm btn-secondary">View All Pending</a>
    </div>
    <div class="card-body card-body-table">
      <?php if (empty($unassigned)): ?>
        <div style="padding: 40px; text-align: center; color: var(--text-muted);">
          <i data-lucide="check-circle" style="width: 44px; height: 44px; margin: 0 auto 12px; color: #10b981;"></i>
          <p style="font-size: 15px; font-weight: 600;">All complaints are currently assigned or resolved!</p>
          <p style="font-size: 13px; margin-top: 4px;">Incoming tickets submitted by students will appear here for staff assignment.</p>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Ticket</th>
                <th>Issue Summary</th>
                <th>Category</th>
                <th>Location</th>
                <th>Priority</th>
                <th>Student</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($unassigned as $item): ?>
                <tr style="<?php echo ($item['priority'] === 'Emergency') ? 'background: #fff1f2;' : ''; ?>">
                  <td>
                    <a href="<?php echo base_url('admin/complaint_view.php?id=' . $item['id']); ?>" class="table-code">
                      #<?php echo clean($item['complaint_code']); ?>
                    </a>
                  </td>
                  <td>
                    <strong style="color: var(--text-main); font-size: 13px;"><?php echo clean($item['title']); ?></strong>
                    <div style="font-size: 11px; color: var(--text-muted);"><?php echo time_ago($item['created_at']); ?></div>
                  </td>
                  <td><?php echo clean($item['category_name']); ?></td>
                  <td>
                    <strong><?php echo clean($item['room_number']); ?></strong>
                    <div style="font-size: 11px; color: var(--text-muted);"><?php echo clean($item['building']); ?></div>
                  </td>
                  <td><?php echo get_priority_badge($item['priority']); ?></td>
                  <td>
                    <div style="font-size: 13px; font-weight: 500;"><?php echo clean($item['student_name']); ?></div>
                    <div style="font-size: 11px; color: var(--text-muted);"><?php echo clean($item['roll_no'] ?? ''); ?></div>
                  </td>
                  <td>
                    <a href="<?php echo base_url('admin/complaint_view.php?id=' . $item['id']); ?>" class="btn btn-sm btn-primary">
                      Assign
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Category Breakdown Chart & Team Info -->
  <div style="display: flex; flex-direction: column; gap: 24px;">
    
    <!-- Chart Card -->
    <div class="content-card">
      <div class="card-header">
        <h3>Complaints by Category</h3>
      </div>
      <div class="card-body" style="padding: 18px;">
        <canvas id="categoryChart" height="200"></canvas>
      </div>
    </div>

    <!-- Active Team Overview -->
    <div class="content-card">
      <div class="card-body" style="padding: 18px 20px;">
        <h4 style="font-size: 13px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; margin-bottom: 12px;">Active Campus Accounts</h4>
        <div style="display: flex; justify-content: space-around; text-align: center;">
          <div>
            <div style="font-size: 24px; font-weight: 800; color: #2563eb;"><?php echo $metrics['total_staff']; ?></div>
            <div style="font-size: 12px; color: var(--text-muted); font-weight: 500; margin-top: 2px;">
              <a href="<?php echo base_url('admin/staff.php'); ?>" style="color: inherit; text-decoration: none;">Maintenance Staff</a>
            </div>
          </div>
          <div style="width: 1px; background: var(--border-color);"></div>
          <div>
            <div style="font-size: 24px; font-weight: 800; color: #10b981;"><?php echo $metrics['total_students']; ?></div>
            <div style="font-size: 12px; color: var(--text-muted); font-weight: 500; margin-top: 2px;">
              <a href="<?php echo base_url('admin/students.php'); ?>" style="color: inherit; text-decoration: none;">Active Students</a>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

</div>

<!-- Render Chart.js -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  const ctx = document.getElementById('categoryChart');
  if (ctx && typeof Chart !== 'undefined') {
    const labels = <?php echo json_encode($cat_labels); ?>;
    const data = <?php echo json_encode($cat_counts); ?>;

    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: labels.length ? labels : ['No Data'],
        datasets: [{
          data: data.length ? data : [1],
          backgroundColor: [
            '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd', '#10b981', '#f59e0b', '#ef4444'
          ],
          borderWidth: 2,
          borderColor: '#ffffff'
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { boxWidth: 12, font: { size: 11 } }
          }
        },
        cutout: '65%'
      }
    });
  }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
