<?php
/**
 * CollegeFix - Admin Maintenance Categories
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Add category
    if ($action === 'add_category') {
        $name = trim($_POST['name'] ?? '');
        $desc = trim($_POST['description'] ?? '');

        if (empty($name)) {
            $error = 'Category name is required.';
        } else {
            try {
                $stmt = $conn->prepare("INSERT INTO categories (name, description, status) VALUES (?, ?, 'Active')");
                $stmt->execute([$name, $desc]);
                set_flash('success', "Category '{$name}' added successfully.");
                redirect('admin/categories.php');
            } catch (Exception $e) {
                $error = 'Error adding category: ' . $e->getMessage();
            }
        }
    }

    // Toggle status
    elseif ($action === 'toggle_status') {
        $id = (int)$_POST['id'];
        $new_status = ($_POST['current_status'] === 'Active') ? 'Inactive' : 'Active';
        try {
            $stmt = $conn->prepare("UPDATE categories SET status = ? WHERE id = ?");
            $stmt->execute([$new_status, $id]);
            set_flash('info', "Category status updated to {$new_status}.");
            redirect('admin/categories.php');
        } catch (Exception $e) {
            $error = 'Error updating status: ' . $e->getMessage();
        }
    }
}

// Fetch categories with complaint counts
try {
    $stmt = $conn->query("
        SELECT cat.*, COUNT(c.id) as total_complaints,
               SUM(CASE WHEN c.status IN ('Resolved', 'Closed') THEN 1 ELSE 0 END) as resolved_complaints
        FROM categories cat
        LEFT JOIN complaints c ON cat.id = c.category_id
        GROUP BY cat.id, cat.name, cat.description, cat.status
        ORDER BY cat.name ASC
    ");
    $categories = $stmt->fetchAll();
} catch (Exception $e) {
    $categories = [];
}

$page_title = 'Categories - Admin - CollegeFix';
$active_menu = 'categories';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>Maintenance Problem Categories</h1>
    <p>Configure issue classifications available for student ticket reporting.</p>
  </div>
  <div class="page-actions">
    <button type="button" class="btn btn-primary" onclick="openModal('addCategoryModal')">
      <i data-lucide="plus"></i>
      <span>Add Category</span>
    </button>
  </div>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger"><?php echo clean($error); ?></div>
<?php endif; ?>

<div class="content-card">
  <div class="card-header">
    <h3>Registered Categories (<?php echo count($categories); ?> total)</h3>
  </div>
  <div class="card-body card-body-table">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Category Name</th>
            <th>Description & Typical Issues</th>
            <th>Total Complaints</th>
            <th>Resolved</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($categories as $cat): ?>
            <tr>
              <td>
                <strong style="font-size: 14px; color: var(--text-main);"><?php echo clean($cat['name']); ?></strong>
              </td>
              <td>
                <span style="font-size: 13px; color: var(--text-muted);"><?php echo clean($cat['description'] ?? 'N/A'); ?></span>
              </td>
              <td>
                <a href="<?php echo base_url('admin/complaints.php?category=' . $cat['id']); ?>" style="color: #2563eb; font-weight: 600; text-decoration: none;">
                  <?php echo (int)$cat['total_complaints']; ?> complaints
                </a>
              </td>
              <td>
                <strong style="color: #10b981;"><?php echo (int)$cat['resolved_complaints']; ?></strong>
              </td>
              <td>
                <?php if ($cat['status'] === 'Active'): ?>
                  <span class="badge badge-success">Active</span>
                <?php else: ?>
                  <span class="badge badge-danger">Disabled</span>
                <?php endif; ?>
              </td>
              <td>
                <form action="<?php echo base_url('admin/categories.php'); ?>" method="POST" style="display: inline;">
                  <input type="hidden" name="action" value="toggle_status">
                  <input type="hidden" name="id" value="<?php echo $cat['id']; ?>">
                  <input type="hidden" name="current_status" value="<?php echo $cat['status']; ?>">
                  <button type="submit" class="btn btn-sm btn-secondary">
                    <?php echo $cat['status'] === 'Active' ? 'Disable' : 'Enable'; ?>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Add Category Modal -->
<div id="addCategoryModal" class="modal-backdrop">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3>Add New Issue Category</h3>
      <button type="button" class="modal-close" onclick="closeModal('addCategoryModal')">&times;</button>
    </div>
    <form action="<?php echo base_url('admin/categories.php'); ?>" method="POST">
      <input type="hidden" name="action" value="add_category">
      <div class="modal-body">
        <div class="form-group">
          <label for="cat_name" class="form-label">Category Name <span class="required">*</span></label>
          <input type="text" name="name" id="cat_name" class="form-control" placeholder="e.g. Smart Board & Audio" required>
        </div>
        <div class="form-group">
          <label for="cat_desc" class="form-label">Description / Examples</label>
          <textarea name="description" id="cat_desc" class="form-control" rows="3" placeholder="Audio amplifier failure, microphone battery, touch calibration..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('addCategoryModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Create Category</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
