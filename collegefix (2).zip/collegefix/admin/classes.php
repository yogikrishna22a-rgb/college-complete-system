<?php
/**
 * CollegeFix - Admin Academic Classes Management
 * Allows administrators to manage academic classes, assign class in-charges,
 * edit class details, and monitor student enrollments & maintenance tickets.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['admin']);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim($_POST['action'] ?? 'add');

    if ($action === 'add') {
        $name = trim($_POST['name'] ?? '');
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $head_name = trim($_POST['head_name'] ?? '');

        if (empty($name) || empty($code)) {
            $error = 'Class Name and Class Code are required.';
        } else {
            try {
                // Check if code already exists
                $check = $conn->prepare("SELECT id FROM departments WHERE code = ? LIMIT 1");
                $check->execute([$code]);
                if ($check->fetch()) {
                    $error = "A class with code '{$code}' already exists.";
                } else {
                    $stmt = $conn->prepare("INSERT INTO departments (name, code, head_name) VALUES (?, ?, ?)");
                    $stmt->execute([$name, $code, $head_name ?: null]);
                    set_flash('success', "Academic class '{$name} ({$code})' created successfully.");
                    redirect('admin/classes.php');
                }
            } catch (Exception $e) {
                $error = 'Error adding class: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'edit') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $head_name = trim($_POST['head_name'] ?? '');

        if (empty($id) || empty($name) || empty($code)) {
            $error = 'Class ID, Name, and Code are required to update class details.';
        } else {
            try {
                // Check if code is already used by another class
                $check = $conn->prepare("SELECT id FROM departments WHERE code = ? AND id != ? LIMIT 1");
                $check->execute([$code, $id]);
                if ($check->fetch()) {
                    $error = "Class code '{$code}' is already assigned to another class.";
                } else {
                    $stmt = $conn->prepare("UPDATE departments SET name = ?, code = ?, head_name = ? WHERE id = ?");
                    $stmt->execute([$name, $code, $head_name ?: null, $id]);
                    set_flash('success', "Academic class '{$name} ({$code})' updated successfully.");
                    redirect('admin/classes.php');
                }
            } catch (Exception $e) {
                $error = 'Error updating class details: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if (!empty($id)) {
            try {
                // Check if class has students or complaints
                $s_check = $conn->prepare("SELECT COUNT(*) FROM users WHERE department_id = ?");
                $s_check->execute([$id]);
                $stu_count = (int)$s_check->fetchColumn();

                $c_check = $conn->prepare("SELECT COUNT(*) FROM complaints WHERE department_id = ?");
                $c_check->execute([$id]);
                $cmp_count = (int)$c_check->fetchColumn();

                if ($stu_count > 0 || $cmp_count > 0) {
                    $error = "Cannot delete this class because it has {$stu_count} enrolled student(s) and {$cmp_count} associated ticket(s).";
                } else {
                    $stmt = $conn->prepare("DELETE FROM departments WHERE id = ?");
                    $stmt->execute([$id]);
                    set_flash('success', 'Academic class deleted successfully.');
                    redirect('admin/classes.php');
                }
            } catch (Exception $e) {
                $error = 'Error deleting class: ' . $e->getMessage();
            }
        }
    }
}

// Fetch academic classes with student and complaint counts
try {
    $stmt = $conn->query("
        SELECT d.*, 
               COUNT(DISTINCT u.id) as student_count,
               COUNT(DISTINCT c.id) as complaint_count
        FROM departments d
        LEFT JOIN users u ON d.id = u.department_id AND u.role = 'student'
        LEFT JOIN complaints c ON d.id = c.department_id
        GROUP BY d.id, d.name, d.code, d.head_name
        ORDER BY d.name ASC
    ");
    $classes = $stmt->fetchAll();
} catch (Exception $e) {
    $classes = [];
}

$page_title = 'Academic Classes - Admin - CollegeFix';
$active_menu = 'classes';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>Academic Classes & Sections</h1>
    <p>Manage college classes, assign class teachers / in-charges, and track ticket distributions.</p>
  </div>
  <div class="page-actions">
    <button type="button" class="btn btn-primary" onclick="openModal('addClassModal')">
      <i data-lucide="plus"></i>
      <span>Add Academic Class</span>
    </button>
  </div>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger"><?php echo clean($error); ?></div>
<?php endif; ?>

<div class="content-card">
  <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
    <h3>Classes (<?php echo count($classes); ?> total)</h3>
    <span style="font-size: 13px; color: var(--text-muted);">Administrators have permission to edit and manage all class details</span>
  </div>
  <div class="card-body card-body-table">
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>Class Code</th>
            <th>Academic Class Name</th>
            <th>Class Teacher / In-Charge</th>
            <th>Enrolled Students</th>
            <th>Associated Tickets</th>
            <th style="text-align: right;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($classes)): ?>
            <tr>
              <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                No academic classes found. Click "Add Academic Class" above to create one.
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($classes as $c): ?>
              <tr>
                <td>
                  <span class="badge badge-primary" style="font-family: monospace; font-size: 13px; font-weight: 700;">
                    <?php echo clean($c['code']); ?>
                  </span>
                </td>
                <td>
                  <strong style="color: var(--text-main); font-size: 14px;">
                    <?php echo clean($c['name']); ?>
                  </strong>
                </td>
                <td>
                  <?php if (!empty($c['head_name'])): ?>
                    <div style="display: flex; align-items: center; gap: 8px;">
                      <i data-lucide="user-check" style="width: 16px; height: 16px; color: #059669;"></i>
                      <span><?php echo clean($c['head_name']); ?></span>
                    </div>
                  <?php else: ?>
                    <span style="color: var(--text-muted); font-style: italic;">Not assigned</span>
                  <?php endif; ?>
                </td>
                <td>
                  <a href="<?php echo base_url('admin/students.php?search=' . urlencode($c['name'])); ?>" style="color: #2563eb; font-weight: 600; text-decoration: none;">
                    <?php echo (int)$c['student_count']; ?> students
                  </a>
                </td>
                <td>
                  <a href="<?php echo base_url('admin/complaints.php?department=' . $c['id']); ?>" style="color: #2563eb; font-weight: 600; text-decoration: none;">
                    <?php echo (int)$c['complaint_count']; ?> complaints
                  </a>
                </td>
                <td style="text-align: right;">
                  <div style="display: flex; justify-content: flex-end; gap: 8px;">
                    <!-- Edit Class Button -->
                    <button type="button" 
                            class="btn btn-sm btn-secondary" 
                            style="display: inline-flex; align-items: center; gap: 4px;"
                            onclick="editClass(<?php echo (int)$c['id']; ?>, <?php echo htmlspecialchars(json_encode($c['name']), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($c['code']), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($c['head_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>)"
                            title="Edit Class Details">
                      <i data-lucide="edit-2" style="width: 14px; height: 14px;"></i>
                      <span>Edit</span>
                    </button>

                    <!-- View Complaints -->
                    <a href="<?php echo base_url('admin/complaints.php?department=' . $c['id']); ?>" 
                       class="btn btn-sm btn-secondary"
                       title="View Class Complaints">
                      <span>Complaints</span>
                    </a>

                    <?php if ((int)$c['student_count'] === 0 && (int)$c['complaint_count'] === 0): ?>
                      <form action="<?php echo base_url('admin/classes.php'); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this class?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo (int)$c['id']; ?>">
                        <button type="submit" class="btn btn-sm btn-danger" style="padding: 4px 8px;" title="Delete Class">
                          <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
                        </button>
                      </form>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Add Class Modal -->
<div id="addClassModal" class="modal-backdrop">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3>Add New Academic Class</h3>
      <button type="button" class="modal-close" onclick="closeModal('addClassModal')">&times;</button>
    </div>
    <form action="<?php echo base_url('admin/classes.php'); ?>" method="POST">
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-group">
          <label for="add_class_name" class="form-label">Academic Class Name <span class="required">*</span></label>
          <input type="text" name="name" id="add_class_name" class="form-control" placeholder="e.g. Computer Science - Year 3 Sec A" required>
        </div>
        <div class="form-group">
          <label for="add_class_code" class="form-label">Class Code / Abbreviation <span class="required">*</span></label>
          <input type="text" name="code" id="add_class_code" class="form-control" placeholder="e.g. CSE-3A" required maxlength="15">
        </div>
        <div class="form-group">
          <label for="add_class_head" class="form-label">Class Teacher / Faculty In-Charge (Optional)</label>
          <input type="text" name="head_name" id="add_class_head" class="form-control" placeholder="e.g. Dr. Arvind Sharma">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('addClassModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Create Class</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Class Modal (Admin Permissions) -->
<div id="editClassModal" class="modal-backdrop">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3>Edit Academic Class Details</h3>
      <button type="button" class="modal-close" onclick="closeModal('editClassModal')">&times;</button>
    </div>
    <form action="<?php echo base_url('admin/classes.php'); ?>" method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="edit_class_id" value="">
      
      <div class="modal-body">
        <div class="form-group">
          <label for="edit_class_name" class="form-label">Academic Class Name <span class="required">*</span></label>
          <input type="text" name="name" id="edit_class_name" class="form-control" placeholder="e.g. Computer Science - Year 3 Sec A" required>
        </div>
        <div class="form-group">
          <label for="edit_class_code" class="form-label">Class Code / Abbreviation <span class="required">*</span></label>
          <input type="text" name="code" id="edit_class_code" class="form-control" placeholder="e.g. CSE-3A" required maxlength="15">
        </div>
        <div class="form-group">
          <label for="edit_class_head" class="form-label">Class Teacher / Faculty In-Charge</label>
          <input type="text" name="head_name" id="edit_class_head" class="form-control" placeholder="e.g. Dr. Arvind Sharma">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('editClassModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script>
function editClass(id, name, code, headName) {
  document.getElementById('edit_class_id').value = id;
  document.getElementById('edit_class_name').value = name;
  document.getElementById('edit_class_code').value = code;
  document.getElementById('edit_class_head').value = headName || '';
  if (typeof window.openModal === 'function') {
    window.openModal('editClassModal');
  } else {
    var m = document.getElementById('editClassModal');
    if (m) m.classList.add('show');
  }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
