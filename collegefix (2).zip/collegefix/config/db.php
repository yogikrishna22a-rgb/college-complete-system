<?php
/**
 * CollegeFix - Database Configuration & Connection Handler
 * Supports standard MySQL (for XAMPP / Production) with seamless auto-fallback
 * to SQLite when running in cloud preview environments without a local MySQL daemon.
 */

define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'collegefix');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') !== false ? getenv('DB_PASS') : '');
define('DB_CHARSET', 'utf8mb4');

function get_db_connection() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $mysql_error = null;

    // 1. Attempt MySQL connection (Default for XAMPP)
    try {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 2,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        $GLOBALS['DB_DRIVER'] = 'mysql';
        return $pdo;
    } catch (PDOException $e) {
        $mysql_error = $e->getMessage();
    }

    // 2. Seamless Fallback to SQLite for Live Container Preview
    try {
        $sqlite_path = __DIR__ . '/collegefix.sqlite';
        $is_new = !file_exists($sqlite_path);
        
        $pdo = new PDO("sqlite:" . $sqlite_path);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec("PRAGMA foreign_keys = ON;");
        $GLOBALS['DB_DRIVER'] = 'sqlite';

        if ($is_new || filesize($sqlite_path) < 1000) {
            init_sqlite_database($pdo);
        }

        return $pdo;
    } catch (Exception $ex) {
        die("<div style='font-family:sans-serif;padding:30px;background:#fee2e2;color:#991b1b;border-radius:8px;max-width:600px;margin:50px auto;'>
            <h2>Database Connection Error</h2>
            <p><strong>MySQL Error:</strong> " . htmlspecialchars($mysql_error ?? 'Not connected') . "</p>
            <p><strong>SQLite Fallback Error:</strong> " . htmlspecialchars($ex->getMessage()) . "</p>
            <p>For XAMPP: Make sure MySQL is running in your XAMPP Control Panel and database <code>collegefix</code> is imported from <code>database.sql</code>.</p>
        </div>");
    }
}

/**
 * Initializes SQLite schema and initial seed data if running in container preview
 */
function init_sqlite_database($pdo) {
    $schema = "
    CREATE TABLE IF NOT EXISTS departments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        code TEXT NOT NULL UNIQUE,
        head_name TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        icon TEXT DEFAULT 'wrench',
        description TEXT,
        status TEXT DEFAULT 'Active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        role TEXT NOT NULL, -- 'admin', 'student', 'staff'
        student_id TEXT,
        staff_id TEXT,
        department_id INTEGER,
        specialization TEXT,
        phone TEXT,
        avatar TEXT,
        status TEXT DEFAULT 'Active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS complaints (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        complaint_code TEXT NOT NULL UNIQUE,
        user_id INTEGER NOT NULL,
        category_id INTEGER NOT NULL,
        department_id INTEGER,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        building TEXT NOT NULL,
        floor TEXT NOT NULL,
        room_number TEXT NOT NULL,
        priority TEXT DEFAULT 'Medium', -- 'Low', 'Medium', 'High', 'Emergency'
        status TEXT DEFAULT 'Submitted', -- 'Submitted', 'Under Review', 'Assigned', 'In Progress', 'Resolved', 'Reopened', 'Rejected'
        assigned_staff_id INTEGER,
        problem_image TEXT,
        resolution_image TEXT,
        resolution_notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        resolved_at DATETIME,
        closed_at DATETIME,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
        FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
        FOREIGN KEY (assigned_staff_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS complaint_updates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        complaint_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        update_type TEXT NOT NULL,
        status TEXT NOT NULL,
        notes TEXT,
        proof_image TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        complaint_id INTEGER,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        type TEXT DEFAULT 'info',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        complaint_id INTEGER NOT NULL UNIQUE,
        user_id INTEGER NOT NULL,
        rating INTEGER NOT NULL,
        is_satisfied INTEGER DEFAULT 1,
        comments TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS college_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        setting_key TEXT NOT NULL UNIQUE,
        setting_value TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    ";

    $pdo->exec($schema);

    // Insert departments
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO departments (id, name, code, head_name) VALUES (?, ?, ?, ?)");
    $departments = [
        [1, 'Computer Science & Engineering', 'CSE', 'Dr. Arvind Sharma'],
        [2, 'Electronics & Communication', 'ECE', 'Prof. Sunita Rao'],
        [3, 'Mechanical Engineering', 'MECH', 'Dr. Rajesh Verma'],
        [4, 'Civil Engineering', 'CIVIL', 'Prof. Priya Menon'],
        [5, 'Campus Maintenance & Estate', 'ESTATE', 'Mr. Ramesh Patel'],
    ];
    foreach ($departments as $d) $stmt->execute($d);

    // Insert categories
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO categories (id, name, icon, description, status) VALUES (?, ?, ?, ?, ?)");
    $categories = [
        [1, 'Electrical', 'zap', 'Switches, wiring, power outlets, circuit breakers', 'Active'],
        [2, 'Plumbing', 'droplet', 'Pipes, taps, water leaks, flush valves, drainage', 'Active'],
        [3, 'Classroom', 'book-open', 'Benches, podiums, whiteboards, doors and window latches', 'Active'],
        [4, 'Laboratory', 'flask', 'Lab equipment, test benches, ventilation hoods', 'Active'],
        [5, 'Projector', 'video', 'Display projectors, HDMI cables, projector screens', 'Active'],
        [6, 'Computer', 'monitor', 'Desktops, monitors, CPUs, peripherals, keyboards', 'Active'],
        [7, 'Internet / Wi-Fi', 'wifi', 'Campus Wi-Fi connectivity, LAN ports, routers', 'Active'],
        [8, 'Furniture', 'armchair', 'Desks, chairs, cupboards, library reading tables', 'Active'],
        [9, 'Fan / AC', 'wind', 'Ceiling fans, exhaust fans, air conditioner cooling', 'Active'],
        [10, 'Washroom', 'bath', 'Sanitation, hygiene, mirrors, dispensers, water flow', 'Active'],
        [11, 'Cleaning', 'sparkles', 'Spills, corridors, dust, trash bins, campus premises', 'Active'],
        [12, 'Hostel', 'home', 'Hostel rooms, mess facility, hot water, cot repair', 'Active'],
        [13, 'Library', 'library', 'Book racks, reading lights, library workstation issues', 'Active'],
        [14, 'Security', 'shield-alert', 'Gates, CCTV cameras, locks, street lights', 'Active'],
        [15, 'Other', 'help-circle', 'General campus or infrastructure issues not listed above', 'Active'],
    ];
    foreach ($categories as $c) $stmt->execute($c);

    // Insert users
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO users (id, name, email, password, role, student_id, staff_id, department_id, specialization, phone, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $users = [
        [1, 'Prof. S. R. Kulkarni (Principal / Admin)', 'admin@collegefix.edu', '$2y$10$PIxEN0LS7OeKwl9/fpNjFuiSMe0tnE1kk3H6Sm9WgF/6sfI4WciYq', 'admin', null, 'ADM-001', 5, 'Administration', '+91 9876543210', 'Active'],
        [2, 'Rahul Sharma (Student)', 'student@collegefix.edu', '$2y$10$lBdXNgCXD/vaLznyfh.96OpQ..CjT1Tk5PdCikCFqsFSgtCOIlKa.', 'student', 'STU2024001', null, 1, null, '+91 9811223344', 'Active'],
        [3, 'Mahesh Kumar (Electrical Tech)', 'staff@collegefix.edu', '$2y$10$WEFhrYUcFdpcVbMP5m4.oerN.aOpccL5eRcpTbWgxmy1PxA18wolS', 'staff', null, 'STF-E01', 5, 'Electrical & Lighting', '+91 9722334455', 'Active'],
        [4, 'Suresh Patil (Plumbing Tech)', 'plumbing@collegefix.edu', '$2y$10$WEFhrYUcFdpcVbMP5m4.oerN.aOpccL5eRcpTbWgxmy1PxA18wolS', 'staff', null, 'STF-P02', 5, 'Plumbing & Sanitation', '+91 9733445566', 'Active'],
        [5, 'Amit Sen (Network Tech)', 'network@collegefix.edu', '$2y$10$WEFhrYUcFdpcVbMP5m4.oerN.aOpccL5eRcpTbWgxmy1PxA18wolS', 'staff', null, 'STF-N03', 1, 'Network & Hardware', '+91 9744556677', 'Active'],
        [6, 'Priya Nair (Student)', 'priya@collegefix.edu', '$2y$10$lBdXNgCXD/vaLznyfh.96OpQ..CjT1Tk5PdCikCFqsFSgtCOIlKa.', 'student', 'STU2024002', null, 2, null, '+91 9833445566', 'Active'],
    ];
    foreach ($users as $u) $stmt->execute($u);

    // Insert complaints
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO complaints (id, complaint_code, user_id, category_id, department_id, title, description, building, floor, room_number, priority, status, assigned_staff_id, created_at, updated_at, resolved_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $complaints = [
        [1, 'CMP1001', 2, 1, 1, 'Sparking Switchboard in CSE Lab 3', 'The main plug switchboard near Row B is sparking intermittently when laptops are plugged in. Potential safety hazard.', 'Science & Tech Block', '2nd Floor', 'Lab 204', 'Emergency', 'In Progress', 3, '2026-09-15 09:30:00', '2026-09-15 14:15:00', null],
        [2, 'CMP1002', 2, 2, 5, 'Continuous Water Leakage in 1st Floor Washroom', 'Washbasin tap in the mens washroom is continuously dripping and the drain is partially clogged.', 'Main Administrative Building', '1st Floor', 'WR-102', 'High', 'Assigned', 4, '2026-09-16 10:00:00', '2026-09-16 11:20:00', null],
        [3, 'CMP1003', 6, 5, 1, 'Overhead Projector Flickering in Seminar Hall B', 'The HDMI connection flickers every 30 seconds, turning the screen pink/black during lectures.', 'Auditorium Complex', 'Ground Floor', 'Seminar Hall B', 'Medium', 'Submitted', null, '2026-09-16 15:45:00', '2026-09-16 15:45:00', null],
        [4, 'CMP1004', 6, 7, 1, 'Wi-Fi Access Point Offline in 3rd Floor Library', 'No internet connection through AP-LIB-3F. Students cannot access research database portals.', 'Central Library', '3rd Floor', 'Digital Reference Room', 'High', 'Resolved', 5, '2026-09-14 08:30:00', '2026-09-14 16:30:00', '2026-09-14 16:30:00'],
    ];
    foreach ($complaints as $cmp) $stmt->execute($cmp);

    // Insert complaint updates
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO complaint_updates (id, complaint_id, user_id, update_type, status, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $updates = [
        [1, 1, 2, 'Creation', 'Submitted', 'Complaint registered with Emergency priority due to electric sparks.', '2026-09-15 09:30:00'],
        [2, 1, 1, 'Review & Assignment', 'Assigned', 'Assigned to Mahesh Kumar (Senior Electrician) for immediate site inspection.', '2026-09-15 10:00:00'],
        [3, 1, 3, 'Work Progress', 'In Progress', 'Arrived at Lab 204. Power isolated for safety. Replacing damaged 16A MCB and terminal wires.', '2026-09-15 14:15:00'],
        [4, 2, 2, 'Creation', 'Submitted', 'Reported water tap dripping.', '2026-09-16 10:00:00'],
        [5, 2, 1, 'Assignment', 'Assigned', 'Assigned to Suresh Patil (Plumbing).', '2026-09-16 11:20:00'],
        [6, 3, 2, 'Creation', 'Submitted', 'Complaint submitted for projector flickering.', '2026-09-16 15:45:00'],
        [7, 4, 2, 'Creation', 'Submitted', 'Wi-Fi AP not working in Library.', '2026-09-14 08:30:00'],
        [8, 4, 1, 'Assignment', 'Assigned', 'Assigned to Amit Sen (Network Tech).', '2026-09-14 09:00:00'],
        [9, 4, 5, 'Resolution', 'Resolved', 'PoE switch port was rebooted and firmware re-synced. Signal coverage verified at 85Mbps.', '2026-09-14 16:30:00'],
    ];
    foreach ($updates as $up) $stmt->execute($up);

    // Insert feedback
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO feedback (id, complaint_id, user_id, rating, is_satisfied, comments, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([1, 4, 2, 5, 1, 'Prompt resolution by the network team! Wi-Fi speed is restored.', '2026-09-14 17:00:00']);

    // Insert notifications
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO notifications (id, user_id, complaint_id, title, message, is_read, type, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $notifs = [
        [1, 2, 1, 'Complaint In Progress', 'Your complaint #CMP1001 is now In Progress by Mahesh Kumar.', 0, 'info', '2026-09-15 14:15:00'],
        [2, 3, 1, 'New Emergency Task Assigned', 'Admin assigned Emergency complaint #CMP1001 (Sparking Switchboard) to you.', 0, 'warning', '2026-09-15 10:00:00'],
        [3, 2, 4, 'Complaint Resolved', 'Complaint #CMP1004 has been marked as resolved by Amit Sen. Please confirm resolution.', 1, 'success', '2026-09-14 16:30:00'],
        [4, 1, 1, 'Emergency Alert', 'New Emergency complaint #CMP1001 submitted by Rahul Sharma.', 0, 'danger', '2026-09-15 09:30:00'],
    ];
    foreach ($notifs as $n) $stmt->execute($n);

    // Insert college settings
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO college_settings (id, setting_key, setting_value) VALUES (?, ?, ?)");
    $settings = [
        [1, 'college_name', 'National Institute of Engineering & Technology'],
        [2, 'college_short_name', 'NIET College'],
        [3, 'contact_email', 'maintenance@collegefix.edu'],
        [4, 'contact_phone', '+91 (080) 2839-4455'],
        [5, 'campus_address', 'Knowledge Corridor, Tech Campus, Gate No. 2'],
        [6, 'allow_student_registration', '1'],
        [7, 'auto_assign_category_lead', '0'],
        [8, 'maintenance_working_hours', '8:00 AM - 6:00 PM (Emergency 24x7)'],
    ];
    foreach ($settings as $s) $stmt->execute($s);
}

// Initial check when included
$conn = get_db_connection();
