-- ==========================================================
-- CollegeFix: College Complaint & Maintenance Management System
-- Database: `collegefix`
-- Compatible with MySQL 5.7+, MySQL 8.0+, MariaDB (XAMPP default)
-- ==========================================================

CREATE DATABASE IF NOT EXISTS `collegefix` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `collegefix`;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `feedback`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `complaint_updates`;
DROP TABLE IF EXISTS `complaints`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `departments`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `college_settings`;
SET FOREIGN_KEY_CHECKS = 1;

-- --------------------------------------------------------
-- Table structure for `departments`
-- --------------------------------------------------------
CREATE TABLE `departments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `code` VARCHAR(20) NOT NULL UNIQUE,
  `head_name` VARCHAR(100) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `categories`
-- --------------------------------------------------------
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `icon` VARCHAR(50) DEFAULT 'wrench',
  `description` TEXT NULL,
  `status` ENUM('Active', 'Inactive') DEFAULT 'Active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `users`
-- --------------------------------------------------------
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'student', 'staff') NOT NULL,
  `student_id` VARCHAR(50) NULL,
  `staff_id` VARCHAR(50) NULL,
  `department_id` INT NULL,
  `specialization` VARCHAR(100) NULL,
  `phone` VARCHAR(25) NULL,
  `avatar` VARCHAR(255) NULL,
  `status` ENUM('Active', 'Inactive', 'Suspended') DEFAULT 'Active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `complaints`
-- --------------------------------------------------------
CREATE TABLE `complaints` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `complaint_code` VARCHAR(30) NOT NULL UNIQUE,
  `user_id` INT NOT NULL,
  `category_id` INT NOT NULL,
  `department_id` INT NULL,
  `title` VARCHAR(200) NOT NULL,
  `description` TEXT NOT NULL,
  `building` VARCHAR(100) NOT NULL,
  `floor` VARCHAR(50) NOT NULL,
  `room_number` VARCHAR(50) NOT NULL,
  `priority` ENUM('Low', 'Medium', 'High', 'Emergency') NOT NULL DEFAULT 'Medium',
  `status` ENUM('Submitted', 'Under Review', 'Assigned', 'In Progress', 'Resolved', 'Reopened', 'Rejected') NOT NULL DEFAULT 'Submitted',
  `assigned_staff_id` INT NULL,
  `problem_image` VARCHAR(255) NULL,
  `resolution_image` VARCHAR(255) NULL,
  `resolution_notes` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `resolved_at` DATETIME NULL,
  `closed_at` DATETIME NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`assigned_staff_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `complaint_updates` (Status & Work Timeline)
-- --------------------------------------------------------
CREATE TABLE `complaint_updates` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `complaint_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `update_type` VARCHAR(50) NOT NULL,
  `status` VARCHAR(50) NOT NULL,
  `notes` TEXT NULL,
  `proof_image` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`complaint_id`) REFERENCES `complaints`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `notifications`
-- --------------------------------------------------------
CREATE TABLE `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `complaint_id` INT NULL,
  `title` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `type` VARCHAR(50) DEFAULT 'info',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`complaint_id`) REFERENCES `complaints`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `feedback`
-- --------------------------------------------------------
CREATE TABLE `feedback` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `complaint_id` INT NOT NULL UNIQUE,
  `user_id` INT NOT NULL,
  `rating` INT NOT NULL CHECK (`rating` >= 1 AND `rating` <= 5),
  `is_satisfied` TINYINT(1) DEFAULT 1,
  `comments` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`complaint_id`) REFERENCES `complaints`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Table structure for `college_settings`
-- --------------------------------------------------------
CREATE TABLE `college_settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `setting_key` VARCHAR(100) NOT NULL UNIQUE,
  `setting_value` TEXT NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- SEED DATA
-- ==========================================================

-- Departments
INSERT INTO `departments` (`id`, `name`, `code`, `head_name`) VALUES
(1, 'Computer Science & Engineering', 'CSE', 'Dr. Arvind Sharma'),
(2, 'Electronics & Communication', 'ECE', 'Prof. Sunita Rao'),
(3, 'Mechanical Engineering', 'MECH', 'Dr. Rajesh Verma'),
(4, 'Civil Engineering', 'CIVIL', 'Prof. Priya Menon'),
(5, 'Campus Maintenance & Estate', 'ESTATE', 'Mr. Ramesh Patel');

-- Categories
INSERT INTO `categories` (`id`, `name`, `icon`, `description`, `status`) VALUES
(1, 'Electrical', 'zap', 'Switches, wiring, power outlets, circuit breakers', 'Active'),
(2, 'Plumbing', 'droplet', 'Pipes, taps, water leaks, flush valves, drainage', 'Active'),
(3, 'Classroom', 'book-open', 'Benches, podiums, whiteboards, doors and window latches', 'Active'),
(4, 'Laboratory', 'flask', 'Lab equipment, test benches, ventilation hoods', 'Active'),
(5, 'Projector', 'video', 'Display projectors, HDMI cables, projector screens', 'Active'),
(6, 'Computer', 'monitor', 'Desktops, monitors, CPUs, peripherals, keyboards', 'Active'),
(7, 'Internet / Wi-Fi', 'wifi', 'Campus Wi-Fi connectivity, LAN ports, routers', 'Active'),
(8, 'Furniture', 'armchair', 'Desks, chairs, cupboards, library reading tables', 'Active'),
(9, 'Fan / AC', 'wind', 'Ceiling fans, exhaust fans, air conditioner cooling', 'Active'),
(10, 'Washroom', 'bath', 'Sanitation, hygiene, mirrors, dispensers, water flow', 'Active'),
(11, 'Cleaning', 'sparkles', 'Spills, corridors, dust, trash bins, campus premises', 'Active'),
(12, 'Hostel', 'home', 'Hostel rooms, mess facility, hot water, cot repair', 'Active'),
(13, 'Library', 'library', 'Book racks, reading lights, library workstation issues', 'Active'),
(14, 'Security', 'shield-alert', 'Gates, CCTV cameras, locks, street lights', 'Active'),
(15, 'Other', 'help-circle', 'General campus or infrastructure issues not listed above', 'Active');

-- Demo Users
-- Passwords:
-- Admin: Admin@123
-- Student: Student@123
-- Staff: Staff@123
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `student_id`, `staff_id`, `department_id`, `specialization`, `phone`, `status`) VALUES
(1, 'Prof. S. R. Kulkarni (Principal / Admin)', 'admin@collegefix.edu', '$2y$10$PIxEN0LS7OeKwl9/fpNjFuiSMe0tnE1kk3H6Sm9WgF/6sfI4WciYq', 'admin', NULL, 'ADM-001', 5, 'Administration', '+91 9876543210', 'Active'),
(2, 'Rahul Sharma (Student)', 'student@collegefix.edu', '$2y$10$lBdXNgCXD/vaLznyfh.96OpQ..CjT1Tk5PdCikCFqsFSgtCOIlKa.', 'student', 'STU2024001', NULL, 1, NULL, '+91 9811223344', 'Active'),
(3, 'Mahesh Kumar (Electrical Tech)', 'staff@collegefix.edu', '$2y$10$WEFhrYUcFdpcVbMP5m4.oerN.aOpccL5eRcpTbWgxmy1PxA18wolS', 'staff', NULL, 'STF-E01', 5, 'Electrical & Lighting', '+91 9722334455', 'Active'),
(4, 'Suresh Patil (Plumbing Tech)', 'plumbing@collegefix.edu', '$2y$10$WEFhrYUcFdpcVbMP5m4.oerN.aOpccL5eRcpTbWgxmy1PxA18wolS', 'staff', NULL, 'STF-P02', 5, 'Plumbing & Sanitation', '+91 9733445566', 'Active'),
(5, 'Amit Sen (Network Tech)', 'network@collegefix.edu', '$2y$10$WEFhrYUcFdpcVbMP5m4.oerN.aOpccL5eRcpTbWgxmy1PxA18wolS', 'staff', NULL, 'STF-N03', 1, 'Network & Hardware', '+91 9744556677', 'Active');

-- Sample Complaints
INSERT INTO `complaints` (`id`, `complaint_code`, `user_id`, `category_id`, `department_id`, `title`, `description`, `building`, `floor`, `room_number`, `priority`, `status`, `assigned_staff_id`, `created_at`, `updated_at`, `resolved_at`) VALUES
(1, 'CMP1001', 2, 1, 1, 'Sparking Switchboard in CSE Lab 3', 'The main plug switchboard near Row B is sparking intermittently when laptops are plugged in. Potential safety hazard.', 'Science & Tech Block', '2nd Floor', 'Lab 204', 'Emergency', 'In Progress', 3, '2026-09-15 09:30:00', '2026-09-15 14:15:00', NULL),
(2, 'CMP1002', 2, 2, 5, 'Continuous Water Leakage in 1st Floor Washroom', 'Washbasin tap in the mens washroom is continuously dripping and the drain is partially clogged.', 'Main Administrative Building', '1st Floor', 'WR-102', 'High', 'Assigned', 4, '2026-09-16 10:00:00', '2026-09-16 11:20:00', NULL),
(3, 'CMP1003', 2, 5, 1, 'Overhead Projector Flickering in Seminar Hall B', 'The HDMI connection flickers every 30 seconds, turning the screen pink/black during lectures.', 'Auditorium Complex', 'Ground Floor', 'Seminar Hall B', 'Medium', 'Submitted', NULL, '2026-09-16 15:45:00', '2026-09-16 15:45:00', NULL),
(4, 'CMP1004', 2, 7, 1, 'Wi-Fi Access Point Offline in 3rd Floor Library', 'No internet connection through AP-LIB-3F. Students cannot access research database portals.', 'Central Library', '3rd Floor', 'Digital Reference Room', 'High', 'Resolved', 5, '2026-09-14 08:30:00', '2026-09-14 16:30:00', '2026-09-14 16:30:00');

-- Complaint Updates
INSERT INTO `complaint_updates` (`complaint_id`, `user_id`, `update_type`, `status`, `notes`, `created_at`) VALUES
(1, 2, 'Creation', 'Submitted', 'Complaint registered with Emergency priority due to electric sparks.', '2026-09-15 09:30:00'),
(1, 1, 'Review & Assignment', 'Assigned', 'Assigned to Mahesh Kumar (Senior Electrician) for immediate site inspection.', '2026-09-15 10:00:00'),
(1, 3, 'Work Progress', 'In Progress', 'Arrived at Lab 204. Power isolated for safety. Replacing damaged 16A MCB and terminal wires.', '2026-09-15 14:15:00'),
(2, 2, 'Creation', 'Submitted', 'Reported water tap dripping.', '2026-09-16 10:00:00'),
(2, 1, 'Assignment', 'Assigned', 'Assigned to Suresh Patil (Plumbing).', '2026-09-16 11:20:00'),
(3, 2, 'Creation', 'Submitted', 'Complaint submitted for projector flickering.', '2026-09-16 15:45:00'),
(4, 2, 'Creation', 'Submitted', 'Wi-Fi AP not working in Library.', '2026-09-14 08:30:00'),
(4, 1, 'Assignment', 'Assigned', 'Assigned to Amit Sen (Network Tech).', '2026-09-14 09:00:00'),
(4, 5, 'Resolution', 'Resolved', 'PoE switch port was rebooted and firmware re-synced. Signal coverage verified at 85Mbps.', '2026-09-14 16:30:00');

-- Sample Feedback for Resolved Complaint CMP1004
INSERT INTO `feedback` (`complaint_id`, `user_id`, `rating`, `is_satisfied`, `comments`, `created_at`) VALUES
(4, 2, 5, 1, 'Prompt resolution by the network team! Wi-Fi speed is restored.', '2026-09-14 17:00:00');

-- Notifications
INSERT INTO `notifications` (`user_id`, `complaint_id`, `title`, `message`, `is_read`, `type`, `created_at`) VALUES
(2, 1, 'Complaint In Progress', 'Your complaint #CMP1001 is now In Progress by Mahesh Kumar.', 0, 'info', '2026-09-15 14:15:00'),
(3, 1, 'New Emergency Task Assigned', 'Admin assigned Emergency complaint #CMP1001 (Sparking Switchboard) to you.', 0, 'warning', '2026-09-15 10:00:00'),
(2, 4, 'Complaint Resolved', 'Complaint #CMP1004 has been marked as resolved by Amit Sen. Please confirm resolution.', 1, 'success', '2026-09-14 16:30:00'),
(1, 1, 'Emergency Alert', 'New Emergency complaint #CMP1001 submitted by Rahul Sharma.', 0, 'danger', '2026-09-15 09:30:00');

-- College Settings
INSERT INTO `college_settings` (`setting_key`, `setting_value`) VALUES
('college_name', 'National Institute of Engineering & Technology'),
('college_short_name', 'NIET College'),
('contact_email', 'maintenance@collegefix.edu'),
('contact_phone', '+91 (080) 2839-4455'),
('campus_address', 'Knowledge Corridor, Tech Campus, Gate No. 2'),
('allow_student_registration', '1'),
('auto_assign_category_lead', '0'),
('maintenance_working_hours', '8:00 AM - 6:00 PM (Emergency 24x7)');
