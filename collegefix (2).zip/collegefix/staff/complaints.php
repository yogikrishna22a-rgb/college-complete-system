<?php
/**
 * CollegeFix - Staff Resolved / Completed Tasks History
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['staff']);

$user = current_user();
$staff_id = $user['id'];

try {
    $stmt = $conn->prepare("
        SELECT c.*, cat.name as category_name, u.name as student_name, fb.rating, fb.comments as feedback_comments
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN users u ON c.user_id = u.id
        LEFT JOIN feedback fb ON c.id = fb.complaint_id
        WHERE c.assigned_staff_id = ? AND c.status IN ('Resolved', 'Closed')
        ORDER BY c.resolved_at DESC
    ");
    $stmt->execute([$staff_id]);
    $completed_tasks = $stmt->fetchAll();
} catch (Exception $e) {
    set_flash('danger', 'Error loading history: ' . $e->getMessage());
    $completed_tasks = [];
}

$page_title = 'Completed Work History - CollegeFix';
$active_menu = 'complaints';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>Completed Maintenance History</h1>
    <p>Archive of work orders you resolved, student feedback ratings, and verified closures.</p>
  </div>
</div>

<div class="content-card">
  <div class="card-header">
    <h3>Resolved Tickets (<?php echo count($completed_tasks); ?> total)</h3>
  </div>
  <div class="card-body card-body-table">
    <?php if (empty($completed_tasks)): ?>
      <div style="padding: 40px; text-align: center; color: var(--text-muted);">
        <i data-lucide="archive" style="width: 44px; height: 44px; margin: 0 auto 12px; color: #94a3b8;"></i>
        <p style="font-size: 15px; font-weight: 600;">No resolved tickets logged yet</p>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Ticket</th>
              <th>Issue Title</th>
              <th>Location</th>
              <th>Category</th>
              <th>Status</th>
              <th>Student Feedback</th>
              <th>Resolved Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($completed_tasks as $t): ?>
              <tr>
                <td>
                  <a href="<?php echo base_url('staff/task_view.php?id=' . $t['id']); ?>" class="table-code">
                    #<?php echo clean($t['complaint_code']); ?>
                  </a>
                </td>
                <td>
                  <strong style="color: var(--text-main);"><?php echo clean($t['title']); ?></strong>
                  <?php if (!empty($t['resolution_notes'])): ?>
                    <div style="font-size: 11px; color: #047857; margin-top: 2px;">
                      Resolution: <?php echo clean(mb_strimwidth($t['resolution_notes'], 0, 45, '...')); ?>
                    </div>
                  <?php endif; ?>
                </td>
                <td><?php echo clean($t['building'] . ' - ' . $t['room_number']); ?></td>
                <td><?php echo clean($t['category_name']); ?></td>
                <td><?php echo get_status_badge($t['status']); ?></td>
                <td>
                  <?php if ($t['rating']): ?>
                    <div style="color: #f59e0b; font-size: 13px;">
                      <?php echo str_repeat('&#9733;', $t['rating']); ?>
                      <span style="color: var(--text-muted); font-size: 11px;">(<?php echo $t['rating']; ?>/5)</span>
                    </div>
                  <?php else: ?>
                    <span style="font-size: 11px; color: var(--text-muted);">Pending rating</span>
                  <?php endif; ?>
                </td>
                <td style="font-size: 12px; color: var(--text-muted);">
                  <?php echo format_datetime($t['resolved_at'] ?? $t['updated_at']); ?>
                </td>
                <td>
                  <a href="<?php echo base_url('staff/task_view.php?id=' . $t['id']); ?>" class="btn btn-sm btn-secondary">
                    View
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
