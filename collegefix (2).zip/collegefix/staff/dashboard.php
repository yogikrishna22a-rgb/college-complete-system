<?php
/**
 * CollegeFix - Maintenance Staff Dashboard
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['staff']);

$user = current_user();
$staff_id = $user['id'];

// Get staff metrics
$counts = [
    'assigned'    => 0,
    'in_progress' => 0,
    'resolved'    => 0,
    'emergency'   => 0
];

try {
    $stmt = $conn->prepare("
        SELECT 
            SUM(CASE WHEN status = 'Assigned' THEN 1 ELSE 0 END) as assigned,
            SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN status IN ('Resolved', 'Closed') THEN 1 ELSE 0 END) as resolved,
            SUM(CASE WHEN priority = 'Emergency' AND status NOT IN ('Resolved', 'Closed', 'Rejected') THEN 1 ELSE 0 END) as emergency
        FROM complaints 
        WHERE assigned_staff_id = ?
    ");
    $stmt->execute([$staff_id]);
    $res = $stmt->fetch();
    if ($res) {
        $counts['assigned']    = (int)($res['assigned'] ?? 0);
        $counts['in_progress'] = (int)($res['in_progress'] ?? 0);
        $counts['resolved']    = (int)($res['resolved'] ?? 0);
        $counts['emergency']   = (int)($res['emergency'] ?? 0);
    }

    // Fetch active tasks for staff
    $stmt = $conn->prepare("
        SELECT c.*, cat.name as category_name, u.name as student_name, u.phone as student_phone
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN users u ON c.user_id = u.id
        WHERE c.assigned_staff_id = ? AND c.status IN ('Assigned', 'In Progress', 'Reopened')
        ORDER BY 
            CASE c.priority 
                WHEN 'Emergency' THEN 1 
                WHEN 'High' THEN 2 
                WHEN 'Medium' THEN 3 
                ELSE 4 
            END ASC,
            c.created_at ASC
    ");
    $stmt->execute([$staff_id]);
    $active_tasks = $stmt->fetchAll();

} catch (Exception $e) {
    set_flash('danger', 'Error loading dashboard metrics: ' . $e->getMessage());
    $active_tasks = [];
}

$page_title = 'Staff Dashboard - CollegeFix';
$active_menu = 'dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>Staff Dashboard: <?php echo clean($user['name']); ?></h1>
    <p>Maintenance Operations &bull; Specialization: <strong><?php echo clean($user['specialization'] ?? 'Campus Technician'); ?></strong></p>
  </div>
  <div class="page-actions">
    <a href="<?php echo base_url('staff/tasks.php'); ?>" class="btn btn-primary">
      <i data-lucide="check-square"></i>
      <span>View All Assigned Tasks</span>
    </a>
  </div>
</div>

<!-- Stat Cards -->
<div class="stats-grid">
  <div class="stat-card stat-warning">
    <div class="stat-content">
      <h3>New Assigned</h3>
      <div class="stat-number"><?php echo $counts['assigned']; ?></div>
      <div class="stat-subtext">Awaiting your response</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="inbox"></i>
    </div>
  </div>

  <div class="stat-card stat-info">
    <div class="stat-content">
      <h3>In Progress</h3>
      <div class="stat-number"><?php echo $counts['in_progress']; ?></div>
      <div class="stat-subtext">Work currently underway</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="wrench"></i>
    </div>
  </div>

  <div class="stat-card stat-success">
    <div class="stat-content">
      <h3>Completed</h3>
      <div class="stat-number"><?php echo $counts['resolved']; ?></div>
      <div class="stat-subtext">Successfully resolved tickets</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="check-circle-2"></i>
    </div>
  </div>

  <div class="stat-card stat-emergency">
    <div class="stat-content">
      <h3>Emergency Tasks</h3>
      <div class="stat-number"><?php echo $counts['emergency']; ?></div>
      <div class="stat-subtext">Requires immediate intervention</div>
    </div>
    <div class="stat-icon-wrapper">
      <i data-lucide="alert-triangle"></i>
    </div>
  </div>
</div>

<!-- Active Work Orders Table -->
<div class="content-card">
  <div class="card-header">
    <h3>Active Work Orders Requiring Attention</h3>
    <span style="font-size: 13px; color: var(--text-muted);">Sorted by Priority & Urgency</span>
  </div>
  <div class="card-body card-body-table">
    <?php if (empty($active_tasks)): ?>
      <div style="padding: 40px; text-align: center; color: var(--text-muted);">
        <i data-lucide="smile" style="width: 48px; height: 48px; margin: 0 auto 12px; color: #10b981;"></i>
        <p style="font-size: 15px; font-weight: 600;">No pending tasks assigned to you right now!</p>
        <p style="font-size: 13px; margin-top: 4px;">Great job! When the administration assigns tickets in your field, they will appear here.</p>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Ticket #</th>
              <th>Task Details</th>
              <th>Location</th>
              <th>Priority</th>
              <th>Status</th>
              <th>Reported By</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($active_tasks as $t): ?>
              <tr style="<?php echo ($t['priority'] === 'Emergency') ? 'background: #fff1f2;' : ''; ?>">
                <td>
                  <a href="<?php echo base_url('staff/task_view.php?id=' . $t['id']); ?>" class="table-code">
                    #<?php echo clean($t['complaint_code']); ?>
                  </a>
                </td>
                <td>
                  <strong style="color: var(--text-main); font-size: 14px;"><?php echo clean($t['title']); ?></strong>
                  <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                    Category: <?php echo clean($t['category_name']); ?>
                  </div>
                </td>
                <td>
                  <strong style="font-size: 13px;"><?php echo clean($t['building']); ?></strong>
                  <div style="font-size: 12px; color: var(--text-muted);"><?php echo clean($t['floor'] . ' &bull; ' . $t['room_number']); ?></div>
                </td>
                <td><?php echo get_priority_badge($t['priority']); ?></td>
                <td><?php echo get_status_badge($t['status']); ?></td>
                <td>
                  <span style="font-weight: 500; font-size: 13px;"><?php echo clean($t['student_name']); ?></span>
                  <?php if (!empty($t['student_phone'])): ?>
                    <div style="font-size: 11px; color: var(--text-muted);"><?php echo clean($t['student_phone']); ?></div>
                  <?php endif; ?>
                </td>
                <td>
                  <a href="<?php echo base_url('staff/task_view.php?id=' . $t['id']); ?>" class="btn btn-sm btn-primary">
                    Manage Task
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
