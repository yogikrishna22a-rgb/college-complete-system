<?php
/**
 * CollegeFix - Staff Task View & Resolution Management
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['staff']);

$user = current_user();
$staff_id = $user['id'];
$task_id = (int)($_GET['id'] ?? 0);

if (!$task_id) {
    set_flash('danger', 'Task not found.');
    redirect('staff/tasks.php');
}

// Handle Staff Update Action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = $_POST['status'] ?? 'In Progress';
    $notes      = trim($_POST['notes'] ?? '');

    if (empty($notes)) {
        set_flash('danger', 'Please enter work notes describing the actions taken.');
    } else {
        // Handle resolution image upload if provided
        $image_upload = handle_image_upload('proof_image', 'resolutions');
        if (!$image_upload['success']) {
            set_flash('danger', $image_upload['error']);
        } else {
            $proof_filename = $image_upload['filename'];
            $now = date('Y-m-d H:i:s');

            try {
                // Update complaint
                if ($new_status === 'Resolved') {
                    $stmt_up_cmp = $conn->prepare("
                        UPDATE complaints 
                        SET status = 'Resolved', resolution_notes = ?, resolution_image = COALESCE(?, resolution_image), resolved_at = ?, updated_at = ?
                        WHERE id = ? AND assigned_staff_id = ?
                    ");
                    $stmt_up_cmp->execute([$notes, $proof_filename, $now, $now, $task_id, $staff_id]);
                } else {
                    $stmt_up_cmp = $conn->prepare("
                        UPDATE complaints 
                        SET status = ?, updated_at = ?
                        WHERE id = ? AND assigned_staff_id = ?
                    ");
                    $stmt_up_cmp->execute([$new_status, $now, $task_id, $staff_id]);
                }

                // Add to timeline updates
                $stmt_timeline = $conn->prepare("
                    INSERT INTO complaint_updates (complaint_id, user_id, update_type, status, notes, proof_image, created_at)
                    VALUES (?, ?, 'Staff Update', ?, ?, ?, ?)
                ");
                $stmt_timeline->execute([$task_id, $staff_id, $new_status, $notes, $proof_filename, $now]);

                // Fetch complaint user to notify them
                $stmt_user = $conn->prepare("SELECT user_id, complaint_code FROM complaints WHERE id = ?");
                $stmt_user->execute([$task_id]);
                $c_info = $stmt_user->fetch();

                if ($c_info) {
                    $msg_title = ($new_status === 'Resolved') ? "Complaint #{$c_info['complaint_code']} Resolved" : "Work Started on #{$c_info['complaint_code']}";
                    $msg_body = ($new_status === 'Resolved') 
                        ? "Technician {$user['name']} has marked your complaint as resolved: \"{$notes}\". Please check and confirm."
                        : "Technician {$user['name']} updated status to {$new_status}: \"{$notes}\".";
                    $notif_type = ($new_status === 'Resolved') ? 'success' : 'info';

                    create_notification($conn, $c_info['user_id'], $task_id, $msg_title, $msg_body, $notif_type);
                }

                set_flash('success', "Work order successfully updated to '{$new_status}'.");
                redirect('staff/task_view.php?id=' . $task_id);

            } catch (Exception $e) {
                set_flash('danger', 'Error updating task: ' . $e->getMessage());
            }
        }
    }
}

// Fetch task details
try {
    $stmt = $conn->prepare("
        SELECT c.*, cat.name as category_name, d.name as department_name, 
               u.name as student_name, u.email as student_email, u.phone as student_phone, u.student_id as student_roll
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN users u ON c.user_id = u.id
        WHERE c.id = ? AND c.assigned_staff_id = ?
    ");
    $stmt->execute([$task_id, $staff_id]);
    $task = $stmt->fetch();

    if (!$task) {
        set_flash('danger', 'Task not found or not assigned to you.');
        redirect('staff/tasks.php');
    }

    // Updates timeline
    $stmt_up = $conn->prepare("
        SELECT cu.*, u.name as user_name, u.role as user_role
        FROM complaint_updates cu
        LEFT JOIN users u ON cu.user_id = u.id
        WHERE cu.complaint_id = ?
        ORDER BY cu.created_at ASC
    ");
    $stmt_up->execute([$task_id]);
    $timeline_updates = $stmt_up->fetchAll();

} catch (Exception $e) {
    set_flash('danger', 'Error loading task details: ' . $e->getMessage());
    redirect('staff/tasks.php');
}

$page_title = 'Task #' . clean($task['complaint_code']) . ' - CollegeFix';
$active_menu = 'tasks';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <div style="display: flex; align-items: center; gap: 10px;">
      <h1>Task #<?php echo clean($task['complaint_code']); ?></h1>
      <?php echo get_status_badge($task['status']); ?>
      <?php echo get_priority_badge($task['priority']); ?>
    </div>
    <p>Assigned on <?php echo format_datetime($task['created_at']); ?> &bull; Room: <strong><?php echo clean($task['building'] . ', ' . $task['room_number']); ?></strong></p>
  </div>
  <div class="page-actions">
    <a href="<?php echo base_url('staff/tasks.php'); ?>" class="btn btn-secondary">
      <i data-lucide="arrow-left"></i>
      <span>Back to Task List</span>
    </a>
  </div>
</div>

<div class="complaint-view-grid">
  
  <!-- Left Column: Details & Update Action -->
  <div>
    
    <!-- Issue Overview -->
    <div class="content-card">
      <div class="card-header">
        <h3><?php echo clean($task['title']); ?></h3>
        <span style="font-size: 13px; color: var(--text-muted);">
          Category: <strong><?php echo clean($task['category_name']); ?></strong>
        </span>
      </div>
      <div class="card-body">
        <h4 style="font-size: 13px; font-weight: 600; color: var(--text-muted); margin-bottom: 6px;">Reported Issue Description</h4>
        <div style="font-size: 14px; line-height: 1.6; color: var(--text-main); background: #f8fafc; padding: 14px; border-radius: var(--radius-sm); border: 1px solid var(--border-color); white-space: pre-line;">
          <?php echo clean($task['description']); ?>
        </div>

        <!-- Problem photo from student -->
        <?php if (!empty($task['problem_image'])): ?>
          <h4 style="font-size: 13px; font-weight: 600; color: var(--text-muted); margin-top: 18px; margin-bottom: 8px;">Photo Provided by Student</h4>
          <div class="image-preview-card">
            <img src="<?php echo base_url('uploads/complaints/' . $task['problem_image']); ?>" alt="Reported problem" onclick="window.open(this.src, '_blank')">
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Staff Work Update Form -->
    <?php if ($task['status'] !== 'Closed'): ?>
      <div class="content-card" style="border: 2px solid #2563eb;">
        <div class="card-header" style="background: #eff6ff;">
          <h3 style="color: #1e40af; display: flex; align-items: center; gap: 8px;">
            <i data-lucide="wrench"></i>
            <span>Log Work Progress or Mark Resolved</span>
          </h3>
        </div>
        <div class="card-body">
          <form action="<?php echo base_url('staff/task_view.php?id=' . $task_id); ?>" method="POST" enctype="multipart/form-data">
            
            <div class="form-group">
              <label for="status" class="form-label">Update Task Status <span class="required">*</span></label>
              <select name="status" id="status" class="form-control" required>
                <option value="In Progress" <?php echo ($task['status'] === 'In Progress' || $task['status'] === 'Assigned') ? 'selected' : ''; ?>>
                  🛠️ In Progress (Diagnosing or work underway)
                </option>
                <option value="Resolved" <?php echo ($task['status'] === 'Resolved') ? 'selected' : ''; ?>>
                  ✅ Resolved (Repair completed, ready for student sign-off)
                </option>
              </select>
            </div>

            <div class="form-group">
              <label for="notes" class="form-label">Work Notes / Action Taken <span class="required">*</span></label>
              <textarea name="notes" id="notes" class="form-control" rows="3" placeholder="Detail the repairs made, parts replaced, or diagnostic steps taken..." required></textarea>
            </div>

            <div class="form-group">
              <label for="proof_image" class="form-label">Proof of Resolution Photo (Optional but recommended)</label>
              <input type="file" name="proof_image" id="proof_image" class="form-control" accept="image/jpeg,image/png,image/webp">
              <div class="form-hint">Upload a picture of the fixed fixture, repair report, or testing output.</div>
            </div>

            <div style="text-align: right; margin-top: 20px;">
              <button type="submit" class="btn btn-primary btn-lg">
                <i data-lucide="save"></i>
                <span>Submit Work Update</span>
              </button>
            </div>

          </form>
        </div>
      </div>
    <?php endif; ?>

    <!-- Timeline of all updates -->
    <div class="content-card">
      <div class="card-header">
        <h3>History & Logs</h3>
      </div>
      <div class="card-body">
        <div class="updates-feed">
          <?php foreach ($timeline_updates as $up): ?>
            <div class="update-item">
              <div class="update-dot"></div>
              <div class="update-content">
                <div class="update-header">
                  <span class="update-author"><?php echo clean($up['user_name'] ?? 'System'); ?> (<?php echo clean(ucfirst($up['user_role'] ?? 'System')); ?>)</span>
                  <span class="update-time"><?php echo format_datetime($up['created_at']); ?></span>
                </div>
                <div style="font-size: 13px; color: var(--text-main); margin-top: 4px;">
                  <?php echo clean($up['notes']); ?>
                </div>
                <?php if (!empty($up['proof_image'])): ?>
                  <div style="margin-top: 8px;">
                    <img src="<?php echo base_url('uploads/resolutions/' . $up['proof_image']); ?>" alt="Proof" style="max-height: 120px; border-radius: 4px; border: 1px solid var(--border-color); cursor: pointer;" onclick="window.open(this.src, '_blank')">
                  </div>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

  </div>

  <!-- Right Column: Location & Reporter Details -->
  <div>
    
    <!-- Location Card -->
    <div class="content-card">
      <div class="card-header">
        <h3>Exact Campus Location</h3>
      </div>
      <div class="card-body">
        <div style="display: flex; flex-direction: column; gap: 12px; font-size: 13px;">
          <div>
            <span style="color: var(--text-muted); display: block; font-size: 11px; text-transform: uppercase;">Campus</span>
            <strong style="color: var(--text-main); font-size: 15px;"><?php echo clean($task['building']); ?></strong>
          </div>
          <div>
            <span style="color: var(--text-muted); display: block; font-size: 11px; text-transform: uppercase;">Floor</span>
            <strong style="color: var(--text-main);"><?php echo clean($task['floor']); ?></strong>
          </div>
          <div>
            <span style="color: var(--text-muted); display: block; font-size: 11px; text-transform: uppercase;">Room / Lab Number</span>
            <strong style="color: #2563eb; font-size: 16px;"><?php echo clean($task['room_number']); ?></strong>
          </div>
        </div>
      </div>
    </div>

    <!-- Student / Reporter Details -->
    <div class="content-card">
      <div class="card-header">
        <h3>Reported By (Student)</h3>
      </div>
      <div class="card-body">
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
          <div class="sidebar-user-avatar" style="width: 44px; height: 44px; font-size: 16px;">
            <?php echo strtoupper(substr($task['student_name'] ?? 'S', 0, 1)); ?>
          </div>
          <div>
            <h4 style="font-size: 14px; font-weight: 700;"><?php echo clean($task['student_name']); ?></h4>
            <p style="font-size: 12px; color: var(--text-muted);">Roll: <?php echo clean($task['student_roll'] ?? 'N/A'); ?></p>
          </div>
        </div>

        <?php if (!empty($task['student_phone'])): ?>
          <div style="background: #eff6ff; padding: 10px; border-radius: var(--radius-sm); font-size: 13px; color: #1e40af; display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
            <i data-lucide="phone" style="width: 14px; height: 14px;"></i>
            <a href="tel:<?php echo clean($task['student_phone']); ?>" style="color: inherit; text-decoration: none; font-weight: 600;">
              <?php echo clean($task['student_phone']); ?>
            </a>
          </div>
        <?php endif; ?>

        <div style="font-size: 12px; color: var(--text-muted);">
          Email: <strong><?php echo clean($task['student_email']); ?></strong>
        </div>
      </div>
    </div>

  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
