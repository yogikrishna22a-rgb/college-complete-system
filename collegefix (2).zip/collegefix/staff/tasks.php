<?php
/**
 * CollegeFix - Staff Assigned Tasks
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['staff']);

$user = current_user();
$staff_id = $user['id'];

// Filter params
$search   = trim($_GET['search'] ?? '');
$status   = trim($_GET['status'] ?? '');
$priority = trim($_GET['priority'] ?? '');

$where_clauses = ["c.assigned_staff_id = ?"];
$params = [$staff_id];

if (!empty($search)) {
    $where_clauses[] = "(c.complaint_code LIKE ? OR c.title LIKE ? OR c.building LIKE ? OR c.room_number LIKE ?)";
    $like = '%' . $search . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

if (!empty($status)) {
    $where_clauses[] = "c.status = ?";
    $params[] = $status;
}

if (!empty($priority)) {
    $where_clauses[] = "c.priority = ?";
    $params[] = $priority;
}

$where_sql = implode(" AND ", $where_clauses);

try {
    $query = "
        SELECT c.*, cat.name as category_name, u.name as student_name, u.phone as student_phone
        FROM complaints c
        LEFT JOIN categories cat ON c.category_id = cat.id
        LEFT JOIN users u ON c.user_id = u.id
        WHERE {$where_sql}
        ORDER BY 
            CASE c.priority 
                WHEN 'Emergency' THEN 1 
                WHEN 'High' THEN 2 
                WHEN 'Medium' THEN 3 
                ELSE 4 
            END ASC,
            c.created_at DESC
    ";
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $tasks = $stmt->fetchAll();
} catch (Exception $e) {
    set_flash('danger', 'Error loading tasks: ' . $e->getMessage());
    $tasks = [];
}

$page_title = 'My Assigned Tasks - CollegeFix';
$active_menu = 'tasks';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>My Assigned Maintenance Tasks</h1>
    <p>Review work orders, update task statuses, and upload resolution proof photos.</p>
  </div>
</div>

<!-- Filters -->
<div class="filter-bar">
  <form action="<?php echo base_url('staff/tasks.php'); ?>" method="GET" style="display: contents;">
    <div class="filter-item" style="flex: 2;">
      <label class="form-label" style="font-size: 11px;">Search Keyword</label>
      <input type="text" name="search" class="form-control" placeholder="Search by ticket #, title, room..." value="<?php echo clean($search); ?>">
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Task Status</label>
      <select name="status" class="form-control">
        <option value="">All Statuses</option>
        <option value="Assigned" <?php if ($status === 'Assigned') echo 'selected'; ?>>Assigned (New)</option>
        <option value="In Progress" <?php if ($status === 'In Progress') echo 'selected'; ?>>In Progress</option>
        <option value="Reopened" <?php if ($status === 'Reopened') echo 'selected'; ?>>Reopened</option>
        <option value="Resolved" <?php if ($status === 'Resolved') echo 'selected'; ?>>Resolved</option>
        <option value="Closed" <?php if ($status === 'Closed') echo 'selected'; ?>>Closed</option>
      </select>
    </div>

    <div class="filter-item">
      <label class="form-label" style="font-size: 11px;">Priority</label>
      <select name="priority" class="form-control">
        <option value="">All Priorities</option>
        <option value="Emergency" <?php if ($priority === 'Emergency') echo 'selected'; ?>>Emergency</option>
        <option value="High" <?php if ($priority === 'High') echo 'selected'; ?>>High</option>
        <option value="Medium" <?php if ($priority === 'Medium') echo 'selected'; ?>>Medium</option>
        <option value="Low" <?php if ($priority === 'Low') echo 'selected'; ?>>Low</option>
      </select>
    </div>

    <div style="display: flex; gap: 8px;">
      <button type="submit" class="btn btn-primary">Filter</button>
      <?php if (!empty($search) || !empty($status) || !empty($priority)): ?>
        <a href="<?php echo base_url('staff/tasks.php'); ?>" class="btn btn-secondary"><i data-lucide="x"></i></a>
      <?php endif; ?>
    </div>
  </form>
</div>

<div class="content-card">
  <div class="card-header">
    <h3>Work Orders (<?php echo count($tasks); ?> total)</h3>
  </div>
  <div class="card-body card-body-table">
    <?php if (empty($tasks)): ?>
      <div style="padding: 40px; text-align: center; color: var(--text-muted);">
        <i data-lucide="check-circle" style="width: 44px; height: 44px; margin: 0 auto 12px; color: #10b981;"></i>
        <p style="font-size: 15px; font-weight: 600;">No tasks found matching criteria</p>
      </div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Ticket</th>
              <th>Issue Summary</th>
              <th>Category</th>
              <th>Location</th>
              <th>Priority</th>
              <th>Status</th>
              <th>Student Contact</th>
              <th>Assigned Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($tasks as $t): ?>
              <tr>
                <td>
                  <a href="<?php echo base_url('staff/task_view.php?id=' . $t['id']); ?>" class="table-code">
                    #<?php echo clean($t['complaint_code']); ?>
                  </a>
                </td>
                <td>
                  <strong style="color: var(--text-main);"><?php echo clean($t['title']); ?></strong>
                  <div style="font-size: 12px; color: var(--text-muted);">
                    <?php echo clean(mb_strimwidth($t['description'], 0, 45, '...')); ?>
                  </div>
                </td>
                <td><?php echo clean($t['category_name']); ?></td>
                <td>
                  <strong><?php echo clean($t['room_number']); ?></strong>
                  <div style="font-size: 11px; color: var(--text-muted);"><?php echo clean($t['building'] . ', ' . $t['floor']); ?></div>
                </td>
                <td><?php echo get_priority_badge($t['priority']); ?></td>
                <td><?php echo get_status_badge($t['status']); ?></td>
                <td>
                  <div style="font-size: 13px; font-weight: 500;"><?php echo clean($t['student_name']); ?></div>
                  <?php if (!empty($t['student_phone'])): ?>
                    <a href="tel:<?php echo clean($t['student_phone']); ?>" style="font-size: 11px; color: #2563eb; text-decoration: none;">
                      <?php echo clean($t['student_phone']); ?>
                    </a>
                  <?php endif; ?>
                </td>
                <td style="font-size: 12px; color: var(--text-muted);">
                  <?php echo format_datetime($t['created_at']); ?>
                </td>
                <td>
                  <a href="<?php echo base_url('staff/task_view.php?id=' . $t['id']); ?>" class="btn btn-sm btn-primary">
                    Manage
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
