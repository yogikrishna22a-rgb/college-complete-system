<?php
/**
 * CollegeFix - Staff Profile & Settings
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

require_auth(['staff']);

$user = current_user();
$user_id = $user['id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $name           = trim($_POST['name'] ?? '');
        $phone          = trim($_POST['phone'] ?? '');
        $specialization = trim($_POST['specialization'] ?? '');

        if (empty($name)) {
            $error = 'Name cannot be empty.';
        } else {
            try {
                $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ?, specialization = ? WHERE id = ?");
                $stmt->execute([$name, $phone, $specialization, $user_id]);

                $_SESSION['user_name'] = $name;
                $_SESSION['phone'] = $phone;

                set_flash('success', 'Profile updated successfully.');
                redirect('staff/profile.php');
            } catch (Exception $e) {
                $error = 'Error updating profile: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'change_password') {
        $current_pass = $_POST['current_password'] ?? '';
        $new_pass     = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        if (empty($current_pass) || empty($new_pass)) {
            $error = 'Please fill out all password fields.';
        } elseif (strlen($new_pass) < 6) {
            $error = 'Password must be at least 6 characters.';
        } elseif ($new_pass !== $confirm_pass) {
            $error = 'Passwords do not match.';
        } else {
            try {
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $hash = $stmt->fetchColumn();

                if (!password_verify($current_pass, $hash)) {
                    $error = 'Incorrect current password.';
                } else {
                    $new_hash = password_hash($new_pass, PASSWORD_BCRYPT);
                    $stmt_up = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt_up->execute([$new_hash, $user_id]);

                    set_flash('success', 'Password updated successfully!');
                    redirect('staff/profile.php');
                }
            } catch (Exception $e) {
                $error = 'Error updating password: ' . $e->getMessage();
            }
        }
    }
}

// Fetch user data
try {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
} catch (Exception $e) {
    $user_data = $user;
}

$page_title = 'Staff Profile - CollegeFix';
$active_menu = 'profile';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title">
    <h1>Staff Profile</h1>
    <p>Manage your contact info, maintenance specialty, and security.</p>
  </div>
</div>

<?php if (!empty($error)): ?>
  <div class="alert alert-danger"><?php echo clean($error); ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; max-width: 1000px;">
  
  <div class="content-card">
    <div class="card-header">
      <h3>Technician Details</h3>
    </div>
    <div class="card-body">
      <form action="<?php echo base_url('staff/profile.php'); ?>" method="POST">
        <input type="hidden" name="action" value="update_profile">

        <div class="form-group">
          <label for="name" class="form-label">Full Name</label>
          <input type="text" name="name" id="name" class="form-control" value="<?php echo clean($user_data['name']); ?>" required>
        </div>

        <div class="form-group">
          <label class="form-label">Email Address (Read-only)</label>
          <input type="email" class="form-control" value="<?php echo clean($user_data['email']); ?>" disabled style="background: #f1f5f9; cursor: not-allowed;">
        </div>

        <div class="form-group">
          <label class="form-label">Staff ID</label>
          <input type="text" class="form-control" value="<?php echo clean($user_data['staff_id'] ?? 'STF001'); ?>" disabled style="background: #f1f5f9; cursor: not-allowed;">
        </div>

        <div class="form-group">
          <label for="specialization" class="form-label">Maintenance Specialty</label>
          <input type="text" name="specialization" id="specialization" class="form-control" placeholder="e.g. Electrical & Wiring, HVAC, Plumbing, Network & IT" value="<?php echo clean($user_data['specialization'] ?? ''); ?>">
        </div>

        <button type="submit" class="btn btn-primary">Save Profile</button>
      </form>
    </div>
  </div>

  <div class="content-card">
    <div class="card-header">
      <h3>Change Password</h3>
    </div>
    <div class="card-body">
      <form action="<?php echo base_url('staff/profile.php'); ?>" method="POST">
        <input type="hidden" name="action" value="change_password">

        <div class="form-group">
          <label for="current_password" class="form-label">Current Password</label>
          <input type="password" name="current_password" id="current_password" class="form-control" required placeholder="••••••••">
        </div>

        <div class="form-group">
          <label for="new_password" class="form-label">New Password</label>
          <input type="password" name="new_password" id="new_password" class="form-control" required placeholder="Min. 6 chars">
        </div>

        <div class="form-group">
          <label for="confirm_password" class="form-label">Confirm Password</label>
          <input type="password" name="confirm_password" id="confirm_password" class="form-control" required placeholder="••••••••">
        </div>

        <button type="submit" class="btn btn-secondary">Update Password</button>
      </form>
    </div>
  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
