import express from 'express';
import { spawn, execSync, ChildProcess } from 'child_process';
import { createProxyMiddleware } from 'http-proxy-middleware';
import path from 'path';

const app = express();
const PORT = 3000;
const PHP_PORT = 8088;

app.set('trust proxy', 1);

function ensurePhpInstalled(): boolean {
  try {
    execSync('which php', { stdio: 'ignore' });
    return true;
  } catch {
    console.log('PHP not detected in system. Automatically installing PHP 8.2 and required extensions...');
    try {
      execSync(
        'DEBIAN_FRONTEND=noninteractive apt-get update && ' +
        'DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends ' +
        '-o Dpkg::Options::="--force-confold" -o Dpkg::Options::="--force-confdef" ' +
        'php8.2-cli php8.2-sqlite3 php8.2-mbstring php8.2-xml php8.2-curl php8.2-gd && ' +
        'sed -i "s/^upload_max_filesize = .*/upload_max_filesize = 64M/" /etc/php/8.2/cli/php.ini 2>/dev/null || true; ' +
        'sed -i "s/^post_max_size = .*/post_max_size = 64M/" /etc/php/8.2/cli/php.ini 2>/dev/null || true; ' +
        'sed -i "s/^memory_limit = .*/memory_limit = 256M/" /etc/php/8.2/cli/php.ini 2>/dev/null || true',
        { stdio: 'inherit' }
      );
      return true;
    } catch (installErr) {
      console.error('Failed to automatically install PHP:', installErr);
      return false;
    }
  }
}

// Start the PHP 8+ Server for CollegeFix
let phpProcess: ChildProcess | null = null;
let isRestarting = false;

function startPhpServer() {
  isRestarting = false;

  if (!ensurePhpInstalled()) {
    console.error('PHP is not available yet. Retrying in 4 seconds...');
    setTimeout(startPhpServer, 4000);
    return;
  }

  const collegefixDir = path.join(process.cwd(), 'collegefix');
  console.log(`Starting PHP 8 server on 127.0.0.1:${PHP_PORT} serving directory: ${collegefixDir}`);
  
  try {
    phpProcess = spawn('php', [
      '-d', 'session.cookie_samesite=None',
      '-d', 'session.cookie_secure=1',
      '-d', 'session.cookie_httponly=1',
      '-d', 'session.use_only_cookies=0',
      '-d', 'upload_max_filesize=64M',
      '-d', 'post_max_size=64M',
      '-d', 'memory_limit=256M',
      '-d', 'max_file_uploads=20',
      '-d', 'max_execution_time=120',
      '-S', `127.0.0.1:${PHP_PORT}`,
      '-t', collegefixDir
    ], {
      stdio: 'inherit'
    });

    const triggerRestart = (reason: string) => {
      if (isRestarting) return;
      isRestarting = true;
      console.log(`PHP server stopped (${reason}). Restarting in 2s...`);
      setTimeout(() => {
        startPhpServer();
      }, 2000);
    };

    phpProcess.on('error', (err) => {
      console.error('PHP server error:', err);
      triggerRestart('error');
    });

    phpProcess.on('exit', (code, signal) => {
      triggerRestart(`exit code ${code}, signal ${signal}`);
    });
  } catch (err) {
    console.error('Failed to spawn PHP process:', err);
    setTimeout(startPhpServer, 2000);
  }
}

startPhpServer();

process.on('exit', () => {
  if (phpProcess) phpProcess.kill();
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', app: 'CollegeFix - PHP 8+ Maintenance Management' });
});

// Proxy all requests directly to the PHP 8+ application with iframe-ready cookie headers
app.use('/', createProxyMiddleware({
  target: `http://127.0.0.1:${PHP_PORT}`,
  changeOrigin: true,
  ws: true,
  xfwd: true,
  cookieDomainRewrite: '',
  cookiePathRewrite: '/',
  on: {
    error: (err, req, res) => {
      console.error('Proxy error connecting to PHP server:', (err as Error).message);
      if (res && 'writeHead' in res) {
        (res as express.Response).status(502).send(`
          <html>
            <head><meta http-equiv="refresh" content="2"><title>Loading CollegeFix...</title></head>
            <body style="font-family:system-ui,sans-serif;text-align:center;padding:50px;">
              <h2>Starting CollegeFix Application...</h2>
              <p style="color:#64748b;">The service is initializing. This page will refresh automatically in 2 seconds.</p>
            </body>
          </html>
        `);
      }
    },
    proxyRes: (proxyRes) => {
      const setCookies = proxyRes.headers['set-cookie'];
      if (setCookies) {
        proxyRes.headers['set-cookie'] = setCookies.map((c: string) => {
          let updated = c;
          if (/samesite=/i.test(updated)) {
            updated = updated.replace(/samesite=[a-z]+/i, 'SameSite=None');
          } else {
            updated += '; SameSite=None';
          }
          if (!/;\s*secure/i.test(updated)) {
            updated += '; Secure';
          }
          if (!/;\s*partitioned/i.test(updated)) {
            updated += '; Partitioned';
          }
          return updated;
        });
      }
    }
  }
}));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`CollegeFix Gateway running on http://0.0.0.0:${PORT} forwarding to PHP 8 on port ${PHP_PORT}`);
});
